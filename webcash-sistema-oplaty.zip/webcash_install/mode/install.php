<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

defined('DATALIFEENGINE') or exit('Access Denied');
?>

<h2>Автоматическая установка модуля</h2>

<?php
//проверка на права доступа
$arr = array(
	ENGINE_DIR.'/data/',
	ENGINE_DIR.'/inc/',
	ENGINE_DIR.'/skins/images/',
	ENGINE_DIR.'/modules/',
	ROOT_DIR.'/templates/',
);

$error = false;
clearstatcache();

foreach ($arr as $fname) {
	if (!is_writable($fname)) {
		$error = true;

		if (is_dir($fname))
			echo '<p class="message information">Ошибка! Каталог &laquo;'.$fname.'&raquo; недоступен для записи.</p>';
		elseif (is_file($fname))
			echo '<p class="message information">Ошибка! Файл &laquo;'.$fname.'&raquo; недоступен для записи.</p>';
	}
}

if ($error) {
	echo '<p>Возникли ошибки при установке, рекомендуется устранить проблемы с правами доступа и заново обновить эту страницу для продолжения установки.<br /><br /> Если возникли проблемы на выделенном сервере - скорее всего связано с правами доступа, когда не совпадают владельцы и группы скриптов и фтп. На время тестирования, можно установить у этих папок и файлов права 777 (это временное решение), чтобы убедиться в причине проблемы. Потом все же рекомендуется разобраться, почему возникла такая ситуация. Часто помогает команда <a href="http://ru.wikipedia.org/wiki/Chown" target="_blank" title="Просмотреть информацию по команде, ссылка откроется в новом окне">chown</a>, можно показать эту часть текста хостеру или администратору, обслуживающему ваш выделенный сервер - они сразу поймут в чем дело.<br /><br /> В крайнем случае, вы можете прибегнуть к ручной установке, процесс который входит в инструкцию по модулю. <a href="http://'.$_SERVER['HTTP_HOST'].'/webcash_install/index.php?do=readme">Перейти к чтению инструкции.</a></p>';
	echo_bottom_html();
	exit;
}
//проверка на права доступа


echo '<ul>';

copy_folder('files', './..', false, false);
echo '<li>Скопированы файлы модуля</li>';



$fname = ROOT_DIR.'/webcash_install/sql/install.sql';

if (file_exists($fname)) {
	$sql_query = fread(fopen($fname, 'r'), filesize($fname)) or exit('Error ['.$fname.']');
	$sql_query = remove_remarks($sql_query);
	$sql_query = split_sql_file($sql_query, ';');

	foreach ($sql_query as $sql) {
		$search = array('dle_', '{PREFIX}', '{USERPREFIX}');
		$replace = array(PREFIX.'_', PREFIX, USERPREFIX);
		$sql = str_replace($search, $replace, $sql);
		$sql = __($sql, true, false);
		$db->query($sql);
	}

	$fname = str_replace(ROOT_DIR, '', $fname);
	echo '<li>Выполнены запросы из файла &laquo;'.$fname.'&raquo;</li>';
}


if (!empty($config['version_id']) and version_compare($config['version_id'], 13, '>=')) {
	$db->query("DELETE FROM `".PREFIX."_plugins` WHERE `name` = 'WebCash'");
	$db->query("INSERT IGNORE INTO `".PREFIX."_plugins` (`name`, `description`, `active`) VALUES ('WebCash', 'Вставка кода в файлы: engine/engine.php, engine/modules/main.php, engine/inc/userfields.php для модуля WebCash. Разработано в New-Dev.ru (платные и бесплатные модули для DLE) &lt;newdevexpert@gmail.com&gt;', 1);");
	if ($id = $db->insert_id()) {
		$db->query("INSERT IGNORE INTO `".PREFIX."_plugins_files` (`plugin_id`, `file`, `action`, `searchcode`, `replacecode`, `active`) VALUES ('{$id}', 'engine/engine.php', 'before', 'case \"rules\" :', '
case \"webcash\" :
		require DLEPlugins::Check(ENGINE_DIR.\'/modules/webcash/site/index.php\');
		break;
		', 1);");
		
		$db->query("INSERT IGNORE INTO `".PREFIX."_plugins_files` (`plugin_id`, `file`, `action`, `searchcode`, `replacecode`, `active`) VALUES ('{$id}', 'engine/modules/main.php', 'before', 'echo \$tpl->result[\'main\'];', 'require ENGINE_DIR.\'/modules/webcash/site/includes/main.php\';', 1);");
		
		$db->query("INSERT IGNORE INTO `".PREFIX."_plugins_files` (`plugin_id`, `file`, `action`, `searchcode`, `replacecode`, `active`) VALUES ('{$id}', 'engine/inc/userfields.php', 'after', 'msg(\"error\", \$lang[\'xfield_error\'], \$lang[\'xfield_xerr2\']);
}', 'require ENGINE_DIR.\'/modules/webcash/admin/includes/userfields.php\';', 1);");
		
		nd_rmdir(ENGINE_DIR.'/cache/system/plugins/', false);
		nd_unlink(ENGINE_DIR.'/cache/system/plugins.php');
		
		echo '<li>Установлен плагин для вставки кода в файлы: &laquo;engine/engine.php&raquo;, &laquo;engine/modules/main.php&raquo;, &laquo;engine/inc/userfields.php&raquo;</li>';
	}
} else {
	
	$arr = array(
		'search' => 'echo $tpl->result[\'main\'];',
		'replace' => "require ENGINE_DIR.'/modules/webcash/site/includes/main.php';",
		'action' => 'before',
	);
	if (!modify_cms_file(ENGINE_DIR.'/modules/main.php', 'webcash', $arr)) {
		modify_cms_file(ROOT_DIR.'/index.php', 'webcash', $arr);
	}
	
	$arr = array(
		'search' => '[SKIP]\s*[/SKIP]case "rules" :',
		'replace' => "\r\n\tcase 'webcash' :\r\n\t\trequire ENGINE_DIR.'/modules/webcash/site/index.php';\r\n\t\tbreak;",
		'action' => 'before',
	);
	modify_cms_file(ENGINE_DIR.'/engine.php', 'webcash', $arr);
	
	$arr = array(
		'search' => 'msg("error", $lang[\'xfield_error\'], $lang[\'xfield_xerr2\']);[SKIP]\s*[/SKIP]}',
		'replace' => "\r\nrequire ENGINE_DIR.'/modules/webcash/admin/includes/userfields.php';",
		'action' => 'after',
	);
	modify_cms_file(ENGINE_DIR.'/inc/userfields.php', 'webcash', $arr);	
}
?>
</ul>

<p>Установка успешно завершена, папка &laquo;webcash_install&raquo; может быть удалена. Вы можете <a href="/<?php echo $config['admin_path']; ?>?mod=webcash" target="_blank">перейти в админцентр</a>, чтобы настроить модуль WebCash или <a href="/" target="_blank">перейти на Главную страницу</a> сайта.</p>


<?php require_once 'readme.php'; ?>