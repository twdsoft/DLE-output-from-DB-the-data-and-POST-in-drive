<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

defined('DATALIFEENGINE') or exit('Access Denied');
?>

<h2>Инструкция по подключению</h2>

<p>
	Модуль предназначен для осуществления платежей с помощью платежных шлюзов или с баланса пользователя. С помощью плагинов можно добавлять новые функции, например, зачисление денег на баланс пользователя за публикацию новостей, пополнение баланса с помощью промокода и через платежные шлюзы и т.д.
</p>


<p class="message information">Внимание! Ознакомиться с другими нашими модулями можно на сайте <a href="http://new-dev.ru/" target="_blank">New-Dev.ru</a></p>

<h2>Контакты для связи</h2>
<p>В случае возникновения технических вопросов или предложений по улучшению модуля связаться можно <strong>по почте: </strong><a href="mailto:newdevexpert@gmail.com">newdevexpert@gmail.com</a> или <strong>телеграму: </strong> @NewDevRU.</p>

<br>
<h3>Ручная установка</h3>
<p>При возникновении проблем с автоматической установкой, можно завершить процесс вручную.</p>
<ul onload="init();">
	<li>1) Скопировать содержимое папки &laquo;/webcash_install/files/&raquo; в корень сайта<br /><br /></li>
	
	<li>
		2) Выполнить запросы из файла &laquo;/webcash_install/sql/install.sql&raquo;
		<br>
		<textarea><?php echo file_get_contents(ROOT_DIR.'/webcash_install/sql/install.sql'); ?></textarea>
		<br /><br />
	</li>
	
	<li>
		3)
		
		<?php if (!empty($config['version_id']) and version_compare($config['version_id'], 13, '>=')) { ?>
			В <a href="/<?php echo $config['admin_path']; ?>?mod=plugins" target="blank">админпанели</a> установить плагин &laquo;<a href="/webcash_install/webcash.xml" target="_blank" download>/webcash_install/webcash.xml</a>&raquo; для вставки кода в файлы: &laquo;/engine/modules/main.php&raquo;, &laquo;/engine/engine.php&raquo;, &laquo;engine/inc/userfields.php&raquo;.
		<?php } else { ?>
			<br>
			<fieldset>
				<legend><b>В файле &laquo;/engine/modules/main.php&raquo;</b> (если его нет, тогда в <b>файле &laquo;/index.php&raquo;</b>) </legend>
				перед строкой:
				<input type="text" value="<?php echo htmlspecialchars('echo $tpl->result[\'main\'];'); ?>">
				добавить строку:
				<input type="text" value="require ENGINE_DIR.'/modules/webcash/site/includes/main.php';">
			</fieldset>
			
			<br>
			<fieldset>
				<legend><b>В файле &laquo;/engine/engine.php&raquo;</b></legend>
				перед строкой:
				<input type="text" value="<?php echo htmlspecialchars('case "rules" :'); ?>">
				добавить строки:
<textarea>
case "webcash" :
	require ENGINE_DIR.'/modules/webcash/site/index.php';
	break;
</textarea>
			</fieldset>
			
			<br>
			<fieldset>
				<legend><b>В файле &laquo;/engine/inc/userfields.php&raquo;</b></legend>
				после строк:
<textarea>
	msg("error", $lang['xfield_error'], $lang['xfield_xerr2']);
}
</textarea>
				добавить строку:
				<input type="text" value="require ENGINE_DIR.'/modules/webcash/admin/includes/userfields.php';">
			</fieldset>
			
			
		<?php } ?>
	</li>
</ul>


<br>
<h3>FAQ (часто задаваемые вопросы)</h3>
<ul class="list2">
	<li><b>Вопрос</b> Для каких версий DataLife Engine рассчитан модуль?</li>
	<li><b>Ответ:</b> Модуль работает со всеми версиями 10.2 - 14.x.</li>

	<li><b>Вопрос</b> Как вывести значение баланса пользователя на главную страницу?</li>
	<li><b>Ответ:</b> В нужном месте в &laquo;main.tpl&raquo; можно вставить <b>{include file="/engine/modules/webcash/site/showbalance.php"}</b></li>

	<li><b>Вопрос:</b> Как удалить модуль или при необходимости снова прочитать инструкцию по подключению без запуска установки</li>
	<li><b>Ответ:</b> Удалить модуль можно по ссылке <a href="/webcash_install/index.php?mode=uninstall" target="_blank">/webcash_install/index.php?mode=uninstall</a>, а прочитать инструкцию без запуска установки модуля по ссылке <a href="/webcash_install/index.php?mode=readme" target="_blank">/webcash_install/index.php?mode=readme</a>.</li>
</ul>