<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

header('Content-Type: text/html; charset=utf-8');

define('ROOT_DIR', dirname(dirname(__FILE__)));
define('ENGINE_DIR', ROOT_DIR.'/engine');
define('DATALIFEENGINE', true);

require_once ENGINE_DIR.'/classes/mysql.php';
require_once ENGINE_DIR.'/data/dbconfig.php';
require_once ENGINE_DIR.'/data/config.php';

require_once ROOT_DIR.'/webcash_install/functions.php';
require_once ROOT_DIR.'/webcash_install/files/engine/modules/webcash/functions.php';
require_once ROOT_DIR.'/webcash_install/files/engine/modules/webcash/admin/lib/sql_parse.php';
require_once ROOT_DIR.'/webcash_install/files/engine/modules/webcash/admin/lib/xcopy/xcopy.php';

require_once ROOT_DIR.'/webcash_install/files/engine/modules/webcash/classes/application.class.php';
require_once ROOT_DIR.'/webcash_install/files/engine/modules/webcash/classes/config.class.php';
require_once ROOT_DIR.'/webcash_install/files/engine/modules/webcash/classes/helper.class.php';
require_once ROOT_DIR.'/webcash_install/files/engine/modules/webcash/classes/dlevars.class.php';
require_once ROOT_DIR.'/webcash_install/files/engine/modules/webcash/classes/addonsettings.class.php';
require_once ROOT_DIR.'/webcash_install/files/engine/modules/webcash/plugins/listtransactions/listtransactions.class.php';
require_once ROOT_DIR.'/webcash_install/files/engine/modules/webcash/classes/webcash.class.php';

echo_top_html();

$mode = empty($_GET['mode']) ? 'install' : $_GET['mode'];

if (!in_array($mode, array('install', 'uninstall', 'readme'))) exit('error mode');

require_once ROOT_DIR.'/webcash_install/mode/'.$mode.'.php';

echo_bottom_html();