<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

use WebCash\NewDb;

require ENGINE_DIR.'/modules/webcash/classes/newdb.class.php';

$db = new NewDb;