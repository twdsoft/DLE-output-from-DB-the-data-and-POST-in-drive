<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

class Gateways_Admin_WebMoney extends Admin_AddonSettings
{
	protected $base_alias = 'webmoney';
	
	public function getGwItemsTblColumns() {
		$tbl_columns = array();
		
		$tbl_columns['nosort1']['column'] = __('№');
		$tbl_columns['title']['column'] = __('Заголовок');
		$tbl_columns['image']['column'] = __('Лого');
		$tbl_columns['lmi_allow_sdp']['column'] = __('LMI_ALLOW_SDP');
		$tbl_columns['lmi_sdp_type']['column'] = __('LMI_SDP_TYPE');
		$tbl_columns['at']['column'] = __('Параметр &laquo;at&raquo;');
		$tbl_columns['description']['column'] = __('Описание');
		$tbl_columns['created']['column'] = __('Дата');
		$tbl_columns['state']['column'] = __('Статус');
		$tbl_columns['nosort2']['column'] = __('Действие');

		$tbl_columns['id']['column'] = __('ID');
		
		
		$tbl_columns = $this->endHandleTblColumns($tbl_columns, 'gw_items_tbl_columns_list');
		
		return $tbl_columns;
	}
	
	public function listGwItems() {
		$base_instance = $this->getBaseInstance();
		
		if (!$total_count = $this->db->selectCell("SELECT COUNT(*) FROM {$base_instance->table_a}"))
			return __('Нет записей');
		
        if ($rows = $this->db->select("SELECT * FROM {$base_instance->table_a}".$base_instance->getItemsOrderBy())) {
		
			$tbl_columns = $this->getGwItemsTblColumns();
			
			$html = '
			<div class="table-responsive">

				<table class="table table-xs table-hover">
					
					'.$this->renderItemsTableThead($tbl_columns).'
					
					<tbody>';
				
				foreach ($rows as $index => $row) {
				
					$edit_start_tag = '<a href="'.$base_instance->getAddonSettingsUrl('&tab2=2&id='.$row['id']).'" title="'.__('Редактировать метод оплаты').'">';
					
					$html .= '<tr>';
					
					if ($tbl_columns['nosort1']['state'])
						$html .= '<td>'.($index + 1).'</td>';
					if ($tbl_columns['title']['state'])
						$html .= '<td>'.$edit_start_tag.$row['title'].'</a></td>';
					if ($tbl_columns['image']['state'])
						$html .= '<td>'.($row['image'] ? '<img src="'.$this->webcash->module_url.'/gateways/webmoney/assets/images/'.$row['image'].'" alt="" style="max-width:30px;" class="simple-lightbox">' : '--//--').'</td>';
					if ($tbl_columns['lmi_allow_sdp']['state'])
						$html .= '<td>'.$row['LMI_ALLOW_SDP'].'</td>';
					if ($tbl_columns['lmi_sdp_type']['state'])
						$html .= '<td>'.$row['LMI_SDP_TYPE'].'</td>';
					if ($tbl_columns['at']['state'])
						$html .= '<td>'.$row['at'].'</td>';
					if ($tbl_columns['description']['state'])
						$html .= '<td>'.($row['description'] ? $row['description'] : '--//--').'</td>';
					if ($tbl_columns['created']['state'])
						$html .= '<td class="text-center">'.$row['created'].'</td>';
					if ($tbl_columns['state']['state'])
						$html .= '<td class="text-center"><i title="'.($row['state'] ? __('Опубликован') : __('Снят с публикации')).'" class="fa fa-exclamation-circle tip '.($row['state'] ? 'text-success' : 'text-danger').'"></i></td>';
					if ($tbl_columns['nosort2']['state'])
						$html .= '
						<td class="text-center">
							<a href="#" data-do="ajax-webcash" data-vars="action=ajax.plugin.from_tab2|subaction=delete|id='.$row['id'].'|plg_alias='.$base_instance->alias.'"'.($base_instance->item_delete_button_confirm ? ' data-confirm="1"' : '').' title="'.__('Удалить запись').'"><i class="fa fa-trash-o text-danger position-left"></i></a>'.$edit_start_tag.'<i class="fa fa-pencil"></i></a>
						</td>';
					if ($tbl_columns['id']['state'])
						$html .= '<td class="text-center">'.$row['id'].'</td>';
					
					$html .= '</tr>';
				}
				
				$html .= '
					</tbody>
				</table>
				
				'.$pagination_html.'
				
			</div>';
		
			return $html;
		}
	}

	
}