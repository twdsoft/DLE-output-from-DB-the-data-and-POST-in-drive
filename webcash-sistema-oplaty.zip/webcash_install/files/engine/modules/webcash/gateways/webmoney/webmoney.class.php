<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

class Gateways_WebMoney extends AddonSettings
{
	const ITEMS_SORTING = 'ordering DESC, id';
	
	protected $alias = 'webmoney';
	protected $table_a = 'webcash_webmoney_gw_items';
	
    public function renderPaymentForm($invoice_id, $cs_key, $gw_item_id) {
		if ($str = $this->verifyGatewayEnable())
			return $str;
		
		if (!$checkout_store = $this->checkout->getDataStore($cs_key))
			return '';
		
		$service_info = $this->getServiceInfo();
		
		if (!$gw_item = safe_array_access($service_info, 'items', $gw_item_id))
			trigger_error(basename(__FILE__).', line: '.__LINE__, E_USER_ERROR);
		
		$amount = $this->wc_currency->convertMainCurrencyTo($checkout_store['amount'], $this->currency);
		
		$tpl = $this->webcash->getTplInstance();
		$tpl->assign('invoice_id', $invoice_id);
		$tpl->assign('amount', number_format($amount, 2, '.', ''));
		$tpl->assign('lmi_payment_desc_base64', base64_encode(to_utf8(safe_array_access($checkout_store, 'checkout_header'))));
		$tpl->assign('email', $this->helper->htmlspecialchars(safe_array_access($checkout_store, 'email')));
		$tpl->assign('lmi_payee_purse', $this->getPurse());
		$tpl->assign('processing_url', $this->checkout->getGatewayProcessingUrl($this->alias));
		$tpl->assign('success_url', $this->checkout->successCheckoutUrl($invoice_id, $cs_key));
		$tpl->assign('fail_url', $this->checkout->failCheckoutUrl($invoice_id, $cs_key));
		$tpl->assign('ip', $this->user->ip);
		$tpl->assign('gw_item', $gw_item);
		$tpl->assign('gateway_header', $service_info['name']);
		$tpl->assign('gw_alias', $this->alias);
		$tpl->assign('gateway_cfg', $this->getCfgPublicParams());
		$tpl->assign('addon_settings_link', $this->renderAddonSettingsLink());
		$tpl->assign('user_hash', $this->user->nonce);
		$tpl->load_template('/modules/webcash/gateways/webmoney/checkout.tpl');
		
		$tpl->compile('content');
		
		return $tpl->result['content'];
	}
	
	public function signData() {
		if (!empty($_POST)) {
			$secret_key = $this->getSecretKey();
			
			$str = POST('LMI_PAYEE_PURSE').POST('LMI_PAYMENT_AMOUNT').POST('LMI_PAYMENT_NO').POST('LMI_MODE').POST('LMI_SYS_INVS_NO').POST('LMI_SYS_TRANS_NO').POST('LMI_SYS_TRANS_DATE').$secret_key.POST('LMI_PAYER_PURSE').POST('LMI_PAYER_WM');// Склеиваем строку параметров
			
			$hash = strtoupper(hash('sha256', $str));//Шифруем полученную строку в sha256 и переводим ее в верхний регистр
			return $hash;
		}
	}
	
	public function processing() {
		if (!POST())
			$this->printError('Пустой запрос');
		
		$invoice_id = (int)POST('LMI_PAYMENT_NO');
		
		if (POST('LMI_PREREQUEST') == 1) {
			if (!$invoice_row = $this->webcash->getRowById($this->webcash->gateway_invoices_table, $invoice_id)) {
				$this->printError('Нет такого инвойса');
			} elseif ($invoice_row['state']) {
				$this->printError('Недействительный инвойс');
			}
			
			if (!(float)$invoice_row['amount'] or $invoice_row['amount'] > POST('LMI_PAYMENT_AMOUNT'))
				$this->printError('Неверная сумма: '.POST('LMI_PAYMENT_AMOUNT'));
			
			if (POST('LMI_PAYEE_PURSE') != $this->getPurse())//cравниваем наш настоящий кошелек с тем кошельком, который передан нам Мерчантом.
				$this->printError('Неверный кошелек получателя '.POST('LMI_PAYEE_PURSE'));
			
			if ($this->email_required) {
				if (!POST('user_email') or !trim($_POST['user_email']))//проверяем, указал ли пользователь свой Емайл
					$this->printError('Не указан Е-майл покупателя');
			}
			
			echo 'YES';//если ошибок не возникло, то выводим YES
			exit;
			
		} else {//если нет lmi_prerequest, следовательно это форма оповещения о платеже...
			$hash = $this->signData($_POST);
			
			if ($hash != POST('LMI_HASH'))// прерываем работу скрипта, если контрольные суммы не совпадают
				$this->printError('Неверная подпись: '.POST('LMI_HASH'));
			
			if (!$invoice_row = $this->webcash->getRowById($this->webcash->gateway_invoices_table, $invoice_id)) {
				$this->printError('Нет такого инвойса');
			} elseif ($invoice_row['state']) {
				$this->printError('Недействительный инвойс');
			}
			
			if ($invoice_row['gateway'] != $this->alias) {
				$this->printError('Инвойс не той платежной системы');
			}
			
			
			if ((float)$invoice_row['amount'] and POST('LMI_PAYMENT_AMOUNT') >= (float)$invoice_row['amount']) {
				$payment_id = $this->processAfterPayment($invoice_id);
				
				if ($payment_row = $this->webcash->getRowById($this->webcash->gateway_payments_table, $payment_id)) {
					
					$this->checkout->gatewaySuccessPayment($invoice_row, $payment_row);

					fs_log('Заказ #'.$invoice_id.' оплачен!');
					exit;
				}
			}
			
			$this->printError('Не удалось завершить операцию');
		}
	}
	
	public function printError($text) {
		$text = 'Ошибка! '.$text;
		//fs_log('Merchant error ('.$this->alias.'): '.$text);
		echo $text;
		exit;
	}
	
	public function processAfterPayment($invoice_id) {
		$gateway_details_arr = POST();
		$gateway_details_arr = array_map(array($this->helper, 'htmlspecialchars'), $gateway_details_arr);
		
		return $this->checkout->addPaymentToDb($invoice_id, POST('LMI_PAYER_PURSE'), $gateway_details_arr);
	}
	
	public function getPurse() {
		$str = strtolower($this->currency);
		
		if (!$purse = $this->{'purse_'.$str})
			$this->webcash->exitMsg('Не указан номер кошелька. Необходимо обратиться к администратору');
		
		return $purse;
	}
	
	public function getSecretKey() {
		$str = strtolower($this->currency);
		
		if (!$secret_key = $this->{'secret_key_'.$str})
			$this->webcash->exitMsg('Не указан секретное слово кошелька. Необходимо обратиться к администратору');
		
		return $secret_key;
	}
	
	public function getServiceInfo() {
		$result = array(
			'name' => 'Webmoney',
			'alias' => $this->alias,
			'items' => $this->arrayKeyId(),
		);
		
		return $result;
	}

}