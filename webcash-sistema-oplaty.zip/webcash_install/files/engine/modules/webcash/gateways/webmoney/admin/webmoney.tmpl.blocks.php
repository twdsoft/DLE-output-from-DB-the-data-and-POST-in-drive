<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

$arr = $this->wc_currency->getCurrenciesList();

$this->adminpanel->showRow(
	__('Главная валюта'),
	__('Главная валюта платежного шлюза'),
	$this->adminpanel->makeDropdown(
		$arr,
		'data[currency]',
		$this->currency,
		'data-linked_select="currency"'
	),
	'',
	$this->col_values
);

foreach ($this->config->currencies as $key => $value) {
	$lower_key = strtolower($key);
	$title = __($value['title']);
	
	$name = 'purse_'.$lower_key;
	
	$this->adminpanel->showRow(
		sprintf(__('Номер кошелька для валюты &laquo;%s&raquo;'), $title),
		sprintf(__('Номер кошелька для приема оплаты для валюты &laquo;%s&raquo;'), $title),
		$this->adminpanel->makeInputText(
			'data['.$name.']',
			$this->{$name}
		),
		$this->makeAddonLinkedPart('currency', $key),
		$this->col_values,
		true
	);
	
	
	$name = 'secret_key_'.$lower_key;
	
	$this->adminpanel->showRow(
		sprintf(__('Секретное слово для валюты &laquo;%s&raquo;'), $title),
		sprintf(__('Секретное слово для проверки уведомлений для валюты &laquo;%s&raquo;'), $title),
		$this->adminpanel->makeInputText(
			'data['.$name.']',
			$this->{$name}
		),
		$this->makeAddonLinkedPart('currency', $key),
		$this->col_values,
		true
	);
}


$this->adminpanel->showRow(
	__('Разрешить доступ только этим группам пользователей'),
	__('Вы можете указать определенные пользовательские группы, которым разрешен доступ к плагину на сайте. Если не указано - то доступ по группе не будет ограничен'),
	$this->webcash->getUsergroupsMultiSelect(
		'data[access_allowed_usergroups][]',
		$this->access_allowed_usergroups
	),
	'',
	$this->col_values
);