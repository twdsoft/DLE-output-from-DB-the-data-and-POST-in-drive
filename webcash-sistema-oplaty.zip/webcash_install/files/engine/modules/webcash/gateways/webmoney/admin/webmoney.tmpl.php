<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

$tabs = array(
	array('id' => 1, 'caption' => __('Методы оплаты')),
	array('id' => 2, 'caption' => __('Редактировать метод оплаты')),
);

if (!$active_tab2 = (int)GET('tab2') or $active_tab2 > count($tabs))
	$active_tab2 = 1;
?>

<div class="panel">

	<div class="panel-header">
		<ul class="nav nav-tabs nav-tabs-left">
			<?php foreach ($tabs as $tab) { ?>
			<li class="<?php echo ($active_tab2 == $tab['id']) ? 'active' : ''; ?>">
				<a href="<?php echo $this->getAddonSettingsUrl('&tab2='.$tab['id']); ?>">
					<?php echo $tab['caption'].safe_array_access($tab, 'header_html'); ?>
				</a>
			</li>
			<?php } ?>
		</ul>
	</div>

	<div class="panel-content">
		<div class="tab-content">

			<div class="tab-pane active">
				<?php require_once $this->getPath().'admin/tab'.$active_tab2.'.php'; ?>
			</div>
			
		</div>
	</div>

</div>