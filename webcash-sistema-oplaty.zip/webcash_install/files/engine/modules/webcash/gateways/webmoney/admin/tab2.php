<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

if ($id = (int)GET('id') and $webmoney_gw_item = $this->webcash->getRowById($this->table_a, $id)) {
?>
<form action="" class="webcash_ajax_form form-horizontal" method="post" autocomplete="off">
	<div class="panel panel-flat">
		<div class="panel-body">
			
			<?php echo $this->adminpanel->hint(__FILE__.'1', 'Все поля отмеченные звездочкой - обязательны к заполнению.'); ?>
			
		</div>
		
		<div class="table-responsive">
			<table class="table table-striped">
			
				<?php require_once $this->getPath().'admin/uni_webmoney_gw_item.php'; ?>
			
			</table>
			
			<div class="buttons_wrap">
				<input type="hidden" name="action" value="ajax.gateway.from_tab2" />
				<input type="hidden" name="subaction" value="edit_webmoney_gw_item" />
				<input type="hidden" name="id" value="<?php echo $id; ?>" />
				<input type="hidden" name="user_hash" value="<?php echo $this->user->nonce; ?>" />
				<input type="hidden" name="gw_alias" value="<?php echo $this->alias; ?>" />
				<button type="submit" class="btn bg-teal btn-raised position-left btn-green">
					<i class="fa fa-floppy-o position-left"></i><?php echo __('Готово'); ?>
				</button>
			</div>
		</div>
	</div>
</form>
<?php
} else {

	$this->js_css->addJsCode('
	$("#adm_search_dialog").dialog({
		autoOpen: true,
		width: 500,
		height: "auto",
		modal: true,
		close: function() {
			WEBCASH.redirectTo("'.$this->getAddonSettingsUrl('&tab2=1').'");
		}
	});', true, true);
	?>
	
	<div id="adm_search_dialog" title="<?php echo __('Выбор метода оплаты для редактирования'); ?>" style="display:none">
		<form action="" class="webcash_ajax_form form-horizontal" method="post" autocomplete="off">
			
			<?php echo $this->adminpanel->hint(__FILE__.'1', sprintf(__('Перейти к редактированию метода оплаты платежного шлюза можно также из <a href="%s">списка методов оплаты</a>.'), $this->getAddonSettingsUrl('&tab2=1')), false); ?>
			
			<div class="sepH_c">
				<?php $str = __('Введите ID или название метода оплаты...'); ?>
				<input type="hidden" name="remark" value="<?php echo $str; ?>" />
				<input type="text" class="form-control" name="search_value" style="width:100%;" value="<?php echo $str ?>" onclick="if (this.value == '<?php echo $str ?>') this.value=''" onblur="if (this.value == '') this.value='<?php echo $str ?>'" />
			</div>
			
			<div class="text-center">
				<input type="hidden" name="action" value="ajax.gateway.from_tab2" />
				<input type="hidden" name="subaction" value="adm_search_gw_item" />
				<input type="hidden" name="user_hash" value="<?php echo $this->user->nonce; ?>" />
				<input type="hidden" name="gw_alias" value="<?php echo $this->alias; ?>" />
				<button type="submit" class="btn bg-teal btn-raised position-left btn-green">
					<i class="fa fa-search position-left"></i><?php echo __('Готово'); ?>
				</button>
				<a href="#" class="btn bg-slate-600 btn-raised" onclick="$('#adm_search_dialog').dialog('close'); return false;">
					<i class="fa fa-close position-left"></i><?php echo __('Отмена'); ?>
				</a>
			</div>
		</form>	
	</div>
<?php } ?>