<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

if (!$this->readSettingsFromFile()) {
	$this->setCfgValue('display_name', 'Платежный шлюз Webmoney');
	$this->setCfgValue('description', 'С помощью этого шлюза можно организовать прием платежей через платежную систему Webmoney.');
	foreach ($this->config->currencies as $key => $value) {
		$lower_key = strtolower($key);
		$this->setCfgValue('purse_'.$lower_key, '');//Номер кошелька
		$this->setCfgValue('secret_key_'.$lower_key, '');//секретный ключ
	}
	$this->setCfgValue('currency', 'USD');
	$this->setCfgValue('email_required', 0);
	$this->setCfgValue('test_mode', 0);
	$this->setCfgValue('lmi_sim_mode', 0);
	$this->setCfgValue('site_url', 'http://merchant.webmoney.ru/conf/default.asp');
	$this->setCfgValue('item_delete_button_confirm', 1);
	$this->setCfgValue('access_allowed_usergroups', array());
	$this->setConvCfgValue('date_format', 'j F Y г. H:i');
	$this->setCfgValue('gw_items_tbl_columns_list', 'nosort1,title,image,description,lmi_allow_sdp,lmi_sdp_type,state,nosort2,id');
	$this->setNoneFormControlCfgValue('public_cfg_fields', array(
		'test_mode',
		'lmi_sim_mode',
	));
	
	if (WebCash::DEBUG_SETTINGS) {
		$this->setCfgValue('currency', 'RUB');
		$this->setCfgValue('purse_rub', 'RXXXXXXXXX');
		$this->setCfgValue('secret_key_rub', 'XXXXXXX-XXXXXXX-XXXX-XXXX-XXXXXXXXXX');
		$this->setCfgValue('purse_usd', 'ZXXXXXXXXX');
		$this->setCfgValue('secret_key_usd', 'XXXXXXX-XXXXXXX-XXXX-XXXX-XXXXXXXXXX');
		$this->setCfgValue('test_mode', 1);
	}
	
	
	$result_url = $this->checkout->getGatewayProcessingUrl($this->alias);
	$success_url = $this->checkout->successCheckoutUrl(0, '', '&gw_alias='.$this->alias);
	$fail_url = $this->checkout->failCheckoutUrl();
	
	$this->addHint(__FILE__.'1', sprintf(__('Внимание, перед началом работы необходимо указать свои номера кошельков и секретные ключи. Также необходимо произвести настройку сайта по ссылке <a href="https://merchant.webmoney.ru/conf/purses.asp" target="_blank">https://merchant.webmoney.ru/conf/purses.asp</a>, обязательно указав там адрес для обработки запросов мерчанта: <a href="%s" target="_blank"><code>%s</code></a>. Также нужно отметить галочку &laquo;Позволять использовать URL, передаваемые в форме&raquo; (рекомендуется) или указать адреса оповещения о успешном или ошибочном завершении процесса оплаты, соответственно: &laquo;%s&raquo; и &laquo;%s&raquo;. В выпадающем списке &laquo;Метод формирования контрольной подписи&raquo; нужно выбрать &laquo;SHA256&raquo;. Для большей защищенности рекомендуется отметить галочку &laquo;Передавать параметры в предварительном запросе&raquo;.'), $result_url, $result_url, $success_url, $fail_url), false);
	
	
	
	$this->setFieldsItem('email_required', array(
		'title' => 'Требовать Емайл',
		'hint' => 'Если включено - то будет выполняться проверка на обязательное указание Емайл адреса плательщика',
		'type' => 'checkbox',
	));
	
	$this->setFieldsItem('test_mode', array(
		'title' => 'Включение тестового режима',
		'hint' => 'Если включено - то платеж выполняется в тестовом режиме, средства реально не переводятся',
		'type' => 'checkbox',
	));
	
	$this->setFieldsItem('lmi_sim_mode', array(
		'title' => 'Режим тестирования',
		'hint' => 'Действует только в режиме тестирования. Соответствует флагу &laquo;LMI_SIM_MODE&raquo; настроек Мерчанта, более подробную информацию можно получить в <a href="https://wiki.webmoney.ru/projects/webmoney/wiki/Web_Merchant_Interface" target="_blank">документации</a>.',
		'type' => 'select',
		'value' => array(0, 1, 2),
		'label' => array(__('Успешно для всех тестовых платежей'), __('Ошибка для всех тестовых платежей'), __('80% успешно, 20% с ошибкой для тестовых платежей')),		
	));
	
	$this->setFieldsItem('item_delete_button_confirm', array(
		'title' => 'Предупреждение перед удалением',
		'hint' => 'Если включено - то при удалении отдельной записи в списке при помощи кнопки, необходимо подтвердить действие',
		'type' => 'checkbox',
	));
	
	$this->setFieldsItem('date_format', array(
		'title' => 'Формат даты',
		'hint' => 'Используется, например, при выводе даты в списке, <a href="#" onclick="javascript:Help(\'date\'); return false;">помощь по работе функции</a>',
		'type' => 'text',
	));
	
	$this->setFieldsItem('site_url', array(
		'title' => 'Сайт провайдера',
		'hint' => 'Данный адрес используется в списке шлюзов только для удобства работы',
		'type' => 'text',
	));
	
	$this->convertDefaultValues();
	$this->writeSettingsInFile(true);
}