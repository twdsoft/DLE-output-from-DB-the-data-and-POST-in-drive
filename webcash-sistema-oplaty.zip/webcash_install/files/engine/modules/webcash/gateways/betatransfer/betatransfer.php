<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

if (!$this->readSettingsFromFile()) {
	$this->setCfgValue('display_name', 'Платежный шлюз Betatransfer');
	$this->setCfgValue('description', 'С помощью этого шлюза можно организовать прием платежей через платежную систему Betatransfer.');
	$this->setCfgValue('token', WebCash::DEBUG_SETTINGS ? '9e2cfcafa4f341eb4ef3c2917986b0e2' : '');
	$this->setCfgValue('secret_key', WebCash::DEBUG_SETTINGS ? 'd95adc3277f45a44201a2fe3b3e7c9b8' : '');
	$this->setCfgValue('language', 'ru');
	$this->setCfgValue('currency', 'RUB');
	$this->setCfgValue('site_url', 'https://betatransfer-merchant.com/');
	$this->setCfgValue('access_allowed_usergroups', array());
	$this->setNoneFormControlCfgValue('public_cfg_fields', array(
		'token',
		'language',
		'currency',
	));
	
	$this->addHint(__FILE__.'1', 'Внимание, перед началом работы необходимо зарегистрироваться на сайте <a href="https://betatransfer.io/" target="_blank">https://betatransfer.io/</a>, и скопировать публичный (токен) и секретный ключи в настройки плагина.');
	
	$this->setFieldsItem('token', array(
		'title' => 'Токен',
		'hint' => 'Токен полученный в системе &laquo;Betatransfer&raquo;. Узнать его можно в настройках личного кабинета.',
		'type' => 'text',
		'required' => true,
	));
	
	$this->setFieldsItem('secret_key', array(
		'title' => 'Секретный ключ',
		'hint' => 'Используется SCI (Betatransfer) при формировании цифровой подписи',
		'type' => 'text',
		'required' => true,
	));
	
	$this->setFieldsItem('language', array(
		'title' => 'Язык клиента',
		'hint' => 'Возможные значения: русский, английский, украинский',
		'type' => 'select',
		'value' => array('ru', 'en', 'uk'),
		'label' => array(__('Русский'), __('Английский'), __('Украинский')),
	));
	
	
	$arr = $this->wc_currency->getCurrenciesList();
	$arr = filter_allowed_keys($arr, array('RUB', 'USD', 'EUR', 'UAH'));
	
	$this->setFieldsItem('currency', array(
		'title' => 'Валюта аккаунта',
		'hint' => 'Валюта которая используется в аккаунте',
		'type' => 'select',
		'value' => array_keys($arr),
		'label' => array_values($arr),
		'required' => true,
	));
	
	$this->setFieldsItem('site_url', array(
		'title' => 'Сайт провайдера',
		'hint' => 'Данный адрес используется в списке шлюзов только для удобства работы',
		'type' => 'text',
	));
	
	
	$this->convertDefaultValues();
	$this->writeSettingsInFile(true);
}