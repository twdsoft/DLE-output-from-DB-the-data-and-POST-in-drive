<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

if (!$this->readSettingsFromFile()) {
	$this->setCfgValue('display_name', 'Платежный шлюз Qiwi');
	$this->setCfgValue('description', 'С помощью этого шлюза можно организовать прием платежей через платежную систему Qiwi.');
	$this->setCfgValue('public_key', WebCash::DEBUG_SETTINGS ? '48e786xn9T7RyYE1MVZswX1FRSbE6iyCj2gCRwwF3Dnh5XrasNTx3BGPiMsyXQFNKQhvukniQG8RTVhYm3iP6Zza2ABNmTrPaFzaTCNVkv1EH71v7kCkQDbXgDp4ckqtwrbzbiAgidCZP8bdQgKUU7dqU8E946Mhz8YVHR2hZ1K2SE5sVvJEtVZSFVE7i' : '');
	$this->setCfgValue('secret_key', WebCash::DEBUG_SETTINGS ? 'eyJ2ZXJzaW9uIjoiUDJQIiwiZGF0YSI6eyJwYXlp8а9tZXJjaGFudF9zaXRlX4VpZCI6IjkxaXU5bC0wMCIsInVzZXJfaWQiOiI3NzcxNTIxNTAzOSIsInNlY3JldCI6IjJjODFiNzk2YzYwNDk4MDhmMjg1NzE5OTU3Nzk4ZDhlMzFjN2Y4MGQwZjZjYWZjZWEzZWU5NjM3OTNlODNmMzcifX0=' : '');
	$this->setCfgValue('site_url', 'https://qiwi.com');
	$this->setCfgValue('access_allowed_usergroups', array());
	$this->setNoneFormControlCfgValue('public_cfg_fields', array(
		'public_key',
	));
	
	
	$result_url = $this->checkout->getGatewayProcessingUrl($this->alias);
	$success_url = $this->checkout->successCheckoutUrl(0, '', '&gw_alias='.$this->alias);
	$fail_url = $this->checkout->failCheckoutUrl();
	
	$this->addHint(__FILE__.'1', sprintf(__('Внимание, перед началом работы необходимо зарегистрироваться на сайте <a href="https://qiwi.com/p2p-admin/" target="_blank">https://qiwi.com/p2p-admin/</a>, и создав пару ключей (публичный и секретный), скопировать их в настройки плагина. В настройках личного кабинета необходимо указать URL для серверных уведомлений: <a href="%s" target="_blank"><code>%s</code></a>. Чтобы это сделать, надо отметить галочку &laquo;Использовать эту пару ключей для серверных уведомлений об изменении статусов счетов&raquo;.'), $result_url, $result_url), false);
	
	$this->setFieldsItem('public_key', array(
		'title' => 'Публичный ключ',
		'hint' => 'Публичный ключ позволяет выставить счет и открыть форму переводов. Получить его можно в <a href="https://qiwi.com/p2p-admin/transfers/api" target="_blank">личном кабинете Qiwi</a>',
		'type' => 'text',
		'required' => true,
	));
	
	$this->setFieldsItem('secret_key', array(
		'title' => 'Секретный ключ',
		'hint' => 'Секретный ключ нужен для обмена информацией между вашим сервисом и QIWI. Получить его можно в <a href="https://qiwi.com/p2p-admin/transfers/api" target="_blank">личном кабинете Qiwi</a>',
		'type' => 'text',
		'required' => true,
	));
	
	$this->setFieldsItem('site_url', array(
		'title' => 'Сайт провайдера',
		'hint' => 'Данный адрес используется в списке шлюзов только для удобства работы',
		'type' => 'text',
	));
	
	
	$this->convertDefaultValues();
	$this->writeSettingsInFile(true);
}