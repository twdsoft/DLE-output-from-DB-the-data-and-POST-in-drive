<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

if (!$this->readSettingsFromFile()) {
	$this->setCfgValue('display_name', 'Платежный шлюз Skrill');
	$this->setCfgValue('description', 'С помощью этого шлюза можно организовать прием платежей через платежную систему Skrill.');
	$this->setCfgValue('skrill_account', WebCash::DEBUG_SETTINGS ? 'muzvideo70@gmail.com' : '');
	$this->setCfgValue('currency', 'USD');
	$this->setCfgValue('test_mode', WebCash::DEBUG_SETTINGS ? 1 : 0);
	$this->setCfgValue('site_url', 'https://skrill.com');
	$this->setCfgValue('access_allowed_usergroups', array());
	$this->setNoneFormControlCfgValue('public_cfg_fields', array(
		'skrill_account',
		'currency',
		'test_mode',
	));
	
	
	$str = $this->checkout->getGatewayProcessingUrl($this->alias);
	
	$this->addHint(__FILE__.'1', 'Внимание, перед началом работы необходимо указать логин Skrill (адрес почты), на который будут приниматься платежи. Адрес обработки запросов от мерчанта: <a href="'.$str.'" target="_blank"><code>'.$str.'</code></a>.');

	$this->setFieldsItem('skrill_account', array(
		'title' => 'Ваш логин Skrill',
		'hint' => 'Логин Skrill (адрес почты), на который будут приниматься платежи',
		'type' => 'text',
		'required' => true,
	));
	
	$arr = $this->wc_currency->getCurrenciesList();
	
	$this->setFieldsItem('currency', array(
		'title' => 'Валюта аккаунта',
		'hint' => 'Валюта которая используется в аккаунте Skrill',
		'type' => 'select',
		'value' => array_keys($arr),
		'label' => array_values($arr),
		'required' => true,
	));
	
	$this->setFieldsItem('test_mode', array(
		'title' => 'Включение тестового режима',
		'hint' => 'Если включено - то платеж выполняется в тестовом режиме, средства реально не переводятся',
		'type' => 'checkbox',
	));
	
	$this->setFieldsItem('site_url', array(
		'title' => 'Сайт провайдера',
		'hint' => 'Данный адрес используется в списке шлюзов только для удобства работы',
		'type' => 'text',
	));
	
	
	$this->convertDefaultValues();
	$this->writeSettingsInFile(true);
}