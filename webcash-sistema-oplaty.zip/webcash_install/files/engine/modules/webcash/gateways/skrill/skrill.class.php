<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

class Gateways_Skrill extends AddonSettings
{
	protected $alias = 'skrill';
	
    public function renderPaymentForm($invoice_id, $cs_key, $gw_item_id) {
		if ($str = $this->verifyGatewayEnable())
			return $str;
		
		if (!$checkout_store = $this->checkout->getDataStore($cs_key))
			return '';
		
		$service_info = $this->getServiceInfo();
		
		if (!$gw_item = safe_array_access($service_info, 'items', $gw_item_id))
			trigger_error(basename(__FILE__).', line: '.__LINE__, E_USER_ERROR);
		
		$amount = $this->wc_currency->convertMainCurrencyTo($checkout_store['amount'], $this->currency);
		
		$tpl = $this->webcash->getTplInstance();
		$tpl->assign('invoice_id', $invoice_id);
		$tpl->assign('amount', $amount);
		$email = $this->helper->htmlspecialchars(safe_array_access($checkout_store, 'email'));
		$tpl->assign('email', $email);
		
		
		//LASTDELETE ?
		$tpl->assign('processing_url', $this->checkout->getGatewayProcessingUrl($this->alias));
		$tpl->assign('success_url', $this->checkout->successCheckoutUrl($invoice_id, $cs_key));
		$tpl->assign('fail_url', $this->checkout->failCheckoutUrl($invoice_id, $cs_key));
		
		
		$tpl->assign('gateway_header', $service_info['name']);
		$tpl->assign('gw_alias', $this->alias);
		$tpl->assign('gateway_cfg', $this->getCfgPublicParams());
		$tpl->assign('addon_settings_link', $this->renderAddonSettingsLink());
		$tpl->assign('user_hash', $this->user->nonce);
		
		$tpl->assign('url', $this->serviceUrl());
        // Payment data.
        $data = array();

        // Merchant Details
        $data['pay_to_email']           = $this->skrill_account;
        $data['transaction_id']         = $invoice_id;
        $data['return_url']             = $this->checkout->successCheckoutUrl($invoice_id, $cs_key);
        $data['cancel_url']             = $this->checkout->failCheckoutUrl($invoice_id, $cs_key);
        $data['status_url']             = $this->checkout->getGatewayProcessingUrl($this->alias);
		$data['detail1_description']	= to_utf8(safe_array_access($checkout_store, 'checkout_header'));
		//$data['detail1_text']			= 'detail1_text';
			//$data['redirect_url']           = $this->config['redirect_url'];
        // Payment Details
        $data['currency']               = $this->currency;
        $data['amount']                 = number_format($amount, 2, '.', '');
        // Customer Details
        $data['pay_from_email']         = $email;
		$tpl->assign('data', $data);

		
		$tpl->load_template('/modules/webcash/gateways/skrill/checkout.tpl');
		
		$tpl->compile('content');
		
		return $tpl->result['content'];
	}
	
    public function verifyTransaction($source_array) {
		if (WebCash::DEBUG_SETTINGS)
			return true;
		
		// read the post from PayPal system and add 'cmd'
		$req = 'cmd=_notify-validate';
		
		foreach ($source_array as $key => $value) {
			$value = urlencode(stripslashes($value));
			$req .= "&{$key}={$value}";
		}

        $url = $this->serviceUrl();
        $ret = $this->download($url, $req);
        return $ret == 'VERIFIED';
	}
	
	public function processing() {
		if (!empty($_POST)) {
			$this->readSettingsFromFile();
			//fs_log($_POST); print2($_POST);
			$invoice_id = (int)GET('bb_invoice_id');
			
			if (!$invoice_row = $this->webcash->getRowById($this->webcash->gateway_invoices_table, $invoice_id)) {
				$this->printError('Нет такого инвойса');
			}
			
			if ($invoice_row['state']) {
				$this->printError('Инвойс уже оплачен');
			}

			if ($invoice_row['gateway'] != $this->alias) {
				$this->printError('Инвойс не той платежной системы');
			}
			
			if (!POST('mb_amount')) {
				$this->printError('Нулевая сумма.');
			} elseif (POST('mb_amount') < $invoice_row['amount']) {
				$this->printError('Неверная сумма: '.POST('mb_amount'));
			} elseif (POST('mb_currency') != $this->currency) {
				$this->printError('Неверная валюта платежа: '.POST('mb_currency'));
			} elseif (POST('status') !== '2') {
				$this->printError('Неверный статус платежа: '.POST('status'));
			//} elseif (POST('txn_type') !== 'web_accept') {
				//$this->printError('Неверный тип платежа: '.POST('txn_type'));
			} elseif (POST('pay_to_email') != $this->skrill_account) {
				$this->printError('Неверный получатель платежа: '.POST('receiver_email'));
			}

			
			if (!$this->verifyTransaction($_POST)) {
				$this->printError('Транзакция не подтверждена');
			}
			
			
			$payment_id = $this->processAfterPayment($invoice_id);
			
			if ($payment_row = $this->webcash->getRowById($this->webcash->gateway_payments_table, $payment_id)) {
				$this->checkout->gatewaySuccessPayment($invoice_row, $payment_row);

				//fs_log("Инвойс #" . $invoice_id . " оплачен!");
				
				echo 'Invoice #'.$invoice_id.' successfully paid';
				exit;
			}

			$this->printError('Error '.__LINE__);
		} else {
			$this->webcash->siteMsgError('Не указаны необходимые данные');
		}
	}
	
	public function printError($text) {
		$text = 'Ошибка! '.$text;
		//fs_log('Merchant error ('.$this->alias.'): '.$text);
		header('HTTP/1.1 500 Internal Server Error');
		echo $text;
		exit;
	}
	
	public function processAfterPayment($invoice_id) {
		$gateway_details_arr = array(
			'payer_id' => POST('payer_id'),
			'payer_status' => POST('payer_status'),
			'payer_email' => POST('payer_email'),
			'receiver_id' => POST('receiver_id'),
			'address_country' => POST('address_country'),
			'address_city' => POST('address_city'),
			'address_street' => POST('address_street'),
			'address_status' => POST('address_status'),
			'payment_date' => POST('payment_date'),
			'payment_status' => POST('payment_status'),
			'payment_fee' => POST('payment_fee'),
			'mc_gross' => POST('mc_gross'),
			'mc_currency' => POST('mc_currency'),
			'txn_id' => POST('txn_id'),
			'ipn_track_id' => POST('ipn_track_id'),
		);
		
		$gateway_details_arr = array_map(array($this->helper, 'htmlspecialchars'), $gateway_details_arr);
		
		return $this->checkout->addPaymentToDb($invoice_id, POST('payer_email'), $gateway_details_arr);
	}

    private function serviceUrl(){
        return $this->test_mode ? 'https://www.skrill.com/app/test_payment.pl' : 'https://www.skrill.com/app/payment.pl';
    }
	
    private function download($url, $post_vars = false, $phd = array(), $contentType = 'application/x-www-form-urlencoded')
    {
        $post_contents = '';
        if ($post_vars) {
            if (is_array($post_vars)) {
                foreach($post_vars as $key => $val) {
                    $post_contents .= ($post_contents ? '&' : '').urlencode($key).'='.urlencode($val);
                }
            } else {
                $post_contents = $post_vars;
            }
        }

        $uinf = parse_url($url);
        $host = $uinf['host'];
        $path = $uinf['path'];
        $path .= (isset($uinf['query']) && $uinf['query']) ? ('?'.$uinf['query']) : '';

        $headers = Array(
            ($post_contents ? 'POST' : 'GET')." $path HTTP/1.1",
            "Host: $host",
            'Connection: Close',
            'User-Agent: BoxBilling'
        );
        if (!empty($phd)) {
            if (!is_array($phd)) {
                $headers[count($headers)] = $phd;
            } else {
                $next = count($headers);
                $count = count($phd);
                for ($i = 0; $i < $count; $i++) { $headers[$next + $i] = $phd[$i]; }
            }
        }
        if ($post_contents) {
            $headers[] = "Content-Type: $contentType";
            $headers[] = 'Content-Length: '.strlen($post_contents);
        }

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_URL,$url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_TIMEOUT, 600);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        // Apply the XML to our curl call
        if ($post_contents) {
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post_contents);
        }

        $data = curl_exec($ch);
        if (curl_errno($ch)) return false;
        curl_close($ch);

        return $data;
    }
	
	public function getServiceInfo() {
		$result = array(
			'name' => 'Skrill',
			'alias' => $this->alias,
			'items' => array(
				1 => array(
					'title' => __('Различные способы'),
					'image' => 'skrill.png',
				),
			),
		);
		
		return $result;
	}

}