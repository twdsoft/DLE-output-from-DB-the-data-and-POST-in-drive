<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

class Gateways_Liqpay extends AddonSettings
{
    const API_URL = 'https://www.liqpay.ua/api/';
    const CHECKOUT_URL = 'https://www.liqpay.ua/api/3/checkout';
    const VERSION = 3;
	
	protected $alias = 'liqpay';
	
    public function renderPaymentForm($invoice_id, $cs_key, $gw_item_id) {
		if ($str = $this->verifyGatewayEnable())
			return $str;
		
		if (!$checkout_store = $this->checkout->getDataStore($cs_key))
			return '';
		
		$service_info = $this->getServiceInfo();
		
		if (!$gw_item = safe_array_access($service_info, 'items', $gw_item_id))
			trigger_error(basename(__FILE__).', line: '.__LINE__, E_USER_ERROR);
		
		$amount = $this->wc_currency->convertMainCurrencyTo($checkout_store['amount'], $this->currency);
		$payment_desc = $this->webcash->site_url.' - '.to_utf8(safe_array_access($checkout_store, 'checkout_header'));
		//$payment_desc = $this->webcash->site_url.' - TEST PAYMENT';
		$params = array(
			'version' => self::VERSION,
			'action' => 'pay',
			'amount' => $amount,
			'currency' => $this->currency,
			'description' => $payment_desc,
			'order_id' => $invoice_id,
			'language' => $this->language,
			'result_url' => $this->checkout->successCheckoutUrl($invoice_id, $cs_key),
			'server_url' => $this->checkout->getGatewayProcessingUrl($this->alias),
		);
		
        $signature = $this->signData($params);
        
		$params = $this->cnbParams($params);
        $data = $this->encodeParams($params);
		
		$tpl = $this->webcash->getTplInstance();
		$tpl->assign('invoice_id', $invoice_id);
		$tpl->assign('amount', number_format($amount, 2, '.', ''));
		$tpl->assign('payment_desc', $payment_desc);
		$tpl->assign('email', $this->helper->htmlspecialchars(safe_array_access($checkout_store, 'email')));
		$tpl->assign('checkout_url', self::CHECKOUT_URL);
		$tpl->assign('data', $data);
		$tpl->assign('signature', $signature);
		$tpl->assign('gateway_header', $service_info['name']);
		$tpl->assign('gw_alias', $this->alias);
		$tpl->assign('gateway_cfg', $this->getCfgPublicParams());
		$tpl->assign('addon_settings_link', $this->renderAddonSettingsLink());
		$tpl->assign('user_hash', $this->user->nonce);
		$tpl->load_template('/modules/webcash/gateways/liqpay/checkout.tpl');
		
		$tpl->compile('content');
		
		return $tpl->result['content'];
	}
	
	public function signData($params) {
        $params = $this->cnbParams($params);

        $str = $this->encodeParams($params);
        $signature = $this->strToSign($str);

        return $signature;
	}
	
	public function processing() {
		if ($data_str = POST('data') and POST('signature')) {
			$this->readSettingsFromFile();
			
			$signature = $this->strToSign($data_str);
			
			if (POST('signature') != $signature) {
				$this->printError('Неверная подпись '.POST('signature'));
			}
			
			if (!$json = $this->decodeParams($data_str)) {
				$this->printError('Ошибочные данные');
			}
			
			$invoice_id = (int)safe_array_access($json, 'order_id');
			
			if (!$invoice_row = $this->webcash->getRowById($this->webcash->gateway_invoices_table, $invoice_id)) {
				$this->printError('Нет такого инвойса');
			}
			
			if ($invoice_row['state']) {
				$this->printError('Инвойс уже оплачен');
			}

			if ($invoice_row['gateway'] != $this->alias) {
				$this->printError('Инвойс не той платежной системы');
			}
			
			if ($invoice_row['amount'] > safe_array_access($json, 'amount')) {
				$this->printError('Неверная сумма: '.safe_array_access($json, 'amount'));
			}
			
			
			$payment_id = $this->processAfterPayment($invoice_id, $json);
			
			
			if ($payment_row = $this->webcash->getRowById($this->webcash->gateway_payments_table, $payment_id)) {
				$this->checkout->gatewaySuccessPayment($invoice_row, $payment_row);

				//fs_log("Инвойс #" . $invoice_id . " оплачен!");
				exit;
			}

			$this->printError('Error '.__LINE__);
		} else {
			$this->printError('Не указаны необходимые данные');
		}
	}
	
	public function printError($text) {
		$text = 'Ошибка! '.$text;
		//fs_log('Merchant error ('.$this->alias.'): '.$text);
		//echo $text;
		exit;
	}
	
	public function processAfterPayment($invoice_id, $json) {
		$gateway_details_arr = POST();
		$gateway_details_arr = array_map(array($this->helper, 'htmlspecialchars'), $gateway_details_arr);
		if (!$sender = safe_array_access($json, 'customer'))
			$sender = safe_array_access($json, 'sender_first_name');		
		
		return $this->checkout->addPaymentToDb($invoice_id, $sender, $gateway_details_arr);
	}
	
	public function getServiceInfo() {
		$result = array(
			'name' => __('Liqpay'),
			'alias' => $this->alias,
			'items' => array(
				1 => array(
					'title' => __('Перейти к оплате'),
					'image' => 'liqpay.png',
				),
			),
		);
		
		return $result;
	}

    private function cnbParams($params) {
		$params['public_key'] = $this->public_key;
		
		if (empty($params['version']))
			trigger_error('version is null', E_USER_ERROR);
		if (empty($params['amount']))
			trigger_error('amount is null', E_USER_ERROR);
		if (empty($params['currency']))
			trigger_error('currency is null', E_USER_ERROR);
		if ($params['currency'] != $this->currency)
			trigger_error('currency is not supported', E_USER_ERROR);
		if (empty($params['description']))
			trigger_error('description is null', E_USER_ERROR);
		
		return $params;
    }
	
    private function encodeParams($params) {
		return base64_encode(json_encode($params));
		//return base64_encode(json_encode($params, JSON_UNESCAPED_SLASHES + JSON_UNESCAPED_UNICODE));
    }
	
    private function decodeParams($params_str) {
		return json_decode(base64_decode($params_str), true);
    }
	
    private function strToSign($str) {
		$str = $this->private_key.$str.$this->private_key;
		$signature = base64_encode(sha1($str, true));
		return $signature;
    }
	
}