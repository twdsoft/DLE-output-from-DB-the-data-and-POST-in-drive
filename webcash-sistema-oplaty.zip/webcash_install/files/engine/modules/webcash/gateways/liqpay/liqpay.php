<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

if (!$this->readSettingsFromFile()) {
	$this->setCfgValue('display_name', 'Платежный шлюз Liqpay');
	$this->setCfgValue('description', 'С помощью этого шлюза можно организовать прием платежей через платежную систему Liqpay.');
	$this->setCfgValue('public_key', '');
	$this->setCfgValue('private_key', '');
	$this->setCfgValue('language', 'ru');
	$this->setCfgValue('currency', 'USD');
	$this->setCfgValue('site_url', 'https://liqpay.ua');
	$this->setCfgValue('access_allowed_usergroups', array());
	$this->setNoneFormControlCfgValue('public_cfg_fields', array(
		'language',
	));
	
	if (WebCash::DEBUG_SETTINGS) {
		$this->setCfgValue('public_key', 'ArgZeU5SNYMqap');
		$this->setCfgValue('private_key', 'X6S7LDtNJQjyJdFxC0rPLIGHhl544fwEJ');
	}
	
	
	$str = $this->checkout->getGatewayProcessingUrl($this->alias);
	
	$this->addHint(__FILE__.'1', 'Внимание, перед началом работы необходимо зарегистрироваться на сайте <a href="https://www.liqpay.ua/" target="_blank">https://www.liqpay.ua/</a>, затем создать магазин в Вашем аккаунте <a href="https://www.liqpay.ua/admin/business" target="_blank">https://www.liqpay.ua/admin/business</a>, и получить публичный и приватный ключи. Адрес обработки запросов от мерчанта: <a href="'.$str.'" target="_blank"><code>'.$str.'</code></a>.');
	
	$this->setFieldsItem('public_key', array(
		'title' => 'Публичный ключ - идентификатор магазина',
		'hint' => 'Публичный ключ - идентификатор магазина. Получить ключ можно в <a href="https://www.liqpay.ua/ru/adminbusiness" target="_blank">настройках магазина</a>',
		'type' => 'text',
		'required' => true,
	));
	
	$this->setFieldsItem('private_key', array(
		'title' => 'Секретный ключ',
		'hint' => 'Секретный ключ магазина. Получить ключ можно в <a href="https://www.liqpay.ua/ru/adminbusiness" target="_blank">настройках магазина</a>',
		'type' => 'text',
		'required' => true,
	));

	$this->setFieldsItem('language', array(
		'title' => 'Язык клиента',
		'hint' => 'Возможные значения: русский, украинский, английский',
		'type' => 'select',
		'value' => array('ru', 'uk', 'en'),
		'label' => array(__('Русский'), __('Украинский'), __('Английский')),
	));
	
	$arr = $this->wc_currency->getCurrenciesList();
	
	$this->setFieldsItem('currency', array(
		'title' => 'Валюта аккаунта',
		'hint' => 'Валюта которая используется в аккаунте Liqpay',
		'type' => 'select',
		'value' => array_keys($arr),
		'label' => array_values($arr),
		'required' => true,
	));
	
	$this->setFieldsItem('site_url', array(
		'title' => 'Сайт провайдера',
		'hint' => 'Данный адрес используется в списке шлюзов только для удобства работы',
		'type' => 'text',
	));
	
	
	$this->convertDefaultValues();
	$this->writeSettingsInFile(true);
}