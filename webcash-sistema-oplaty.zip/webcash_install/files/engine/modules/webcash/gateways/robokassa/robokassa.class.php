<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

class Gateways_RoboKassa extends AddonSettings
{
	protected $alias = 'robokassa';
    
	public function renderPaymentForm($invoice_id, $cs_key, $gw_item_id) {
		if ($str = $this->verifyGatewayEnable())
			return $str;
		
		if (!$checkout_store = $this->checkout->getDataStore($cs_key))
			return '';
		
		$service_info = $this->getServiceInfo();
		
		if (!$gw_item = safe_array_access($service_info, 'items', $gw_item_id))
			trigger_error(basename(__FILE__).', line: '.__LINE__, E_USER_ERROR);
		
		$amount = $this->wc_currency->convertMainCurrencyTo($checkout_store['amount'], $this->currency);
		$amount = number_format($amount, 2, '.', '');
		$payment_desc = ($this->webcash->site_url.' - '.to_utf8(safe_array_access($checkout_store, 'checkout_header')));
		
		$tpl = $this->webcash->getTplInstance();
		$tpl->assign('amount', $amount);
		$tpl->assign('invoice_id', $invoice_id);
		$tpl->assign('description', $payment_desc);
		
		$params = array(
			$this->merchant_login,
			$amount,
			$invoice_id,
		);
		
		if ($this->currency != 'RUB')
			$params[] = $this->currency;
		
		$params[] = $this->secret_key1;
		
		$tpl->assign('signature', $this->signData($params));
		$tpl->assign('email', $this->helper->htmlspecialchars(safe_array_access($checkout_store, 'email')));
		
		$tpl->assign('gw_item_id', $gw_item_id);
		$tpl->assign('gw_item', $gw_item);
		$tpl->assign('gateway_header', $service_info['name']);
		$tpl->assign('gw_alias', $this->alias);
		$tpl->assign('gateway_cfg', $this->getCfgPublicParams());
		$tpl->assign('addon_settings_link', $this->renderAddonSettingsLink());
		$tpl->assign('user_hash', $this->user->nonce);
		$tpl->load_template('/modules/webcash/gateways/robokassa/checkout.tpl');
		
		$tpl->compile('content');
		
		return $tpl->result['content'];
	}
	
	public function signData($params) {
		return strtoupper(hash('md5', implode(':', $params)));
	}
	
	public function processing() {
		// проверка на наличие обязательных полей
		foreach(array(
			'OutSum',
			'InvId',
			'SignatureValue',
		) as $key => $field) {
			if (!POST($field)) {
				$this->printError('Не указаны обязательные данные');
			}
		}
		
		// нормализация данных
		$amount = only_float($_POST['OutSum']);
		$invoice_id = (int)$_POST['InvId'];
		
		// проверка значения сигнатуры
		$params = array(
			$amount,
			$invoice_id,
			$this->secret_key2,
		);
		$signature = $this->signData($params);
		
		if ($_POST['SignatureValue'] != $signature) {
			$this->printError('Неверная подпись '.$_POST['SignatureValue']);
		}
		
		
		$this->readSettingsFromFile();
		
		if (!$invoice_row = $this->webcash->getRowById($this->webcash->gateway_invoices_table, $invoice_id)) {
			$this->printError('Нет такого инвойса');
		}
		
		if ($invoice_row['state']) {
			$this->printError('Инвойс уже оплачен');
		}

		if ($invoice_row['gateway'] != $this->alias) {
			$this->printError('Инвойс не той платежной системы');
		}
		
		if ($invoice_row['amount'] > $amount) {
			$this->printError('Неверная сумма: '.$amount);
		}
		
		
		$sender = $invoice_row['email'];
		
		$payment_id = $this->processAfterPayment($invoice_id, $sender);
		
		
		if ($payment_row = $this->webcash->getRowById($this->webcash->gateway_payments_table, $payment_id)) {
			$this->checkout->gatewaySuccessPayment($invoice_row, $payment_row);

			//fs_log("Инвойс #" . $invoice_id . " оплачен!");
			exit("OK{$invoice_id}\n");// успешный ответ для платежного шлюза и завершение скрипта
		}
		
		echo $_POST['m_orderid'].'|error';
		
		$this->printError('Error '.__LINE__);
	}
	
	public function printError($text) {
		$text = 'Ошибка! '.$text;
		if (WebCash::DEBUG_SETTINGS) {
			fs_log('Merchant error ('.$this->alias.'): '.$text);
			echo $text;
		}
		
		exit;
	}
	
	public function processAfterPayment($invoice_id, $sender) {
		$gateway_details_arr = POST();
		$gateway_details_arr = array_map(array($this->helper, 'htmlspecialchars'), $gateway_details_arr);
		
		return $this->checkout->addPaymentToDb($invoice_id, $sender, $gateway_details_arr);
	}
	
	public function getServiceInfo() {
		$result = array(
			'name' => __('Robokassa'),
			'alias' => $this->alias,
			'items' => array(
				1 => array(
					'title' => __('Перейти к оплате'),
					'image' => 'robokassa.png',
				),
			),
		);
		
		return $result;
	}

}