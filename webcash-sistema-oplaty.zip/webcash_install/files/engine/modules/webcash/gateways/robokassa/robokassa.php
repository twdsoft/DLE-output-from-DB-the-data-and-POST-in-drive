<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

if (!$this->readSettingsFromFile()) {
	$this->setCfgValue('display_name', 'Платежный шлюз Robokassa');
	$this->setCfgValue('description', 'С помощью этого шлюза можно организовать прием платежей через платежную систему Robokassa.');
	$this->setCfgValue('merchant_login', WebCash::DEBUG_SETTINGS ? 'phpphpru' : '');
	$this->setCfgValue('secret_key1', WebCash::DEBUG_SETTINGS ? 'fnqHh7soU2b1a6lIZw5U' : '');
	$this->setCfgValue('secret_key2', WebCash::DEBUG_SETTINGS ? 'c44qLbqeZybIBUO5c1H2' : '');
	$this->setCfgValue('language', 'ru');
	$this->setCfgValue('currency', 'USD');
	$this->setCfgValue('test_mode', DEBUG_SETTINGS ? 1 : 0);
	$this->setCfgValue('site_url', 'https://robokassa.com');
	$this->setCfgValue('access_allowed_usergroups', array());
	$this->setNoneFormControlCfgValue('public_cfg_fields', array(
		'merchant_login',
		'language',
		'currency',
		'test_mode',
	));
	
	
	$result_url = $this->checkout->getGatewayProcessingUrl($this->alias);
	$success_url = $this->checkout->successCheckoutUrl(0, '', '&gw_alias='.$this->alias);
	$fail_url = $this->checkout->failCheckoutUrl();
	
	$this->addHint(__FILE__.'1', sprintf(__('Внимание, перед началом работы необходимо зарегистрироваться на сайте <a href="https://robokassa.com/" target="_blank">https://robokassa.com/</a>, и создав магазин, скопировать идентификатор магазина и пару секретных ключей в настройки плагина. В настройках магазина, кроме других обязательных полей, необходимо выбрать в поле &laquo;Алгоритм расчета хеша&raquo; - MD5, везде методом отсылки данных выбрать - &laquo;POST&raquo;, указать Success Url: <b>%s</b>, Fail Url: <b>%s</b>, Result Url: <a href="%s" target="_blank"><code>%s</code></a>.'), $success_url, $fail_url, $result_url, $result_url), false);
	
	$this->setFieldsItem('merchant_login', array(
		'title' => 'Идентификатор магазина',
		'hint' => 'Идентификатор магазина в Robokassa, который Вы придумали при <a href="https://docs.robokassa.ru/#1140">создании магазина</a>',
		'type' => 'text',
		'required' => true,
	));
	
	$this->setFieldsItem('secret_key1', array(
		'title' => 'Секретный ключ #1',
		'hint' => 'Секретный ключ #1 из <a href="https://partner.robokassa.ru/Shops" target="_blank">настроек магазина в Robokassa</a>',
		'type' => 'text',
		'required' => true,
	));
	
	$this->setFieldsItem('secret_key2', array(
		'title' => 'Секретный ключ #2',
		'hint' => 'Секретный ключ #2 из <a href="https://partner.robokassa.ru/Shops" target="_blank">настроек магазина в Robokassa</a>',
		'type' => 'text',
		'required' => true,
	));
	
	$this->setFieldsItem('language', array(
		'title' => 'Язык клиента',
		'hint' => 'Возможные значения: русский, английский',
		'type' => 'select',
		'value' => array('ru', 'en'),
		'label' => array(__('Русский'), __('Английский')),
	));
	
	$arr = $this->wc_currency->getCurrenciesList();
	$arr = filter_allowed_keys($arr, array('RUB', 'USD', 'EUR'));
	
	$this->setFieldsItem('currency', array(
		'title' => 'Валюта аккаунта',
		'hint' => 'Валюта которая используется в аккаунте',
		'type' => 'select',
		'value' => array_keys($arr),
		'label' => array_values($arr),
		'required' => true,
	));
	
	$this->setFieldsItem('test_mode', array(
		'title' => 'Включение тестового режима',
		'hint' => 'Если включено - то платеж выполняется в тестовом режиме, средства реально не переводятся',
		'type' => 'checkbox',
	));
	
	$this->setFieldsItem('site_url', array(
		'title' => 'Сайт провайдера',
		'hint' => 'Данный адрес используется в списке шлюзов только для удобства работы',
		'type' => 'text',
	));
	
	
	$this->convertDefaultValues();
	$this->writeSettingsInFile(true);
}