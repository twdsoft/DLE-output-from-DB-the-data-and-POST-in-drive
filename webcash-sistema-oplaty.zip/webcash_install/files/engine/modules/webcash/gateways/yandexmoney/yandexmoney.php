<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

if (!$this->readSettingsFromFile()) {
	$this->setCfgValue('display_name', 'Платежный шлюз Yoomoney');
	$this->setCfgValue('description', 'С помощью этого шлюза можно организовать прием платежей через платежную систему Yoomoney.');
	$this->setCfgValue('receiver', '');//Номер кошелька
	$this->setCfgValue('notification_secret', '');
	$this->setCfgValue('quickpay_form', 'small');
	$this->setCfgValue('site_url', 'https://yoomoney.ru');
	$this->setCfgValue('access_allowed_usergroups', array());
	$this->setNoneFormControlCfgValue('public_cfg_fields', array(
		'receiver',
		'quickpay_form',
	));
	
	if (WebCash::DEBUG_SETTINGS) {
		$this->setCfgValue('receiver', 'XXXXXXXXXXXXXXX');
		$this->setCfgValue('notification_secret', 'XXXXXXXXXXXXXXXXXXXXXXXXXXXX');
	}
	
	
	$str = $this->checkout->getGatewayProcessingUrl($this->alias);
	
	$this->addHint(__FILE__.'1', 'Внимание, перед началом работы необходимо указать свой номер кошелька и секретное слово, которое можно получить по ссылке <a href="https://yoomoney.ru/transfer/myservices/http-notification" target="_blank">https://yoomoney.ru/transfer/myservices/http-notification</a>, указав там адрес для получения HTTP-уведомлений. Адрес обработки запросов от мерчанта: <a href="'.$str.'" target="_blank"><code>'.$str.'</code></a>.');
	
	$this->setFieldsItem('receiver', array(
		'title' => 'Номер кошелька',
		'hint' => 'Номер кошелька для приема оплаты',
		'type' => 'text',
		'required' => true,
	));
	
	$this->setFieldsItem('notification_secret', array(
		'title' => 'Секретное слово',
		'hint' => 'Секретное слово для проверки уведомлений',
		'type' => 'text',
		'required' => true,
	));

	$this->setFieldsItem('quickpay_form', array(
		'title' => 'Тип транзакции',
		'hint' => 'Возможные значения: для универсальной формы (shop), для &laquo;благотворительной&raquo; формы (donate), для кнопки (small)',
		'type' => 'select',
		'value' => array('shop', 'donate', 'small'),
		'label' => array(__('Для универсальной формы'), __('Для &laquo;благотворительной&raquo; формы'), __('Для кнопки')),
	));
	
	$this->setFieldsItem('site_url', array(
		'title' => 'Сайт провайдера',
		'hint' => 'Данный адрес используется в списке шлюзов только для удобства работы',
		'type' => 'text',
	));
	
	
	$this->convertDefaultValues();
	$this->writeSettingsInFile(true);
}