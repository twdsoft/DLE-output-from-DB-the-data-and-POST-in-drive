<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

class Gateways_YandexMoney extends AddonSettings
{
	const CURRENCY = 'RUB';
	
	protected $alias = 'yandexmoney';
	
    public function renderPaymentForm($invoice_id, $cs_key, $gw_item_id) {
		if ($str = $this->verifyGatewayEnable())
			return $str;
		
		if (!$checkout_store = $this->checkout->getDataStore($cs_key))
			return '';
		
		$service_info = $this->getServiceInfo();
		
		if (!$gw_item = safe_array_access($service_info, 'items', $gw_item_id))
			trigger_error(basename(__FILE__).', line: '.__LINE__, E_USER_ERROR);
		
		$amount = $this->wc_currency->convertMainCurrencyTo($checkout_store['amount'], self::CURRENCY);
		$payment_desc = $this->webcash->site_url.' - '.to_utf8(safe_array_access($checkout_store, 'checkout_header'));
		
		$tpl = $this->webcash->getTplInstance();
		$tpl->assign('invoice_id', $invoice_id);
		$tpl->assign('amount', number_format($amount, 2, '.', ''));
		$tpl->assign('payment_desc', $payment_desc);
		$tpl->assign('email', $this->helper->htmlspecialchars(safe_array_access($checkout_store, 'email')));
		$tpl->assign('success_url', $this->checkout->successCheckoutUrl($invoice_id, $cs_key));
		$tpl->assign('gw_item_id', $gw_item_id);
		$tpl->assign('gw_item', $gw_item);
		$tpl->assign('gateway_header', $service_info['name']);
		$tpl->assign('gw_alias', $this->alias);
		$tpl->assign('gateway_cfg', $this->getCfgPublicParams());
		$tpl->assign('addon_settings_link', $this->renderAddonSettingsLink());
		$tpl->assign('user_hash', $this->user->nonce);
		$tpl->load_template('/modules/webcash/gateways/yandexmoney/checkout.tpl');
		
		$tpl->compile('content');
		
		return $tpl->result['content'];
	}
	
	public function signData() {
		if (!empty($_POST)) {
			$params = 'notification_type&operation_id&amount&currency&datetime&sender&codepro';

			$params = explode('&', $params);
			$for_hash = array();
			
			foreach ($params as $p) {
				array_push($for_hash, POST($p));
			}

			array_push($for_hash, $this->notification_secret);
			array_push($for_hash, POST('label'));

			$str = implode('&', $for_hash);
			$hash = hash('sha1', $str);
			return $hash;
		}
	}
	
	public function getAmountDue($sum, $notification_type) {
		$result = $sum;
		
		if ($notification_type == 'p2p-incoming')
			$result = $sum - $sum * (0.005 / (1 + 0.005));
		elseif ($notification_type == 'card-incoming')
			$result = $sum * (1 - 0.02);
			
		$result = round($result, 2);
		
		return $result;
	}
	
	public function processing() {
		if (POST('notification_type') and POST('operation_id') and POST('amount') and POST('withdraw_amount') and POST('datetime') and POST('label') and POST('sha1_hash')) {
			$this->readSettingsFromFile();
			
			$sign_hash = $this->signData();
			
			if (POST('sha1_hash') != $sign_hash) {
				$this->printError('Неверная подпись '.POST('sha1_hash'));
			}

			
			$invoice_id = (int)POST('label');
			
			if (!$invoice_row = $this->webcash->getRowById($this->webcash->gateway_invoices_table, $invoice_id)) {
				$this->printError('Нет такого инвойса');
			}
			
			if ($invoice_row['state']) {
				$this->printError('Инвойс уже оплачен');
			}

			if ($invoice_row['gateway'] != $this->alias) {
				$this->printError('Инвойс не той платежной системы');
			}
			
			if (POST('notification_type') != 'p2p-incoming' and POST('notification_type') != 'card-incoming') {
				$this->printError('Неверный тип оповещения');
			}
			
			$amount_due = $this->getAmountDue(POST('amount'), POST('notification_type'));
			
			if (round(POST('amount'), 1) < round($amount_due, 1)) {
				$this->printError('Неверная сумма: '.POST('amount'));
			}
			
			if (POST('withdraw_amount') < $invoice_row['amount']) {
				$this->printError('Неверная сумма #2: '.POST('withdraw_amount'));
			}
			
			
			$payment_id = $this->processAfterPayment($invoice_id, $amount_due);
			
			
			if ($payment_row = $this->webcash->getRowById($this->webcash->gateway_payments_table, $payment_id)) {
				if (POST('unaccepted') and POST('unaccepted') !== 'false') {//Перевод еще не зачислен. Получателю нужно освободить место в кошельке или использовать код протекции (если codepro=true).
					$this->helper->sendEmailToAdmin('Перевод еще не зачислен. Получателю нужно освободить место в кошельке или использовать код протекции (если codepro=true). Invoice ID: '.$invoice_id.', Payment ID: '.$payment_id);
					
					$this->printError('Перевод еще не зачислен.');
				}
				
				if (POST('codepro') and POST('codepro') !== 'false') {//Для переводов из кошелька — перевод защищен кодом протекции. Для переводов с произвольной карты — всегда false.
					$this->helper->sendEmailToAdmin('Перевод защищен кодом протекции. Invoice ID: '.$invoice_id.', Payment ID: '.$payment_id);
					$this->printError('Перевод защищен кодом протекции.');
				}
				
				
				$this->checkout->gatewaySuccessPayment($invoice_row, $payment_row);

				//fs_log("Инвойс #" . $invoice_id . " оплачен!");
				exit;
			}

			$this->printError('Error '.__LINE__);
		} else {
			$this->webcash->siteMsgError('Не указаны необходимые данные');
		}
	}
	
	public function printError($text) {
		$text = 'Ошибка! '.$text;
		//fs_log('Merchant error ('.$this->alias.'): '.$text);
		header('HTTP/1.1 500 Internal Server Error');
		echo $text;
		exit;
	}
	
	public function processAfterPayment($invoice_id, $amount_due) {
		$gateway_details_arr = array(
			'amount_due' => $amount_due,
			'notification_type' => POST('notification_type'),
			'datetime' => POST('datetime'),
			'operation_id' => POST('operation_id'),
		);
		
		$gateway_details_arr = array_map(array($this->helper, 'htmlspecialchars'), $gateway_details_arr);
		
		return $this->checkout->addPaymentToDb($invoice_id, POST('sender'), $gateway_details_arr);
	}
	
	public function getServiceInfo() {
		$result = array(
			'name' => __('Yoomoney'),
			'alias' => $this->alias,
			'items' => array(
				1 => array(
					'title' => __('Кошелек'),
					'image' => 'iomoney.png',//
				),
				2 => array(
					'title' => __('Банковская карта'),
					'image' => 'visa_mastercard_logo.png',
				),
			),
		);
		
		return $result;
	}

}