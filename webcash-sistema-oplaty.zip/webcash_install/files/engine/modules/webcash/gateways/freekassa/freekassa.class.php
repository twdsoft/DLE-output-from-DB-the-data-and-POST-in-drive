<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

class Gateways_FreeKassa extends AddonSettings
{
	protected $alias = 'freekassa';
    
	public function renderPaymentForm($invoice_id, $cs_key, $gw_item_id) {
		if ($str = $this->verifyGatewayEnable())
			return $str;
		
		if (!$checkout_store = $this->checkout->getDataStore($cs_key))
			return '';
		
		$service_info = $this->getServiceInfo();
		
		if (!$gw_item = safe_array_access($service_info, 'items', $gw_item_id))
			trigger_error(basename(__FILE__).', line: '.__LINE__, E_USER_ERROR);
		
		$amount = $this->wc_currency->convertMainCurrencyTo($checkout_store['amount'], $this->currency);
		$amount = number_format($amount, 2, '.', '');
		$payment_desc = $this->webcash->site_url.' - '.to_utf8(safe_array_access($checkout_store, 'checkout_header'));
		
        $signature = md5(implode(':', array(
            $this->merchant_id,
            $amount,
            $this->secret_key,
            $invoice_id,
        )));
		
		$tpl = $this->webcash->getTplInstance();
		$tpl->assign('merchant_id', $this->merchant_id);
		$tpl->assign('amount', $amount);
		$tpl->assign('invoice_id', $invoice_id);
		$tpl->assign('currency', $this->currency);
		$tpl->assign('description', $this->helper->htmlspecialchars($payment_desc));
		$tpl->assign('email', $this->helper->htmlspecialchars(safe_array_access($checkout_store, 'email')));
		$tpl->assign('language', $this->language);
		$tpl->assign('signature', $signature);
		
		$tpl->assign('gw_item_id', $gw_item_id);
		$tpl->assign('gw_item', $gw_item);
		$tpl->assign('gateway_header', $service_info['name']);
		$tpl->assign('gw_alias', $this->alias);
		$tpl->assign('gateway_cfg', $this->getCfgPublicParams());
		$tpl->assign('addon_settings_link', $this->renderAddonSettingsLink());
		$tpl->assign('user_hash', $this->user->nonce);
		$tpl->load_template('/modules/webcash/gateways/freekassa/checkout.tpl');
		
		$tpl->compile('content');
		
		return $tpl->result['content'];
	}
	
	public function processing() {
		if ($this->server_ip) {
			//проверка IP-адреса
			$allowed = explode("\n", $this->server_ip);
			$allowed = array_map('trim', $allowed);
			
			$ip_checked = false;
			
			foreach(array(
				'HTTP_X_CLUSTER_CLIENT_IP',
				'HTTP_X_FORWARDED_FOR',
				'HTTP_X_FORWARDED',
				'HTTP_FORWARDED_FOR',
				'HTTP_FORWARDED',
				'HTTP_CLIENT_IP',
				'REMOTE_ADDR'
			) as $param) {
				foreach ($allowed as $ip) {
					if (safe_array_access($_SERVER, $param) === $ip) {
						$ip_checked = true;
						break;
					}
				}
			}
			
			if (!$ip_checked) {
				$this->printError('Неверный IP-адрес');
			}
		}
		
		// проверка на наличие обязательных полей
		foreach(array(
			'MERCHANT_ID',
			'AMOUNT',
			'MERCHANT_ORDER_ID',
			'SIGN'
		) as $field) {
			if (empty($_REQUEST[$field])) {
				$this->printError('Не указаны обязательные данные');
			}
		}
		
		
		// нормализация данных
		$merchant_id = (int)$_REQUEST['MERCHANT_ID'];
		$amount = only_float($_REQUEST['AMOUNT']);
		$invoice_id = (int)$_REQUEST['MERCHANT_ORDER_ID'];
		$signature = $_REQUEST['SIGN'];
		$email = $_REQUEST['P_EMAIL'];
		$phone = safe_array_access($_REQUEST, 'P_PHONE');
		$intid = (int)$_REQUEST['intid'];
		$cur_id = (int)$_REQUEST['CUR_ID'];
		
		// проверка валюты
		if ($merchant_id != $this->merchant_id) {
			$this->printError('Неверный ID магазина '.$merchant_id);
		}
		
		// проверка формата сигнатуры
		if (!preg_match('/^[0-9a-f]{32}$/', $signature)) {
			$this->printError('Неверный формат подписи '.$signature);
		}
		
		// проверка значения сигнатуры (используется ваш второй секретный ключ)
		$signature_calc = md5(implode(':', array(
			$merchant_id,
			$amount, 
			$this->secret_key2,
			$invoice_id
		)));
		
		if ($signature_calc !== $signature) {
			$this->printError('Неверная подпись '.$signature);
		}
		
		
		$this->readSettingsFromFile();
		
		if (!$invoice_row = $this->webcash->getRowById($this->webcash->gateway_invoices_table, $invoice_id)) {
			$this->printError('Нет такого инвойса');
		}
		
		if ($invoice_row['state']) {
			$this->printError('Инвойс уже оплачен');
		}

		if ($invoice_row['gateway'] != $this->alias) {
			$this->printError('Инвойс не той платежной системы');
		}
		
		if ($invoice_row['amount'] > $amount) {
			$this->printError('Неверная сумма: '.$amount);
		}
		
		
		if (!$sender = $email) {
			if (!$sender = $phone) {
				$sender = $intid;
			}
		}
		
		$payment_id = $this->processAfterPayment($invoice_id, $sender);
		
		
		if ($payment_row = $this->webcash->getRowById($this->webcash->gateway_payments_table, $payment_id)) {
			$this->checkout->gatewaySuccessPayment($invoice_row, $payment_row);

			//fs_log("Инвойс #" . $invoice_id . " оплачен!");
			exit('YES');// успешный ответ для Free-Kassa и завершение скрипта
		}
		
		$this->printError('Error '.__LINE__);
	}
	
	public function printError($text) {
		$text = 'Ошибка! '.$text;
		//fs_log('Merchant error ('.$this->alias.'): '.$text);
		//echo $text;
		exit;
	}
	
	public function processAfterPayment($invoice_id, $sender) {
		$gateway_details_arr = POST();
		$gateway_details_arr = array_map(array($this->helper, 'htmlspecialchars'), $gateway_details_arr);
		
		return $this->checkout->addPaymentToDb($invoice_id, $sender, $gateway_details_arr);
	}
	
	public function getServiceInfo() {
		$result = array(
			'name' => __('FreeKassa'),
			'alias' => $this->alias,
			'items' => array(
				1 => array(
					'title' => __('Перейти к оплате'),
					'image' => 'freekassa.png',
				),
			),
		);
		
		return $result;
	}

}