<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

if (!$this->readSettingsFromFile()) {
	$this->setCfgValue('display_name', 'Платежный шлюз Free-kassa');
	$this->setCfgValue('description', 'С помощью этого шлюза можно организовать прием платежей через платежную систему Free-kassa.');
	$this->setCfgValue('merchant_id', '');
	$this->setCfgValue('secret_key', '');
	$this->setCfgValue('secret_key2', '');
	$this->setCfgValue('server_ip', "136.243.38.147\n136.243.38.149\n136.243.38.150\n136.243.38.151\n136.243.38.189\n136.243.38.108");
	$this->setCfgValue('language', 'ru');
	$this->setCfgValue('currency', 'RUB');
	$this->setCfgValue('site_url', 'https://free-kassa.ru');
	$this->setCfgValue('access_allowed_usergroups', array());
	$this->setNoneFormControlCfgValue('public_cfg_fields', array(
		'merchant_id',
		'language',
	));
	
	if (WebCash::DEBUG_SETTINGS) {
		$this->setCfgValue('merchant_id', '211311');
		$this->setCfgValue('secret_key', 'XXXXXXXX');
		$this->setCfgValue('secret_key2', 'XXXXXXXX');
	}
	
	
	$result_url = $this->checkout->getGatewayProcessingUrl($this->alias);
	$success_url = $this->checkout->successCheckoutUrl(0, '', '&gw_alias='.$this->alias);
	$fail_url = $this->checkout->failCheckoutUrl();
	
	$this->addHint(__FILE__.'1', sprintf(__('Внимание, перед началом работы необходимо зарегистрироваться на сайте <a href="https://free-kassa.ru/" target="_blank">https://free-kassa.ru/</a>, и создав магазин, скопировать секретные ключи в настройки плагина. В настройках магазина, кроме других обязательных полей, необходимо указать URL возврата в случае успеха: <b>%s</b>, URL возврата в случае неудачи: <b>%s</b>, URL оповещения: <a href="%s" target="_blank"><code>%s</code></a>.'), $success_url, $fail_url, $result_url, $result_url), false);
	
	$this->setFieldsItem('merchant_id', array(
		'title' => 'Идентификатор магазина',
		'hint' => 'Идентификатор магазина, узнать его можно в <a href="https://free-kassa.ru/" target="_blank">личном кабинете Free-kassa</a>',
		'type' => 'text',
		'required' => true,
	));
	
	$this->setFieldsItem('secret_key', array(
		'title' => 'Секретный ключ №1',
		'hint' => 'Первый секретный ключ, получить его можно в <a href="https://free-kassa.ru/" target="_blank">личном кабинете Free-kassa</a>',
		'type' => 'text',
		'required' => true,
	));
	
	$this->setFieldsItem('secret_key2', array(
		'title' => 'Секретный ключ №2',
		'hint' => 'Второй секретный ключ, получить его можно в <a href="https://free-kassa.ru/" target="_blank">личном кабинете Free-kassa</a>',
		'type' => 'text',
		'required' => true,
	));

	$this->setFieldsItem('language', array(
		'title' => 'Язык клиента',
		'hint' => 'Возможные значения: русский, английский',
		'type' => 'select',
		'value' => array('ru', 'en'),
		'label' => array(__('Русский'), __('Английский')),
	));
	
	$arr = $this->wc_currency->getCurrenciesList();
	$arr = filter_allowed_keys($arr, array('RUB', 'USD', 'EUR'));
	
	$this->setFieldsItem('currency', array(
		'title' => 'Валюта аккаунта',
		'hint' => 'Валюта которая используется в аккаунте Free-kassa',
		'type' => 'select',
		'value' => array_keys($arr),
		'label' => array_values($arr),
		'required' => true,
	));
	
	$this->setFieldsItem('server_ip', array(
		'title' => 'Доверенные IP-адреса',
		'hint' => 'Если указать IP-адреса шлюза (по одному в каждой строке), то извещения будут приниматься только с этих адресов. Если надо убрать данную проверку - поле должно быть пустым.',
		'type' => 'textarea',
		'tag_part' => 'style="height:130px;"',
	));
	
	$this->setFieldsItem('site_url', array(
		'title' => 'Сайт провайдера',
		'hint' => 'Данный адрес используется в списке шлюзов только для удобства работы',
		'type' => 'text',
	));
	
	
	$this->convertDefaultValues();
	$this->writeSettingsInFile(true);
}