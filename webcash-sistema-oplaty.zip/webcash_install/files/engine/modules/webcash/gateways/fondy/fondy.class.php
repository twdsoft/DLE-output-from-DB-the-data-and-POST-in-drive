<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

class Gateways_Fondy extends AddonSettings
{
	const ORDER_APPROVED = 'approved';
	
	protected $alias = 'fondy';
    
	public function renderPaymentForm($invoice_id, $cs_key, $gw_item_id) {
		if ($str = $this->verifyGatewayEnable())
			return $str;
		
		if (!$checkout_store = $this->checkout->getDataStore($cs_key))
			return '';
		
		$service_info = $this->getServiceInfo();
		
		if (!$gw_item = safe_array_access($service_info, 'items', $gw_item_id))
			trigger_error(basename(__FILE__).', line: '.__LINE__, E_USER_ERROR);
		
		$amount = $this->wc_currency->convertMainCurrencyTo($checkout_store['amount'], $this->currency);
		$payment_desc = $this->webcash->site_url.' - '.to_utf8(safe_array_access($checkout_store, 'checkout_header'));
		
		$oplata_args = array(
			'order_id' => $invoice_id		.'#'.time(),//LASTSUPER
			'merchant_id' => $this->merchant_id,
			'order_desc' => $payment_desc,
			'amount' => $amount * 100,
			'currency' => $this->currency,
			'server_callback_url' => $this->checkout->getGatewayProcessingUrl($this->alias),
			'response_url' => $this->checkout->successCheckoutUrl($invoice_id, '', '&gw_alias='.$this->alias),
			'lang' => $this->language,
			'sender_email' => $this->helper->htmlspecialchars(safe_array_access($checkout_store, 'email'))
		);
		
		$oplata_args['signature'] = $this->signData($oplata_args);
		//print2($oplata_args);
		$url = $this->getCheckoutUrl($oplata_args);
		
		$tpl = $this->webcash->getTplInstance();
		$tpl->assign('url', $url);
		$tpl->assign('amount', $amount);
		$tpl->assign('invoice_id', $invoice_id);
		$tpl->assign('currency', $this->currency);
		$tpl->assign('description', $this->helper->htmlspecialchars($payment_desc));
		$tpl->assign('email', $this->helper->htmlspecialchars(safe_array_access($checkout_store, 'email')));
		
		$tpl->assign('gw_item_id', $gw_item_id);
		$tpl->assign('gw_item', $gw_item);
		$tpl->assign('gateway_header', $service_info['name']);
		$tpl->assign('gw_alias', $this->alias);
		$tpl->assign('gateway_cfg', $this->getCfgPublicParams());
		$tpl->assign('addon_settings_link', $this->renderAddonSettingsLink());
		$tpl->assign('user_hash', $this->user->nonce);
		$tpl->load_template('/modules/webcash/gateways/fondy/checkout.tpl');
		
		$tpl->compile('content');
		
		return $tpl->result['content'];
	}
	
	public function signData($params) {
        $params = array_filter($params, function($var) {
            return $var !== '' and $var !== null;
        });
        ksort($params);
        array_unshift($params, $this->secret_key);
		
        return sha1(implode('|', $params));
	}
	
	protected function getCheckoutUrl($args) {
		if (is_callable('curl_init')) {
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, 'https://api.fondy.eu/api/checkout/url/');
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-type: application/json'));
			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(array('request' => $args)));
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
			
			$result = json_decode(curl_exec($ch));
			$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
				
			if ($http_code != 200) {
				echo "Return code is {$http_code} \n".curl_error($ch);
				exit;
			}
			
			if ($result->response->response_status == 'failure') {
				echo $result->response->error_message;
				exit;
			}
			
			$url = $result->response->checkout_url;
			return $url;
		} else {
			trigger_error(basename(__FILE__).', line: '.__LINE__, E_USER_ERROR);
		}
	}
	
	
	public function processing() {
		if ($this->server_ip) {
			//проверка IP-адреса
			$allowed = explode("\n", $this->server_ip);
			$allowed = array_map('trim', $allowed);
			
			$ip_checked = false;
			
			foreach(array(
				'HTTP_X_CLUSTER_CLIENT_IP',
				'HTTP_X_FORWARDED_FOR',
				'HTTP_X_FORWARDED',
				'HTTP_FORWARDED_FOR',
				'HTTP_FORWARDED',
				'HTTP_CLIENT_IP',
				'REMOTE_ADDR'
			) as $param) {
				foreach ($allowed as $ip) {
					if (safe_array_access($_SERVER, $param) === $ip) {
						$ip_checked = true;
						break;
					}
				}
			}
			
			if (!$ip_checked) {
				$this->printError('Неверный IP-адрес');
			}
		}
		
		if (empty($_POST)) {
			if (!$json = json_decode(file_get_contents('php://input'), true)){
				$this->printError('Пустой ответ');
			}
			
			$response = array();
			
			foreach($json as $key => $val) {
				$response[$key] = $val;
			}
		} else {
			$response = $_POST;
		}
		
		// проверка на наличие обязательных полей
		foreach(array(
			'merchant_id',
			'signature',
			'amount',
			'order_id',
			'order_status',
		) as $field) {
			if (empty($response[$field])) {
				$this->printError('Не указаны обязательные данные');
			}
		}
		
		
		// нормализация данных
		$merchant_id = (int)$response['merchant_id'];
		$amount = $response['amount'] / 100;
		$invoice_id = (int)$response['order_id'];
		$signature = $response['signature'];
		$email = $response['sender_email'];
		
		if ($response['order_status'] != self::ORDER_APPROVED) {
			$this->printError('Статус оплаты отличается от успешного - '.$response['order_status']);
		}
		
		// проверка валюты
		if ($merchant_id != $this->merchant_id) {
			$this->printError('Неверный ID магазина '.$merchant_id);
		}
		
		// проверка значения сигнатуры
		unset($response['response_signature_string']);
		unset($response['signature']);
		
		if ($this->signData($response) !== $signature) {
			$this->printError('Неверная подпись '.$signature);
		}
		
		
		$this->readSettingsFromFile();
		
		if (!$invoice_row = $this->webcash->getRowById($this->webcash->gateway_invoices_table, $invoice_id)) {
			$this->printError('Нет такого инвойса');
		}
		
		if ($invoice_row['state']) {
			$this->printError('Инвойс уже оплачен');
		}

		if ($invoice_row['gateway'] != $this->alias) {
			$this->printError('Инвойс не той платежной системы');
		}
		
		if ($invoice_row['amount'] > $amount) {
			$this->printError('Неверная сумма: '.$amount);
		}
		
		
		if (!$sender = $email) {
			if (!$sender = safe_array_access($response, 'sender_cell_phone')) {
				if (!$sender = safe_array_access($response, 'sender_account')) {
					if (!$sender = safe_array_access($response, 'masked_card')) {
						$sender = safe_array_access($response, 'rrn');
					}
				}
			}
		}
		
		$payment_id = $this->processAfterPayment($invoice_id, $sender);
		
		
		if ($payment_row = $this->webcash->getRowById($this->webcash->gateway_payments_table, $payment_id)) {
			$this->checkout->gatewaySuccessPayment($invoice_row, $payment_row);

			//fs_log("Инвойс #" . $invoice_id . " оплачен!");
			exit('ok');// успешный код ответа 200 для Fondy и завершение скрипта
		}
		
		$this->printError('Error '.__LINE__);
	}
	
	public function printError($text) {
		$text = 'Ошибка! '.$text;
		fs_log('Merchant error ('.$this->alias.'): '.$text);
		echo $text;
		exit;
	}
	
	public function processAfterPayment($invoice_id, $sender) {
		$gateway_details_arr = POST();
		$gateway_details_arr = array_map(array($this->helper, 'htmlspecialchars'), $gateway_details_arr);
		
		return $this->checkout->addPaymentToDb($invoice_id, $sender, $gateway_details_arr);
	}
	
	public function getServiceInfo() {
		$result = array(
			'name' => __('Fondy'),
			'alias' => $this->alias,
			'items' => array(
				1 => array(
					'title' => __('Перейти к оплате'),
					'image' => 'fondy.png',
				),
			),
		);
		
		return $result;
	}

}