<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

if (!$this->readSettingsFromFile()) {
	$this->setCfgValue('display_name', 'Платежный шлюз Fondy');
	$this->setCfgValue('description', 'С помощью этого шлюза можно организовать прием платежей через платежную систему Fondy.');
	$this->setCfgValue('merchant_id', '');
	$this->setCfgValue('secret_key', '');
	$this->setCfgValue('server_ip', "54.76.178.89\n54.154.216.60\n23.105.225.142\n23.108.217.143");
	$this->setCfgValue('language', 'ru');
	$this->setCfgValue('currency', 'RUB');
	$this->setCfgValue('mode', 'redirect');
	$this->setCfgValue('site_url', 'https://fondy.ru');
	$this->setCfgValue('access_allowed_usergroups', array());
	$this->setNoneFormControlCfgValue('public_cfg_fields', array(
		'merchant_id',
		'language',
		'mode',
	));
	
	if (WebCash::DEBUG_SETTINGS) {
		$this->setCfgValue('merchant_id', '1472065');
		$this->setCfgValue('secret_key', 'lhU0VlhGyxbFwgWWRJp5HzNwzZAamrIE');
	}
	
	
	$result_url = $this->checkout->getGatewayProcessingUrl($this->alias);
	$success_url = $this->checkout->successCheckoutUrl(0, '', '&gw_alias='.$this->alias);
	$fail_url = $this->checkout->failCheckoutUrl();
	
	$this->addHint(__FILE__.'1', sprintf(__('Внимание, перед началом работы необходимо зарегистрироваться на сайте <a href="https://fondy.ru/" target="_blank">https://fondy.ru/</a>, и добавив мерчант, скопировать секретные ключи в настройки плагина. В настройках мерчанта, кроме других параметров, можно указать URL для успешного ответа: <b>%s</b>, URL для неуспешного ответа: <b>%s</b>, Server Callback URL: <a href="%s" target="_blank"><code>%s</code></a>.'), $success_url, $fail_url, $result_url, $result_url), false);

	
	$this->setFieldsItem('merchant_id', array(
		'title' => 'Идентификатор мерчанта',
		'hint' => 'Идентификатор мерчанта, узнать его можно в <a href="https://fondy.ru/" target="_blank">личном кабинете Fondy</a>',
		'type' => 'text',
		'required' => true,
	));
	
	$this->setFieldsItem('secret_key', array(
		'title' => 'Секретный ключ',
		'hint' => 'Секретный ключ, получить его можно в <a href="https://fondy.ru/" target="_blank">личном кабинете Fondy</a>',
		'type' => 'text',
		'required' => true,
	));
	
	$this->setFieldsItem('language', array(
		'title' => 'Язык клиента',
		'hint' => 'Возможные значения: русский, английский',
		'type' => 'select',
		'value' => array('ru', 'en', 'uk', 'lv', 'cs', 'pl', 'de'),
		'label' => array(__('Русский'), __('Английский'), __('Украинский'), __('Латышский'), __('Чешский'), __('Польский'), __('Немецкий')),
	));
	
	$arr = $this->wc_currency->getCurrenciesList();
	$arr = filter_allowed_keys($arr, array('RUB', 'USD', 'EUR', 'UAH', 'BYR', 'KZT'));
	
	$this->setFieldsItem('currency', array(
		'title' => 'Валюта аккаунта',
		'hint' => 'Валюта которая используется в аккаунте Fondy',
		'type' => 'select',
		'value' => array_keys($arr),
		'label' => array_values($arr),
		'required' => true,
	));
	
	$this->setFieldsItem('server_ip', array(
		'title' => 'Доверенные IP-адреса',
		'hint' => 'Если указать IP-адреса шлюза (по одному в каждой строке), то извещения будут приниматься только с этих адресов. Если надо убрать данную проверку - поле должно быть пустым.',
		'type' => 'textarea',
		'tag_part' => 'style="height:100px;"',
	));
	
	$this->setFieldsItem('mode', array(
		'title' => 'Режим оплаты',
		'hint' => 'Выбор режима оплаты с перенаправлением плательщика на платежную страницу или с предварительным host-to-host запросом получения URL платежной страницы',
		'type' => 'select',
		'value' => array('redirect', 'onpage'),
		'label' => array(__('Перенаправление на страницу оплаты'), __('Отображение на странице')),
	));
	
	$this->setFieldsItem('site_url', array(
		'title' => 'Сайт провайдера',
		'hint' => 'Данный адрес используется в списке шлюзов только для удобства работы',
		'type' => 'text',
	));
	
	
	$this->convertDefaultValues();
	$this->writeSettingsInFile(true);
}