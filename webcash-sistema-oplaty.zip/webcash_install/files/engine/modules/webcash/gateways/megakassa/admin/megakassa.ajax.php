<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

$webcash->megakassa->readSettingsFromFile();


if ($action == 'ajax.gateway.from_tab1') {
	if ($subaction == 'delete' and $id = (int)POST('id')) {
		if ($webcash->adminpanel->deleteRecordById($id, $webcash->megakassa->table_a)) {
			$webcash->helper->showMsgOk('Запись удалена. Перезагрузка...', 'Информация', 'self');
		}
	} elseif ($subaction == 'save_columns') {
		$webcash->admin_megakassa->saveTblColumnsList('gw_items_tbl_columns_list', POST('tbl_columns_list'));
	}
} elseif ($action == 'ajax.gateway.from_tab2') {
	if ($subaction == 'edit_megakassa_gw_item') {
		$webcash->helper->emptyRequiredFields($_POST);
		
		if ($webcash->megakassa->updateItem($_POST)) {
			$webcash->helper->showMsgOk('Параметры метода оплаты обновлены');
		}
		
	} elseif ($subaction == 'adm_search_gw_item') {
		if ($str = POST('search_value') and $str != POST('remark')) {
			if (is_numeric($str)) {//by ID
				$row = $webcash->getRowById($webcash->megakassa->table_a, $str);
			} else {
				$str = $webcash->db->esc_html($str);
				$str = __($str);
				$row = $webcash->db->selectRow("SELECT * FROM {$webcash->megakassa->table_a} WHERE title LIKE '%{$str}%' LIMIT 1");//by title
			}
			
			if (!empty($row['id'])) {
				$webcash->helper->showMsgOk('Метод оплаты найден. Перенаправление...', 'Информация', $webcash->megakassa->getAddonSettingsUrl('&tab2=2&id='.$row['id']));
			} else {
				$webcash->helper->showMsgError('Не найден метод оплаты');
			}
		} else {
			$webcash->helper->showMsgError('Не указано значение для поиска');
		}
	}
}

$webcash->helper->showMsgError('Ошибка при выполнении запроса');