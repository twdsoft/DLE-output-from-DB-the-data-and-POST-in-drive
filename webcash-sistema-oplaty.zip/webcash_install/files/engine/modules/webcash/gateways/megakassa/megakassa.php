<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

if (!$this->readSettingsFromFile()) {
	$this->setCfgValue('display_name', 'Платежный шлюз Megakassa');
	$this->setCfgValue('description', 'С помощью этого шлюза можно организовать прием платежей через платежную систему Megakassa.');
	$this->setCfgValue('merchant_id', '');
	$this->setCfgValue('secret_key', '');
	$this->setCfgValue('language', 'ru');
	$this->setCfgValue('currency', 'RUB');
	$this->setCfgValue('test_mode', 0);
	$this->setCfgValue('use_method_id', 0);
	$this->setCfgValue('site_url', 'https://megakassa.ru');
	$this->setCfgValue('item_delete_button_confirm', 1);
	$this->setCfgValue('access_allowed_usergroups', array());
	$this->setConvCfgValue('date_format', 'j F Y г. H:i');
	$this->setCfgValue('gw_items_tbl_columns_list', 'nosort1,title,image,method_id,optional,description,state,nosort2,id');
	$this->setNoneFormControlCfgValue('public_cfg_fields', array(
		'merchant_id',
		'language',
		'test_mode',
		'use_method_id',
	));
	
	if (WebCash::DEBUG_SETTINGS) {
		$this->setCfgValue('merchant_id', '6305');
		$this->setCfgValue('secret_key', 'XXXXXXXXXXXXXXXX');
		$this->setCfgValue('test_mode', 1);
		$this->setCfgValue('use_method_id', 1);
	}
	
	
	$result_url = $this->checkout->getGatewayProcessingUrl($this->alias);
	$success_url = $this->checkout->successCheckoutUrl(0, '', '&gw_alias='.$this->alias);
	$fail_url = $this->checkout->failCheckoutUrl();
	
	$this->addHint(__FILE__.'1', sprintf(__('Внимание, перед началом работы необходимо зарегистрироваться на сайте <a href="https://megakassa.ru/" target="_blank">https://megakassa.ru/</a>, и создать магазин. В настройках, кроме других обязательных полей, необходимо указать URL успешной оплаты: <b>%s</b>, URL неуспешной оплаты: <b>%s</b>, URL обработчика: <a href="%s" target="_blank"><code>%s</code></a>.'), $success_url, $fail_url, $result_url, $result_url), false);
	
	$this->setFieldsItem('merchant_id', array(
		'title' => 'Идентификатор магазина',
		'hint' => 'Идентификатор магазина, узнать его можно в <a href="https://megakassa.ru/panel/shops/" target="_blank">настройках</a>',
		'type' => 'text',
		'required' => true,
	));
	
	$this->setFieldsItem('secret_key', array(
		'title' => 'Секретный ключ',
		'hint' => 'Секретный ключ магазина, получить его можно в <a href="https://megakassa.ru/panel/shops/" target="_blank">настройках магазина</a>',
		'type' => 'text',
		'required' => true,
	));

	$this->setFieldsItem('language', array(
		'title' => 'Язык клиента',
		'hint' => 'Возможные значения: русский, английский',
		'type' => 'select',
		'value' => array('ru', 'en'),
		'label' => array(__('Русский'), __('Английский')),
	));
	
	$arr = $this->wc_currency->getCurrenciesList();
	$arr = filter_allowed_keys($arr, array('RUB', 'USD', 'EUR'));
	
	$this->setFieldsItem('currency', array(
		'title' => 'Валюта аккаунта',
		'hint' => 'Валюта которая используется в аккаунте Megakassa',
		'type' => 'select',
		'value' => array_keys($arr),
		'label' => array_values($arr),
		'required' => true,
	));
	
	$this->setFieldsItem('test_mode', array(
		'title' => 'Включение тестового режима',
		'hint' => 'Если включено - то платеж выполняется в тестовом режиме, средства реально не переводятся',
		'type' => 'checkbox',
	));
	
	$this->setFieldsItem('use_method_id', array(
		'title' => 'Выбор метода оплаты на сайте',
		'hint' => 'Если включено - то у плательщика будет возможность выбрать метод оплаты на сайте, в противном случае выбор будет возможен при переходе в платежный шлюз. При включенном параметре, обязательным условием является передача в шлюз Емайл плательщика.',
		'type' => 'checkbox',
	));
	
	$this->setFieldsItem('item_delete_button_confirm', array(
		'title' => 'Предупреждение перед удалением',
		'hint' => 'Если включено - то при удалении отдельной записи в списке при помощи кнопки, необходимо подтвердить действие',
		'type' => 'checkbox',
	));
	
	$this->setFieldsItem('date_format', array(
		'title' => 'Формат даты',
		'hint' => 'Используется, например, при выводе даты в списке, <a href="#" onclick="javascript:Help(\'date\'); return false;">помощь по работе функции</a>',
		'type' => 'text',
	));
	
	$this->setFieldsItem('site_url', array(
		'title' => 'Сайт провайдера',
		'hint' => 'Данный адрес используется в списке шлюзов только для удобства работы',
		'type' => 'text',
	));
	
	
	$this->convertDefaultValues();
	$this->writeSettingsInFile(true);
}