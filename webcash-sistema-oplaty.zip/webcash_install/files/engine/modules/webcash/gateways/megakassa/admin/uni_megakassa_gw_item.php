<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

$this->adminpanel->showRow(
	__('Заголовок'),
	__('Заголовок метода оплаты'),
	$this->adminpanel->makeInputText(
		'data[title]',
		safe_array_access($megakassa_gw_item, 'title')
	),
	'',
	array(),
	true
);

$this->adminpanel->showRow(
	__('Лого'),
	__('Название картинки для логотипа метода оплаты'),
	$this->adminpanel->makeInputText(
		'data[image]',
		safe_array_access($megakassa_gw_item, 'image')
	),
	'',
	array(),
	true
);

$this->adminpanel->showRow(
	__('ID метода'),
	__('Служебный ID метода оплаты'),
	$this->adminpanel->makeInputText(
		'data[method_id]',
		safe_array_access($megakassa_gw_item, 'method_id')
	)
);

$this->adminpanel->showRow(
	__('Описание к методу оплаты'),
	__('Текстовое описание к методу оплаты, используется только в служебных целях, например, как подсказка администратору. Максимум 255 символов.'),
	$this->adminpanel->makeTextarea(
		'data[description]',
		safe_array_access($megakassa_gw_item, 'description')
	)
);

$this->adminpanel->showRow(
	__('Сортировка'),
	__('Индекс сортировки метода оплаты'),
	$this->adminpanel->makeInputText(
		'data[ordering]',
		safe_array_access($megakassa_gw_item, 'ordering')
	)
);

$this->adminpanel->showRow(
	__('Статус'),
	__('Если выключить метод оплаты - то он не будет отображаться в списке на сайте'),
	$this->adminpanel->makeCheckbox(
		'data[state]',
		safe_array_access($megakassa_gw_item, 'state')
	)
);