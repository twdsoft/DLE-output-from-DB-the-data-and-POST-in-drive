<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

$this->js_css->addCSSFile($this->webcash->rel_module_url.'admin/lib/simple-lightbox-images/jquery.simple-lightbox.css', true);

$this->js_css->addJsFile($this->webcash->rel_module_url.'admin/lib/simple-lightbox-images/jquery.simple-lightbox.js', true);
$this->js_css->addJsCode('$("img.simple-lightbox").simpleLightbox();', true, true);


$tbl_columns = $this->admin_megakassa->getGwItemsTblColumns();
?>

<form action="" class="webcash_ajax_form form-horizontal" method="post" autocomplete="off">
	<div class="panel panel-flat">
		<div class="panel-body">
			
			<?php echo $this->adminpanel->renderCommonListPart(__FILE__, $tbl_columns); ?>
			
			
            <div class="dataTables_wrapper">
				<?php echo $this->admin_megakassa->listGwItems(); ?>
			</div>
			
		
		</div>
	</div>
	<div class="buttons_wrap">
		<input type="hidden" name="action" value="ajax.gateway.from_tab1" />
		<input type="hidden" name="subaction" value="" />
		<input type="hidden" name="user_hash" value="<?php echo $this->user->nonce; ?>" />
		<input type="hidden" name="gw_alias" value="<?php echo $this->alias; ?>" />
	</div>
</form>