<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

class Gateways_MegaKassa extends AddonSettings
{
	const SERVER_IP = '5.196.121.217';
	
	protected $alias = 'megakassa';
	protected $table_a = 'webcash_megakassa_gw_items';
    
	public function renderPaymentForm($invoice_id, $cs_key, $gw_item_id) {
		if ($str = $this->verifyGatewayEnable())
			return $str;
		
		if (!$checkout_store = $this->checkout->getDataStore($cs_key))
			return '';
		
		$service_info = $this->getServiceInfo();
		
		if (!$gw_item = safe_array_access($service_info, 'items', $gw_item_id))
			trigger_error(basename(__FILE__).', line: '.__LINE__, E_USER_ERROR);
		
		$amount = $this->wc_currency->convertMainCurrencyTo($checkout_store['amount'], $this->currency);
		$amount = number_format($amount, 2, '.', '');
		$email = $this->helper->htmlspecialchars(safe_array_access($checkout_store, 'email'));
		$payment_desc = $this->webcash->site_url.' - '.to_utf8(safe_array_access($checkout_store, 'checkout_header'));
		
		if ($this->use_method_id and $email) {
			$method_id = $gw_item['method_id'];
			$client_email = $email;
		} else {
			$method_id = $client_email = '';
		}
		
		$signature = md5($this->secret_key.md5(join(':', array(
			$this->merchant_id,
			$amount,
			$this->currency,
			$payment_desc,
			$invoice_id,
			$method_id,
			$client_email,
			$this->test_mode,
			$this->secret_key
		))));
		
		$tpl = $this->webcash->getTplInstance();
		$tpl->assign('merchant_id', $this->merchant_id);
		$tpl->assign('amount', $amount);
		$tpl->assign('currency', $this->currency);
		$tpl->assign('description', $this->helper->htmlspecialchars($payment_desc));
		$tpl->assign('invoice_id', $invoice_id);
		$tpl->assign('method_id', $method_id);
		$tpl->assign('client_email', $client_email);
		$tpl->assign('debug', $this->test_mode);
		$tpl->assign('email', $email);
		$tpl->assign('language', $this->language);
		$tpl->assign('signature', $signature);
		
		$tpl->assign('gw_item_id', $gw_item_id);
		$tpl->assign('gw_item', $gw_item);
		$tpl->assign('gateway_header', $service_info['name']);
		$tpl->assign('gw_alias', $this->alias);
		$tpl->assign('gateway_cfg', $this->getCfgPublicParams());
		$tpl->assign('addon_settings_link', $this->renderAddonSettingsLink());
		$tpl->assign('user_hash', $this->user->nonce);
		$tpl->load_template('/modules/webcash/gateways/megakassa/checkout.tpl');
		
		$tpl->compile('content');
		
		return $tpl->result['content'];
	}
	
	public function processing() {
		if (self::SERVER_IP) {
			//проверка IP-адреса
			$ip_checked = false;
			
			foreach(array(
				'HTTP_X_CLUSTER_CLIENT_IP',
				'HTTP_X_FORWARDED_FOR',
				'HTTP_X_FORWARDED',
				'HTTP_FORWARDED_FOR',
				'HTTP_FORWARDED',
				'HTTP_CLIENT_IP',
				'REMOTE_ADDR'
			) as $param) {
				if (safe_array_access($_SERVER, $param) === self::SERVER_IP) {
					$ip_checked = true;
					break;
				}
			}
			
			if (!$ip_checked) {
				$this->printError('Неверный IP-адрес');
			}
		}
		
		// проверка на наличие обязательных полей
		// поля $payment_time и $debug могут дать true для empty()
		// поэтому их нет в проверке
		foreach(array(
			'uid',
			'amount',
			'amount_shop',
			'amount_client',
			'currency',
			'order_id',
			'payment_method_title',
			'creation_time',
			'client_email',
			'status',
			'signature'
		) as $field) {
			if (empty($_POST[$field])) {
				$this->printError('Не указаны обязательные данные');
			}
		}
		
		
		// нормализация данных
		$uid = (int)$_POST['uid'];
		$amount = only_float($_POST['amount']);
		$amount_shop = only_float($_POST['amount_shop']);
		$amount_client = only_float($_POST['amount_client']);
		$currency = $_POST['currency'];
		$invoice_id = (int)$_POST['order_id'];
		$payment_method_id = (int)$_POST['payment_method_id'];
		$payment_method_title = $_POST['payment_method_title'];
		$creation_time = $_POST['creation_time'];
		$payment_time = $_POST['payment_time'];
		$client_email = $_POST['client_email'];
		$status = $_POST['status'];
		$debug = (int)$_POST['debug'];
		$signature = $_POST['signature'];
		
		// проверка валюты
		if ($currency != $this->currency) {
			$this->printError('Неверная валюта платежа '.$currency);
		}
		
		// проверка статуса платежа
		if ($status != 'success') {
			$this->printError('Неуспешный платеж '.$status);
		}
		
		// проверка формата сигнатуры
		if (!preg_match('/^[0-9a-f]{32}$/', $signature)) {
			$this->printError('Неверный формат подписи '.$signature);
		}
		
		// проверка значения сигнатуры (используется ваш секретный ключ)
		$signature_calc = md5(implode(':', array(
			$uid, $amount, $amount_shop, $amount_client, $currency,
			$invoice_id, $payment_method_id, $payment_method_title, 
			$creation_time, $payment_time, $client_email, $status, 
			$debug, $this->secret_key
		)));
		
		if ($signature_calc !== $signature) {
			$this->printError('Неверная подпись '.$signature);
		}
		
		
		$this->readSettingsFromFile();
		
		if (!$invoice_row = $this->webcash->getRowById($this->webcash->gateway_invoices_table, $invoice_id)) {
			$this->printError('Нет такого инвойса');
		}
		
		if ($invoice_row['state']) {
			$this->printError('Инвойс уже оплачен');
		}

		if ($invoice_row['gateway'] != $this->alias) {
			$this->printError('Инвойс не той платежной системы');
		}
		
		if ($invoice_row['amount'] > $amount) {
			$this->printError('Неверная сумма: '.$amount);
		}
		
		
		$payment_id = $this->processAfterPayment($invoice_id, $client_email);
		
		
		if ($payment_row = $this->webcash->getRowById($this->webcash->gateway_payments_table, $payment_id)) {
			$this->checkout->gatewaySuccessPayment($invoice_row, $payment_row);

			//fs_log("Инвойс #" . $invoice_id . " оплачен!");
			exit('ok');// успешный ответ для Мегакассы и завершение скрипта
		}
		
		$this->printError('Error '.__LINE__);
	}
	
	public function printError($text) {
		$text = 'Ошибка! '.$text;
		//fs_log('Merchant error ('.$this->alias.'): '.$text);
		//echo $text;
		exit;
	}
	
	public function processAfterPayment($invoice_id, $client_email) {
		$gateway_details_arr = POST();
		$gateway_details_arr = array_map(array($this->helper, 'htmlspecialchars'), $gateway_details_arr);
		
		return $this->checkout->addPaymentToDb($invoice_id, $client_email, $gateway_details_arr);
	}
	
	public function getServiceInfo() {
		if ($this->use_method_id) {
			$arr = $this->arrayKeyId();
		} else {
			$arr = array(
				1 => array(
					'title' => __('Перейти к оплате'),
					'image' => 'megakassa.png',
				),
			);
		}
		
		$result = array(
			'name' => __('MegaKassa'),
			'alias' => $this->alias,
			'items' => $arr,
		);
		
		return $result;
	}

}