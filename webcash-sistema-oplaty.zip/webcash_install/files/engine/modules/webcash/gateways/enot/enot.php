<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

if (!$this->readSettingsFromFile()) {
	$this->setCfgValue('display_name', 'Платежный шлюз Enot');
	$this->setCfgValue('description', 'С помощью этого шлюза можно организовать прием платежей через платежную систему Enot.');
	$this->setCfgValue('merchant_login', WebCash::DEBUG_SETTINGS ? '6965' : '');
	$this->setCfgValue('secret_key1', WebCash::DEBUG_SETTINGS ? '2PI5yrT-4AHUFFPpQ-s0le1ODD-rExQv' : '');
	$this->setCfgValue('secret_key2', WebCash::DEBUG_SETTINGS ? 'ilS1SuNfVVBroxzr5lNsH_QC09AeTshi' : '');
	$this->setCfgValue('currency', 'RUB');
	$this->setCfgValue('test_mode', DEBUG_SETTINGS ? 1 : 0);
	$this->setCfgValue('site_url', 'https://enot.io');
	$this->setCfgValue('access_allowed_usergroups', array());
	$this->setNoneFormControlCfgValue('public_cfg_fields', array(
		'merchant_login',
		'currency',
	));
	
	
	$result_url = $this->checkout->getGatewayProcessingUrl($this->alias);
	$result_url = str_replace(array('http://', 'https://'), '', $result_url);
	
	$this->addHint(__FILE__.'1', sprintf(__('Внимание, перед началом работы необходимо зарегистрироваться на сайте <a href="https://enot.com/" target="_blank">https://enot.com/</a>, и создав магазин, скопировать идентификатор магазина, секретный пароль и дополнительный ключ в настройки плагина. В настройках магазина в поле &laquo;URL webhook&raquo; необходимо указать: <a href="%s" target="_blank"><code>%s</code></a>.'), $result_url, $result_url), false);
	
	$this->setFieldsItem('merchant_login', array(
		'title' => 'Идентификатор магазина',
		'hint' => 'Идентификатор магазина в Enot, можно посмотреть в <a href="https://enot.io/cabinet/merchant/site/index">списке касс</a>',
		'type' => 'text',
		'required' => true,
	));
	
	$this->setFieldsItem('secret_key1', array(
		'title' => 'Секретный пароль',
		'hint' => 'Секретный пароль из <a href="https://enot.io/cabinet/merchant/site/index" target="_blank">настроек магазина в Enot</a>',
		'type' => 'text',
		'required' => true,
	));
	
	$this->setFieldsItem('secret_key2', array(
		'title' => 'Дополнительный ключ',
		'hint' => 'Дополнительный ключ из <a href="https://enot.io/cabinet/merchant/site/index" target="_blank">настроек магазина в Enot</a>',
		'type' => 'text',
		'required' => true,
	));
	
	
	$arr = $this->wc_currency->getCurrenciesList();
	$arr = filter_allowed_keys($arr, array('RUB', 'USD', 'EUR', 'UAH'));
	
	$this->setFieldsItem('currency', array(
		'title' => 'Валюта аккаунта',
		'hint' => 'Валюта которая используется в аккаунте',
		'type' => 'select',
		'value' => array_keys($arr),
		'label' => array_values($arr),
		'required' => true,
	));
	
	$this->setFieldsItem('site_url', array(
		'title' => 'Сайт провайдера',
		'hint' => 'Данный адрес используется в списке шлюзов только для удобства работы',
		'type' => 'text',
	));
	
	
	$this->convertDefaultValues();
	$this->writeSettingsInFile(true);
}