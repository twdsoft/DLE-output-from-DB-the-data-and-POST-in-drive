<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

if (!$this->readSettingsFromFile()) {
	$this->setCfgValue('display_name', 'Платежный шлюз WalletOne');
	$this->setCfgValue('description', 'С помощью этого шлюза можно организовать прием платежей через платежную систему WalletOne.');
	$this->setCfgValue('merchant_id', WebCash::DEBUG_SETTINGS ? '113788140189' : '');
	$this->setCfgValue('secret_key', WebCash::DEBUG_SETTINGS ? '5c68385b477b4951784b6d5265676f4670714a6f6067454e38545c' : '');
	$this->setCfgValue('language', 'ru-RU');
	$this->setCfgValue('currency', 'RUB');
	$this->setCfgValue('site_url', 'https://walletone.com');
	$this->setCfgValue('access_allowed_usergroups', array());
	$this->setNoneFormControlCfgValue('public_cfg_fields', array(
		'merchant_id',
		'language',
		'currency',
	));
	
	
	$result_url = $this->checkout->getGatewayProcessingUrl($this->alias);
	$success_url = $this->checkout->successCheckoutUrl(0, '', '&gw_alias='.$this->alias);
	$fail_url = $this->checkout->failCheckoutUrl();
	
	$this->addHint(__FILE__.'1', sprintf(__('Внимание, перед началом работы необходимо зарегистрироваться на сайте <a href="https://walletone.com/" target="_blank">https://walletone.com/</a>, и создав магазин, скопировать идентификатор магазина и секретный ключ в настройки плагина. В <a href="https://www.walletone.com/merchant/client" target="_blank">настройках магазина</a>, кроме других обязательных полей, необходимо выбрать в поле &laquo;Метод формирования ЭЦП&raquo; - MD5, указать URL скрипта: <a href="%s" target="_blank"><code>%s</code></a>.'), $result_url, $result_url), false);
	
	$this->setFieldsItem('merchant_id', array(
		'title' => 'Идентификатор магазина',
		'hint' => 'Идентификатор магазина в WalletOne, который Вы получили при создании магазина',
		'type' => 'text',
		'required' => true,
	));
	
	$this->setFieldsItem('secret_key', array(
		'title' => 'Секретный ключ',
		'hint' => 'Секретный ключ из настроек магазина в WalletOne',
		'type' => 'text',
		'required' => true,
	));
	
	$this->setFieldsItem('language', array(
		'title' => 'Язык клиента',
		'hint' => 'Возможные значения: русский, английский',
		'type' => 'select',
		'value' => array('ru-RU', 'en-US'),
		'label' => array(__('Русский'), __('Английский')),
	));
	
	$arr = $this->wc_currency->getCurrenciesList();
	$arr = filter_allowed_keys($arr, array('RUB', 'USD', 'EUR', 'UAH', 'BYN', 'KZT'));
	
	$this->setFieldsItem('currency', array(
		'title' => 'Валюта аккаунта',
		'hint' => 'Валюта которая используется в аккаунте',
		'type' => 'select',
		'value' => array_keys($arr),
		'label' => array_values($arr),
		'required' => true,
	));
	
	$this->setFieldsItem('site_url', array(
		'title' => 'Сайт провайдера',
		'hint' => 'Данный адрес используется в списке шлюзов только для удобства работы',
		'type' => 'text',
	));
	
	
	$this->convertDefaultValues();
	$this->writeSettingsInFile(true);
}