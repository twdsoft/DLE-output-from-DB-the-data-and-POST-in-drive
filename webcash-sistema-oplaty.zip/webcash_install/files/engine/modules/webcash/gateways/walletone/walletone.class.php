<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

class Gateways_WalletOne extends AddonSettings
{
	protected $alias = 'walletone';
    
	public function renderPaymentForm($invoice_id, $cs_key, $gw_item_id) {
		if ($str = $this->verifyGatewayEnable())
			return $str;
		
		if (!$checkout_store = $this->checkout->getDataStore($cs_key))
			return '';
		
		$service_info = $this->getServiceInfo();
		
		if (!$gw_item = safe_array_access($service_info, 'items', $gw_item_id))
			trigger_error(basename(__FILE__).', line: '.__LINE__, E_USER_ERROR);
		
		$amount = $this->wc_currency->convertMainCurrencyTo($checkout_store['amount'], $this->currency);
		$amount = number_format($amount, 2, '.', '');
		$payment_desc = ($this->webcash->site_url.' - '.to_utf8(safe_array_access($checkout_store, 'checkout_header')));
		
		$tpl = $this->webcash->getTplInstance();
		
		$fields = array();
		$fields['WMI_MERCHANT_ID'] = $this->merchant_id;
		$fields['WMI_PAYMENT_AMOUNT'] = $amount;
		$arr = array('RUB' => 643, 'USD' => 840, 'EUR' => 978, 'UAH' => 980, 'BYN' => 974, 'KZT' => 398);
		$fields['WMI_CURRENCY_ID'] = safe_array_access($arr, $this->currency);
		$fields['WMI_PAYMENT_NO'] =  $invoice_id;
		$fields['WMI_DESCRIPTION'] = 'BASE64:'.base64_encode($payment_desc);
		$fields['WMI_SUCCESS_URL'] = $this->checkout->successCheckoutUrl($invoice_id, $cs_key);
		$fields['WMI_FAIL_URL'] = $this->checkout->failCheckoutUrl($invoice_id, $cs_key);
		
		//$fields['WMI_PTENABLED'] = 'TestCardRUB';
  
		$tpl->assign('amount', $amount);
		$tpl->assign('invoice_id', $invoice_id);
		$fields['WMI_SIGNATURE'] = $this->signData($fields);
		$tpl->assign('fields', $fields);
		
		$tpl->assign('email', $this->helper->htmlspecialchars(safe_array_access($checkout_store, 'email')));
		
		$tpl->assign('gw_item_id', $gw_item_id);
		$tpl->assign('gw_item', $gw_item);
		$tpl->assign('gateway_header', $service_info['name']);
		$tpl->assign('gw_alias', $this->alias);
		$tpl->assign('gateway_cfg', $this->getCfgPublicParams());
		$tpl->assign('addon_settings_link', $this->renderAddonSettingsLink());
		$tpl->assign('user_hash', $this->user->nonce);
		$tpl->load_template('/modules/webcash/gateways/walletone/checkout.tpl');
		
		$tpl->compile('content');
		
		return $tpl->result['content'];
	}
	
	public function signData($fields) {
		//Сортировка значений внутри полей
		foreach ($fields as $name => $val) {
			if (is_array($val)) {
				usort($val, 'strcasecmp');
				$fields[$name] = $val;
			}
		}

		// Формирование сообщения, путем объединения значений формы, отсортированных по именам ключей в порядке возрастания.
		uksort($fields, 'strcasecmp');
		$fieldValues = '';

		foreach ($fields as $value) {
			if (is_array($value)) {
				foreach($value as $v) {
					$v = to_win1251($v);
					$fieldValues .= $v;
				}
			} else {
				$value = to_win1251($value);
				$fieldValues .= $value;
			}
		}
		
		$signature = base64_encode(pack('H*', md5($fieldValues . $this->secret_key)));
		return $signature;
	}
	
	public function processing() {
		// проверка на наличие обязательных полей
		foreach(array(
			'WMI_MERCHANT_ID',
			'WMI_PAYMENT_AMOUNT',
			'WMI_COMMISSION_AMOUNT',
			'WMI_CURRENCY_ID',
			'WMI_TO_USER_ID',
			'WMI_PAYMENT_NO',
			'WMI_ORDER_ID',
			'WMI_DESCRIPTION',
			'WMI_INVOICE_OPERATIONS',
			'WMI_SUCCESS_URL',
			'WMI_FAIL_URL',
			'WMI_EXPIRED_DATE',
			'WMI_CREATE_DATE',
			'WMI_UPDATE_DATE',
			'WMI_ORDER_STATE',
			'WMI_SIGNATURE',
			'WMI_TEST_MODE_INVOICE',
		) as $key => $field) {
			if (!isset($_POST[$field])) {
				$this->printError('Не указаны обязательные данные');
			}
		}
		
		if (strtoupper(POST('WMI_ORDER_STATE')) != 'ACCEPTED') {
			$this->printError('Неверное состояние '.$_POST["WMI_ORDER_STATE"]);
		}
	
		// нормализация данных
		$amount = only_float($_POST['WMI_PAYMENT_AMOUNT']);
		$invoice_id = (int)$_POST['WMI_PAYMENT_NO'];
		
		// проверка значения сигнатуры
		$params = $_POST;
		unset($params['WMI_SIGNATURE']);
		$signature = $this->signData($params);
		
		if ($_POST['WMI_SIGNATURE'] != $signature) {
			$this->printError('Неверная подпись '.$_POST['WMI_SIGNATURE']);
		}
		
		
		$this->readSettingsFromFile();
		
		if (!$invoice_row = $this->webcash->getRowById($this->webcash->gateway_invoices_table, $invoice_id)) {
			$this->printError('Нет такого инвойса');
		}
		
		if ($invoice_row['state']) {
			$this->printError('Инвойс уже оплачен');
		}

		if ($invoice_row['gateway'] != $this->alias) {
			$this->printError('Инвойс не той платежной системы');
		}
		
		if ($invoice_row['amount'] > $amount) {
			$this->printError('Неверная сумма: '.$amount);
		}
		
		
		$sender = $invoice_row['email'];
		
		$payment_id = $this->processAfterPayment($invoice_id, $sender);
		
		
		if ($payment_row = $this->webcash->getRowById($this->webcash->gateway_payments_table, $payment_id)) {
			$this->checkout->gatewaySuccessPayment($invoice_row, $payment_row);

			//fs_log("Инвойс #" . $invoice_id . " оплачен!");
			exit('WMI_RESULT=OK');// успешный ответ для платежного шлюза и завершение скрипта
		}
		
		$this->printError('Error '.__LINE__);
	}
	
	public function printError($text) {
		$text = 'Ошибка! '.$text;
		if (WebCash::DEBUG_SETTINGS) {
			fs_log('Merchant error ('.$this->alias.'): '.$text);
			echo $text;
		}
		
		exit('WMI_RESULT=RETRY&WMI_DESCRIPTION='.urlencode($text));
	}
	
	public function processAfterPayment($invoice_id, $sender) {
		$gateway_details_arr = POST();
		$gateway_details_arr = array_map(array($this->helper, 'htmlspecialchars'), $gateway_details_arr);
		
		return $this->checkout->addPaymentToDb($invoice_id, $sender, $gateway_details_arr);
	}
	
	public function getServiceInfo() {
		$result = array(
			'name' => __('WalletOne'),
			'alias' => $this->alias,
			'items' => array(
				1 => array(
					'title' => __('Перейти к оплате'),
					'image' => 'walletone.png',
				),
			),
		);
		
		return $result;
	}

}