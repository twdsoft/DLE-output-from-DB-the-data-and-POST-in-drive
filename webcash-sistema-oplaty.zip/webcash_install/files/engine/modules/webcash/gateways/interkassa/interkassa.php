<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

if (!$this->readSettingsFromFile()) {
	$this->setCfgValue('display_name', 'Платежный шлюз Интеркасса');
	$this->setCfgValue('description', 'С помощью этого шлюза можно организовать прием платежей через платежную систему Интеркасса.');
	$this->setCfgValue('ik_merchant_id', '');//Номер кошелька
	$this->setCfgValue('ik_secret_key', '');
	$this->setCfgValue('test_mode', 0);
	$this->setCfgValue('ik_test_key', '');
	$this->setCfgValue('site_choose_method_on', 0);
	$this->setCfgValue('api_mode', 0);
	$this->setCfgValue('api_id', '');
	$this->setCfgValue('api_key', '');
	$this->setCfgValue('currency', 'RUB');
	$this->setCfgValue('site_url', 'https://interkassa.com');
	$this->setCfgValue('item_delete_button_confirm', 1);
	$this->setCfgValue('access_allowed_usergroups', array());
	$this->setConvCfgValue('date_format', 'j F Y г. H:i');
	$this->setCfgValue('gw_items_tbl_columns_list', 'nosort1,title,image,description,lmi_allow_sdp,lmi_sdp_type,state,nosort2,id');
	$this->setNoneFormControlCfgValue('public_cfg_fields', array(
		'ik_merchant_id',
		'test_mode',
	));
	
	if (WebCash::DEBUG_SETTINGS) {
		$this->setCfgValue('test_mode', 1);
		$this->setCfgValue('ik_merchant_id', 'xxxxxxxxxxxxxxx');
		$this->setCfgValue('ik_secret_key', 'xxxxxxxxxxxxxxx');
		$this->setCfgValue('ik_test_key', 'xxxxxxxxxx');
		$this->setCfgValue('api_id', 'xxxxxxxxxxxxxxxxxxxxxxxxx');
		$this->setCfgValue('api_key', 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
	}
	
	
	$str = $this->checkout->getGatewayProcessingUrl($this->alias);
	
	$this->addHint(__FILE__.'1', 'Внимание, перед началом работы создайте кассу по ссылке <a href="https://www.interkassa.com/account/checkout/" target="_blank">https://www.interkassa.com/account/checkout/</a>, настройте и скопируйте все необходимые параметры в настройки модуля. Адрес обработки запросов от мерчанта: <a href="'.$str.'" target="_blank"><code>'.$str.'</code></a>, чтобы его использовать, во вкладке &laquo;Интерфейс&raquo; кассы под полем &laquo;URL взаимодействия&raquo; необходимо включить чекбокс &laquo;разрешить переопределять в запросе&raquo;.');
	
	$this->setFieldsItem('ik_merchant_id', array(
		'title' => 'Идентификатор кассы',
		'hint' => 'Идентификатор кассы Интеркассы',
		'type' => 'text',
		'required' => true,
	));
	
	$this->setFieldsItem('ik_secret_key', array(
		'title' => 'Секретный ключ',
		'hint' => 'Секретный ключ безопасности находится на сайте Интеркассы во вкладке &laquo;Безопасность&raquo; вашей кассы',
		'type' => 'text',
		'required' => true,
	));
	
	
	$this->addCustomPositionBlocks();
	
	
	$arr = $this->wc_currency->getCurrenciesList();
	
	$this->setFieldsItem('currency', array(
		'title' => 'Валюта аккаунта',
		'hint' => 'Валюта которая используется в аккаунте',
		'type' => 'select',
		'value' => array_keys($arr),
		'label' => array_values($arr),
		'required' => true,
	));
	
	$this->setFieldsItem('item_delete_button_confirm', array(
		'title' => 'Предупреждение перед удалением',
		'hint' => 'Если включено - то при удалении отдельной записи в списке при помощи кнопки, необходимо подтвердить действие',
		'type' => 'checkbox',
	));
	
	$this->setFieldsItem('date_format', array(
		'title' => 'Формат даты',
		'hint' => 'Используется, например, при выводе даты в списке, <a href="#" onclick="javascript:Help(\'date\'); return false;">помощь по работе функции</a>',
		'type' => 'text',
	));
	
	$this->setFieldsItem('site_url', array(
		'title' => 'Сайт провайдера',
		'hint' => 'Данный адрес используется в списке шлюзов только для удобства работы',
		'type' => 'text',
	));
	
	
	$this->convertDefaultValues();
	$this->writeSettingsInFile(true);
}