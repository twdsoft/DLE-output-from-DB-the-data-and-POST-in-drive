<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

$this->adminpanel->showRow(
	__('Включение тестового режима'),
	__('Если включено - то платеж выполняется в тестовом режиме, средства реально не переводятся'),
	$this->adminpanel->makeCheckbox(
		'data[test_mode]',
		$this->test_mode,
		'data-linked_checkbox="test_mode"'
	),
	'',
	$this->col_values
);

$this->adminpanel->showRow(
	__('Тестовый ключ'),
	__('Тестовый ключ безопасности находится на сайте Интеркассы во вкладке &laquo;Безопасность&raquo; вашей кассы'),
	$this->adminpanel->makeInputText(
		'data[ik_test_key]',
		$this->ik_test_key
	),
	$this->makeAddonLinkedPart('test_mode'),
	$this->col_values,
	true
);

/*LAST
$this->adminpanel->showRow(
	__('Выбор методов оплаты прямо на сайте'),
	__('Если включено - то плательщик может выбирать нужный метод оплаты из списка разрешенных для вашей кассы. Иначе выбор происходит на стороне Интеркассы.'),
	$this->adminpanel->makeCheckbox(
		'data[site_choose_method_on]',
		$this->site_choose_method_on,
		'data-linked_checkbox="site_choose_method_on"'
	),
	'',
	$this->col_values
);


$this->adminpanel->showRow(
	__('Получить список методов оплаты'),
	__('Получить список методов оплаты с сайта Интеркассы'),
	'<a href="#" data-do="ajax-webcash" data-vars="action=ajax.gateway.get_gw_items|gw_alias=interkassa" title="'.__('Получить список методов оплаты').'" class="btn bg-brown-600 btn-sm btn-raised legitRipple">'.__('Получить').'</a>',
	$this->makeAddonLinkedPart('site_choose_method_on')
);

$this->adminpanel->showRow(
	__('Режим API'),
	__('Если включено - то для получения списка доступных методов оплаты используется API'),
	$this->adminpanel->makeCheckbox(
		'data[api_mode]',
		$this->api_mode,
		'data-linked_checkbox="api_mode"'
	),
	$this->makeAddonLinkedPart('site_choose_method_on'),
	$this->col_values
);

$this->adminpanel->showRow(
	__('Интеркасса API ID'),
	__('ID пользователя находится на сайте Интеркассы в разделе <a href="https://www.interkassa.com/account/user/settings" target="_blank">Личные данные</a>'),
	$this->adminpanel->makeInputText(
		'data[api_id]',
		$this->api_id
	),
	$this->makeAddonLinkedPart('site_choose_method_on').$this->makeAddonLinkedPart('api_mode'),
	$this->col_values,
	true
);

$this->adminpanel->showRow(
	__('Интеркасса API Key'),
	__('Ключ находится на сайте Интеркассы в разделе <a href="https://www.interkassa.com/account/user/settings" target="_blank">Личные данные</a>'),
	$this->adminpanel->makeInputText(
		'data[api_key]',
		$this->api_key
	),
	$this->makeAddonLinkedPart('site_choose_method_on').$this->makeAddonLinkedPart('api_mode'),
	$this->col_values,
	true
);
*/