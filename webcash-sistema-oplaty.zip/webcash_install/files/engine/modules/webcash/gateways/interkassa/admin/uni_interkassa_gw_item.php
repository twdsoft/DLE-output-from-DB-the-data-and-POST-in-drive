<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

$this->adminpanel->showRow(
	__('Заголовок'),
	__('Заголовок метода оплаты'),
	$this->adminpanel->makeInputText(
		'data[title]',
		safe_array_access($interkassa_gw_item, 'title')
	),
	'',
	array(),
	true
);

$this->adminpanel->showRow(
	__('Лого'),
	__('Название картинки для логотипа метода оплаты'),
	$this->adminpanel->makeInputText(
		'data[image]',
		safe_array_access($interkassa_gw_item, 'image')
	),
	'',
	array(),
	true
);

$this->adminpanel->showRow(
	__('Параметр &laquo;LMI_ALLOW_SDP&raquo;'),
	__('Служебный параметр &laquo;LMI_ALLOW_SDP&raquo;, который используется в системе <a href="https://wiki.interkassa.ru/projects/interkassa/wiki/Web_Merchant_Interface" target="_blank">&laquo;Merchant Webmoney&raquo;</a>'),
	$this->adminpanel->makeInputText(
		'data[LMI_ALLOW_SDP]',
		safe_array_access($interkassa_gw_item, 'LMI_ALLOW_SDP')
	)
);

$this->adminpanel->showRow(
	__('Параметр &laquo;LMI_SDP_TYPE&raquo;'),
	__('Служебный параметр &laquo;LMI_SDP_TYPE&raquo;, который используется в системе <a href="https://wiki.interkassa.ru/projects/interkassa/wiki/Web_Merchant_Interface" target="_blank">&laquo;Merchant Webmoney&raquo;</a>'),
	$this->adminpanel->makeInputText(
		'data[LMI_SDP_TYPE]',
		safe_array_access($interkassa_gw_item, 'LMI_SDP_TYPE')
	)
);

$this->adminpanel->showRow(
	__('Параметр &laquo;at&raquo;'),
	__('Служебный параметр &laquo;at&raquo;, который используется в системе <a href="https://wiki.interkassa.ru/projects/interkassa/wiki/Web_Merchant_Interface" target="_blank">&laquo;Merchant Webmoney&raquo;</a>'),
	$this->adminpanel->makeInputText(
		'data[at]',
		safe_array_access($interkassa_gw_item, 'at')
	)
);

$this->adminpanel->showRow(
	__('Описание к методу оплаты'),
	__('Текстовое описание к методу оплаты, используется только в служебных целях, например, как подсказка администратору. Максимум 255 символов.'),
	$this->adminpanel->makeTextarea(
		'data[description]',
		safe_array_access($interkassa_gw_item, 'description')
	)
);

$this->adminpanel->showRow(
	__('Сортировка'),
	__('Индекс сортировки метода оплаты'),
	$this->adminpanel->makeInputText(
		'data[ordering]',
		safe_array_access($interkassa_gw_item, 'ordering')
	)
);

$this->adminpanel->showRow(
	__('Статус'),
	__('Если выключить метод оплаты - то он не будет отображаться в списке на сайте'),
	$this->adminpanel->makeCheckbox(
		'data[state]',
		safe_array_access($interkassa_gw_item, 'state')
	)
);