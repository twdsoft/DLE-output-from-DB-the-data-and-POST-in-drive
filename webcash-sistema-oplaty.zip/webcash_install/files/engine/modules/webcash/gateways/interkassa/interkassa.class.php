<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

class Gateways_InterKassa extends AddonSettings
{
	const ITEMS_SORTING = 'ordering DESC, id';
	
	protected $alias = 'interkassa';
	protected $table_a = 'webcash_interkassa_gw_items';
	
    public function renderPaymentForm($invoice_id, $cs_key, $gw_item_id) {
		if ($str = $this->verifyGatewayEnable())
			return $str;
		
		if (!$checkout_store = $this->checkout->getDataStore($cs_key))
			return '';
		
		$service_info = $this->getServiceInfo();
		
		if (!$gw_item = safe_array_access($service_info, 'items', $gw_item_id))
			trigger_error(basename(__FILE__).', line: '.__LINE__, E_USER_ERROR);
		
		$amount = $this->wc_currency->convertMainCurrencyTo($checkout_store['amount'], $this->currency);
		$payment_desc = $this->webcash->site_url.' - '.to_utf8(safe_array_access($checkout_store, 'checkout_header'));
		
		
		$params = array(
			'ik_co_id' => $this->ik_merchant_id,
			'ik_pm_no' => $invoice_id,
			'ik_am' => number_format($amount, 2, '.', ''),
			'ik_cur' => $this->currency,
			'ik_desc' => $payment_desc,
			'ik_suc_u' => $this->checkout->successCheckoutUrl($invoice_id, $cs_key),
			'ik_fal_u' => $this->checkout->failCheckoutUrl($invoice_id, $cs_key),
			'ik_pnd_u' => $this->checkout->failCheckoutUrl($invoice_id, $cs_key),
			'ik_ia_u' => $this->checkout->getGatewayProcessingUrl($this->alias),
		);
		
		if ($this->test_mode) {
			$params['ik_pw_via'] = 'test_interkassa_test_xts';
		} elseif ($this->api_mode) {
			$params['ik_act'] = 'payways';
			$params['ik_int'] = 'json';
			$params['payments_systems'] = $this->getPaymentsApi();//LAST
		}
		
		$params['ik_sign'] = $this->signData($params);
		
		$tpl = $this->webcash->getTplInstance();
		$tpl->assign('invoice_id', $invoice_id);
		$tpl->assign('amount', number_format($amount, 2, '.', ''));
		$tpl->assign('payment_desc', $payment_desc);
		$tpl->assign('email', $this->helper->htmlspecialchars(safe_array_access($checkout_store, 'email')));
		$tpl->assign('params', $params);
		$tpl->assign('gw_item_id', $gw_item_id);
		$tpl->assign('gw_item', $gw_item);
		$tpl->assign('gateway_header', $service_info['name']);
		$tpl->assign('gw_alias', $this->alias);
		$tpl->assign('gateway_cfg', $this->getCfgPublicParams());
		$tpl->assign('addon_settings_link', $this->renderAddonSettingsLink());
		$tpl->assign('user_hash', $this->user->nonce);
		$tpl->load_template('/modules/webcash/gateways/interkassa/checkout.tpl');
		
		$tpl->compile('content');
		
		return $tpl->result['content'];
	}
	
	public function signData($params) {
		if (isset($params['ik_sign']))
			unset($params['ik_sign']);

		$data = array();
		foreach ($params as $key => $value) {
			if (!preg_match('/ik_/', $key)) continue;
			$data[$key] = $value;
		}
		
		ksort($data, SORT_STRING);
		
		array_push($data, $this->test_mode ? $this->ik_test_key : $this->ik_secret_key);
		$str = implode(':', $data);
		$sign = base64_encode(md5($str, true));
		return $sign;
	}
	
	public function processing() {
		if (GET('send_sign') == 1) {
			$this->sendSign();
		} else {
			$this->callback();
		}
	}
	
	public function sendSign() {
		$sign = $this->signData($_POST);
		header('Expires: Mon, 26 Jul 1997 05:00:00 GMT');
		header('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT');
		header('Cache-Control: no-store, no-cache, must-revalidate');
		header('Cache-Control: post-check=0, pre-check=0', false);
		header('Pragma: no-cache');
		echo $sign;
		exit;
	}
	
	public function callback() {
		if (POST('ik_co_id') and POST('ik_pm_no') and POST('ik_inv_st') and POST('ik_pw_via') and POST('ik_am') and POST('ik_cur') and POST('ik_inv_id') and POST('ik_sign')) {
			$this->readSettingsFromFile();
			
			if (POST('ik_co_id') != $this->ik_merchant_id) {
				$this->printError('Неверный ID кассы '.POST('ik_co_id'));
			}

			if (POST('ik_cur') != $this->currency) {
				$this->printError('Неверная валюта платежа '.POST('ik_cur'));
			}

			if (POST('ik_inv_st') != 'success') {
				$this->printError('Неуспешный платеж '.POST('ik_inv_st'));
			}
			
			if (POST('ik_sign') != $this->signData($_POST)) {
				$this->printError('Неверная подпись '.POST('ik_sign'));
			}

			
			$invoice_id = (int)POST('ik_pm_no');
			
			if (!$invoice_row = $this->webcash->getRowById($this->webcash->gateway_invoices_table, $invoice_id)) {
				$this->printError('Нет такого инвойса');
			}
			
			if ($invoice_row['state']) {
				$this->printError('Инвойс уже оплачен');
			}

			if ($invoice_row['gateway'] != $this->alias) {
				$this->printError('Инвойс не той платежной системы');
			}
			
			if ((float)POST('ik_am') < $invoice_row['amount']) {
				$this->printError('Неверная сумма: '.POST('ik_am'));
			}
			
			
			$payment_id = $this->processAfterPayment($invoice_id);
			
			
			if ($payment_row = $this->webcash->getRowById($this->webcash->gateway_payments_table, $payment_id)) {
				$this->checkout->gatewaySuccessPayment($invoice_row, $payment_row);
				
				//fs_log("Инвойс #" . $invoice_id . " оплачен!");
				exit;
			}

			$this->printError('Error '.__LINE__);
		} else {
			$this->printError('Не указаны необходимые данные');
		}
	}
	
	public function printError($text) {
		$text = 'Ошибка! '.$text;
		header('HTTP/1.1 500 Internal Server Error');//в случае неуспеха - сервис сделает до 13-ти повторных попыток на протяжении 3-х дней
		if (WebCash::DEBUG_SETTINGS) {
			fs_log('Merchant error ('.$this->alias.'): '.$text);
			echo $text;
		}
		exit;
	}
	
	public function processAfterPayment($invoice_id) {
		$gateway_details_arr = POST();
		$gateway_details_arr = array_map(array($this->helper, 'htmlspecialchars'), $gateway_details_arr);
		if (!$sender = POST('ik_cli'))
			$sender = POST('ik_inv_id');
		
		return $this->checkout->addPaymentToDb($invoice_id, $sender, $gateway_details_arr);
	}
	
	public function getServiceInfo() {
		$result = array(
			'name' => __('Интеркасса'),
			'alias' => $this->alias,
			//'items' => $this->arrayKeyId(),LAST
			'items' => array(
				1 => array(
					'title' => __('Перейти к оплате'),
					'image' => 'interkassa_logo.gif',
				),
			),
		);
		
		return $result;
	}

}