<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

class Gateways_Admin_InterKassa extends Admin_AddonSettings
{
	protected $base_alias = 'interkassa';
	
	public function getGwItemsTblColumns() {
		$tbl_columns = array();
		
		$tbl_columns['nosort1']['column'] = __('№');
		$tbl_columns['title']['column'] = __('Заголовок');
		$tbl_columns['image']['column'] = __('Лого');
		$tbl_columns['lmi_allow_sdp']['column'] = __('LMI_ALLOW_SDP');
		$tbl_columns['lmi_sdp_type']['column'] = __('LMI_SDP_TYPE');
		$tbl_columns['at']['column'] = __('Параметр &laquo;at&raquo;');
		$tbl_columns['description']['column'] = __('Описание');
		$tbl_columns['created']['column'] = __('Дата');
		$tbl_columns['state']['column'] = __('Статус');
		$tbl_columns['nosort2']['column'] = __('Действие');

		$tbl_columns['id']['column'] = __('ID');
		
		
		$tbl_columns = $this->endHandleTblColumns($tbl_columns, 'gw_items_tbl_columns_list');
		
		return $tbl_columns;
	}
	
	public function listGwItems() {
		$base_instance = $this->getBaseInstance();
		
		if (!$total_count = $this->db->selectCell("SELECT COUNT(*) FROM {$base_instance->table_a}"))
			return __('Нет записей');
		
        if ($rows = $this->db->select("SELECT * FROM {$base_instance->table_a}".$base_instance->getItemsOrderBy())) {
		
			$tbl_columns = $this->getGwItemsTblColumns();
			
			$html = '
			<div class="table-responsive">

				<table class="table table-xs table-hover">
					
					'.$this->renderItemsTableThead($tbl_columns).'
					
					<tbody>';
				
				foreach ($rows as $index => $row) {
				
					$edit_start_tag = '<a href="'.$base_instance->getAddonSettingsUrl('&tab2=2&id='.$row['id']).'" title="'.__('Редактировать метод оплаты').'">';
					
					$html .= '<tr>';
					
					if ($tbl_columns['nosort1']['state'])
						$html .= '<td>'.($index + 1).'</td>';
					if ($tbl_columns['title']['state'])
						$html .= '<td>'.$edit_start_tag.$row['title'].'</a></td>';
					if ($tbl_columns['image']['state'])
						$html .= '<td>'.($row['image'] ? '<img src="'.$this->webcash->module_url.'/gateways/interkassa/assets/images/'.$row['image'].'" alt="" style="max-width:30px;" class="simple-lightbox">' : '--//--').'</td>';
					if ($tbl_columns['lmi_allow_sdp']['state'])
						$html .= '<td>'.$row['LMI_ALLOW_SDP'].'</td>';
					if ($tbl_columns['lmi_sdp_type']['state'])
						$html .= '<td>'.$row['LMI_SDP_TYPE'].'</td>';
					if ($tbl_columns['at']['state'])
						$html .= '<td>'.$row['at'].'</td>';
					if ($tbl_columns['description']['state'])
						$html .= '<td>'.($row['description'] ? $row['description'] : '--//--').'</td>';
					if ($tbl_columns['created']['state'])
						$html .= '<td class="text-center">'.$row['created'].'</td>';
					if ($tbl_columns['state']['state'])
						$html .= '<td class="text-center"><i title="'.($row['state'] ? __('Опубликован') : __('Снят с публикации')).'" class="fa fa-exclamation-circle tip '.($row['state'] ? 'text-success' : 'text-danger').'"></i></td>';
					if ($tbl_columns['nosort2']['state'])
						$html .= '
						<td class="text-center">
							<a href="#" data-do="ajax-webcash" data-vars="action=ajax.plugin.from_tab2|subaction=delete|id='.$row['id'].'|plg_alias='.$base_instance->alias.'"'.($base_instance->item_delete_button_confirm ? ' data-confirm="1"' : '').' title="'.__('Удалить запись').'"><i class="fa fa-trash-o text-danger position-left"></i></a>'.$edit_start_tag.'<i class="fa fa-pencil"></i></a>
						</td>';
					if ($tbl_columns['id']['state'])
						$html .= '<td class="text-center">'.$row['id'].'</td>';
					
					$html .= '</tr>';
				}
				
				$html .= '
					</tbody>
				</table>
				
				'.$pagination_html.'
				
			</div>';
		
			return $html;
		}
	}
	
	public function getPaymentsApi() {
		$base_instance = $this->getBaseInstance();
		$payment_systems = array();
		$host = 'https://api.interkassa.com/v1/paysystem-input-payway?checkoutId='.$base_instance->ik_merchant_id;
		$username = $base_instance->api_id;
		$password = $base_instance->api_key;
		
		$business_acc = $this->getIkBusinessAcc($username, $password);
		$headers = array();
        $headers[] = 'Authorization: Basic '.base64_encode("{$username}:{$password}");
        
		if (!empty($business_acc)) {
			$headers[] = 'Ik-Api-Account-Id: '.$business_acc;
        }
		
		$ch = curl_init($host);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		$response = curl_exec($ch);
		
		if (!empty($response)) {
			$json = json_decode($response);
			if ($json->status == 'ok' and $json->code == 0) {
				$payways = $json->data;
			}
		}
		
		if (!empty($payways)) {
			foreach ($payways as $ps => $info) {
				$payment_system = $info->ser;
				if (!array_key_exists($payment_system, $payment_systems)) {
					$payment_systems[$payment_system] = array();
					foreach ($info->name as $name) {
						if ($name->l == 'en') {
							$payment_systems[$payment_system]['title'] = ucfirst($name->v);
						}
						
						$payment_systems[$payment_system]['name'][$name->l] = $name->v;
					}
				}
				
				$payment_systems[$payment_system]['currency'][strtoupper($info->curAls)] = $info->als;
			}
		}
		
		return $payment_systems;
	}
	
	public function getIkBusinessAcc($username, $password) {
		$cache_key = $this->getBaseInstance()->getCacheKey('account');
		$data = $this->helper->getCache($cache_key, 3600 * 24 * 30, true);
		
		if (!$business_acc = safe_array_access($data, 'business_acc') or sha1($username.$password) !== safe_array_access($data, 'hash')) {
			$curl = curl_init();
			curl_setopt($curl, CURLOPT_URL, 'https://api.interkassa.com/v1/account');
			curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
			curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($curl, CURLOPT_FOLLOWLOCATION, false);
			curl_setopt($curl, CURLOPT_HEADER, false);
			curl_setopt($curl, CURLOPT_HTTPHEADER, array('Authorization: Basic '.base64_encode("{$username}:{$password}")));
			
			$response = curl_exec($curl);
			
			if ($response) {
				$json = json_decode($response, true);
				
				if ($json['status'] == 'ok') {
					if (!empty($json['data'])) {
						foreach ($json['data'] as $id => $value) {
							if ($value['tp'] == 'b') {
								$business_acc = $id;
								break;
							}
						}
					}
					
					$arr = array(
						'business_acc' => $business_acc,
						'hash' => sha1($username.$password)
					);
					
					$this->helper->putCache($cache_key, $arr, true);
					
				} elseif ($json['status'] == 'error') {
					$this->webcash->exitMsg($json['message']);
				}
				
			} else {
				$this->webcash->exitMsg('Пустой ответ сервера');
			}
		}

		return $business_acc;
	}
	
}