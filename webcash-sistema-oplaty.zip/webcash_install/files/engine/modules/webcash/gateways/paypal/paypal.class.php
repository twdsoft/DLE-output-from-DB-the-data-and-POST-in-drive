<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

class Gateways_Paypal extends AddonSettings
{
	protected $alias = 'paypal';
	
    public function renderPaymentForm($invoice_id, $cs_key, $gw_item_id) {
		if ($str = $this->verifyGatewayEnable())
			return $str;
		
		if (!$checkout_store = $this->checkout->getDataStore($cs_key))
			return '';
		
		$service_info = $this->getServiceInfo();
		
		if (!$gw_item = safe_array_access($service_info, 'items', $gw_item_id))
			trigger_error(basename(__FILE__).', line: '.__LINE__, E_USER_ERROR);
		
		$amount = $this->wc_currency->convertMainCurrencyTo($checkout_store['amount'], $this->currency);
		
		$tpl = $this->webcash->getTplInstance();
		$tpl->assign('invoice_id', $invoice_id);
		$tpl->assign('amount', number_format($amount, 2, '.', ''));
		$tpl->assign('item_name', to_utf8(safe_array_access($checkout_store, 'checkout_header')));
		$tpl->assign('email', $this->helper->htmlspecialchars(safe_array_access($checkout_store, 'email')));
		$tpl->assign('processing_url', $this->checkout->getGatewayProcessingUrl($this->alias));
		$tpl->assign('success_url', $this->checkout->successCheckoutUrl($invoice_id, $cs_key));
		$tpl->assign('fail_url', $this->checkout->failCheckoutUrl($invoice_id, $cs_key));
		$tpl->assign('gateway_header', $service_info['name']);
		$tpl->assign('gw_alias', $this->alias);
		$tpl->assign('gateway_cfg', $this->getCfgPublicParams());
		$tpl->assign('addon_settings_link', $this->renderAddonSettingsLink());
		$tpl->assign('user_hash', $this->user->nonce);
		$tpl->load_template('/modules/webcash/gateways/paypal/checkout.tpl');
		
		$tpl->compile('content');
		
		return $tpl->result['content'];
	}
	
    public function verifyTransaction($source_array) {
		if (WebCash::DEBUG_SETTINGS)
			return true;
		
		// read the post from PayPal system and add 'cmd'
		$req = 'cmd=_notify-validate';
		
		foreach ($source_array as $key => $value) {
			$value = urlencode(stripslashes($value));
			$req .= "&{$key}={$value}";
		}

		// post back to PayPal system to validate
		$header = "POST /cgi-bin/webscr HTTP/1.0\r\n";
		$header .= "Host: www.paypal.com\r\n";
		$header .= "User-Agent: PHP-IPN-VerificationScript\r\n";
		$header .= "Content-Type: application/x-www-form-urlencoded\r\n";
		$header .= "Content-Length: ".strlen($req)."\r\n";
		$header .= "Connection: Close\r\n\r\n";
		
		$fp = fsockopen('ssl://www.paypal.com', 443, $errno, $errstr, 30);
		
		if ($fp) {
			fputs($fp, $header.$req);
			
			while (!feof($fp)) {
				$res = fgets($fp, 1024);
				
				if (strcmp($res, 'VERIFIED') == 0) {
					return true;
				} elseif (strcmp($res, 'INVALID') == 0) {
					return false;
				}
			}
			
			fclose ($fp);
		}
		
		return false;
	}
	
	public function processing() {
		if (!empty($_POST)) {
			$this->readSettingsFromFile();
			
			$invoice_id = (int)POST('custom');
			
			if (!$invoice_row = $this->webcash->getRowById($this->webcash->gateway_invoices_table, $invoice_id)) {
				$this->printError('Нет такого инвойса');
			}
			
			if ($invoice_row['state']) {
				$this->printError('Инвойс уже оплачен');
			}

			if ($invoice_row['gateway'] != $this->alias) {
				$this->printError('Инвойс не той платежной системы');
			}
			
			
			$amount = $this->wc_currency->convertMainCurrencyTo($invoice_row['amount'], $this->currency);
			$amount = number_format($amount, 2, '.', '');
			
			if (!POST('mc_gross')) {
				$this->printError('Нулевая сумма.');
			} elseif (POST('mc_gross') < $amount) {
				$this->printError('Неверная сумма: '.POST('mc_gross'));
			} elseif (POST('mc_currency') != $this->currency) {
				$this->printError('Неверная валюта платежа: '.POST('mc_currency'));
			} elseif (POST('payment_status') !== 'Completed') {
				$this->printError('Неверный статус платежа: '.POST('payment_status'));
			} elseif (POST('txn_type') !== 'web_accept') {
				$this->printError('Неверный тип платежа: '.POST('txn_type'));
			} elseif (POST('receiver_email') != $this->paypal_account) {
				$this->printError('Неверный получатель платежа: '.POST('receiver_email'));
			}

			
			if (!$this->verifyTransaction($_POST)) {
				$this->printError('Транзакция не подтверждена');
			}
			
			
			$payment_id = $this->processAfterPayment($invoice_id);
			
			if ($payment_row = $this->webcash->getRowById($this->webcash->gateway_payments_table, $payment_id)) {
				$this->checkout->gatewaySuccessPayment($invoice_row, $payment_row);

				//fs_log("Инвойс #" . $invoice_id . " оплачен!");
				
				header('HTTP/1.1 200 OK');
				echo 'Invoice #'.$invoice_id.' successfully paid';
				exit;
			}

			$this->printError('Error '.__LINE__);
		} else {
			$this->webcash->siteMsgError('Не указаны необходимые данные');
		}
	}
	
	public function printError($text) {
		$text = 'Ошибка! '.$text;
		//fs_log('Merchant error ('.$this->alias.'): '.$text);
		header('HTTP/1.1 500 Internal Server Error');
		echo $text;
		exit;
	}
	
	public function processAfterPayment($invoice_id) {
		$gateway_details_arr = array(
			'payer_id' => POST('payer_id'),
			'payer_status' => POST('payer_status'),
			'payer_email' => POST('payer_email'),
			'receiver_id' => POST('receiver_id'),
			'address_country' => POST('address_country'),
			'address_city' => POST('address_city'),
			'address_street' => POST('address_street'),
			'address_status' => POST('address_status'),
			'payment_date' => POST('payment_date'),
			'payment_status' => POST('payment_status'),
			'payment_fee' => POST('payment_fee'),
			'mc_gross' => POST('mc_gross'),
			'mc_currency' => POST('mc_currency'),
			'txn_id' => POST('txn_id'),
			'ipn_track_id' => POST('ipn_track_id'),
		);
		
		$gateway_details_arr = array_map(array($this->helper, 'htmlspecialchars'), $gateway_details_arr);
		
		return $this->checkout->addPaymentToDb($invoice_id, POST('payer_email'), $gateway_details_arr);
	}
	
	public function getServiceInfo() {
		$result = array(
			'name' => 'Paypal',
			'alias' => $this->alias,
			'items' => array(
				1 => array(
					'title' => __('Кошелек или карта'),
					'image' => 'paypal.png',
				),
			),
		);
		
		return $result;
	}

}