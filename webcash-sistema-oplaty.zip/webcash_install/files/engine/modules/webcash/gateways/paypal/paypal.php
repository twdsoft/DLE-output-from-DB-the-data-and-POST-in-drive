<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

if (!$this->readSettingsFromFile()) {
	$this->setCfgValue('display_name', 'Платежный шлюз Paypal');
	$this->setCfgValue('description', 'С помощью этого шлюза можно организовать прием платежей через платежную систему Paypal.');
	$this->setCfgValue('paypal_account', '');
	$this->setCfgValue('currency', 'USD');
	$this->setCfgValue('site_url', 'https://paypal.com');
	$this->setCfgValue('access_allowed_usergroups', array());
	$this->setNoneFormControlCfgValue('public_cfg_fields', array(
		'paypal_account',
		'currency',
	));
	
	if (WebCash::DEBUG_SETTINGS) {
		$this->setCfgValue('paypal_account', 'danakdanak@gmail.com');
	}
	
	
	$str = $this->checkout->getGatewayProcessingUrl($this->alias);
	
	$this->addHint(__FILE__.'1', 'Внимание, перед началом работы необходимо указать логин Paypal (адрес почты), на который будут приниматься платежи. Адрес обработки запросов от мерчанта: <a href="'.$str.'" target="_blank"><code>'.$str.'</code></a>.');

	$this->setFieldsItem('paypal_account', array(
		'title' => 'Ваш логин Paypal',
		'hint' => 'Логин Paypal (адрес почты), на который будут приниматься платежи',
		'type' => 'text',
		'required' => true,
	));
	
	$arr = $this->wc_currency->getCurrenciesList();
	
	$this->setFieldsItem('currency', array(
		'title' => 'Валюта аккаунта',
		'hint' => 'Валюта которая используется в аккаунте Paypal',
		'type' => 'select',
		'value' => array_keys($arr),
		'label' => array_values($arr),
		'required' => true,
	));
	
	$this->setFieldsItem('site_url', array(
		'title' => 'Сайт провайдера',
		'hint' => 'Данный адрес используется в списке шлюзов только для удобства работы',
		'type' => 'text',
	));
	
	
	$this->convertDefaultValues();
	$this->writeSettingsInFile(true);
}