<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

$tbl_columns = $this->admin_listtransactions->getBalanceTransactionsTblColumns();
?>

<form action="" class="webcash_ajax_form form-horizontal" method="post" autocomplete="off">
	<div class="panel panel-flat">
		<div class="panel-body">
			
			<?php echo $this->adminpanel->renderCommonListPart(__FILE__, $tbl_columns); ?>
			
            <div class="dataTables_wrapper">
				<?php echo $this->admin_listtransactions->listBalanceTransactions($active_tab2); ?>
			</div>
			
		
		</div>
	</div>
	<div class="buttons_wrap">
		<input type="hidden" name="action" value="ajax.plugin.from_tab<?php echo $this::BALANCE_TRANSACTIONS_TAB; ?>" />
		<input type="hidden" name="subaction" value="" />
		<input type="hidden" name="user_hash" value="<?php echo $this->user->nonce; ?>" />
		<input type="hidden" name="plg_alias" value="<?php echo $this->alias; ?>" />
		
		<a href="#" data-do="ajax-webcash" data-vars="action=ajax.plugin.from_tab<?php echo $this::BALANCE_TRANSACTIONS_TAB; ?>|subaction=empty_balance_transactions_table|plg_alias=<?php echo $this->alias; ?>" data-confirm="1" title="<?php echo __('Очистить таблицу. Внимание, данная операция необратима!'); ?>" class="btn bg-danger btn-raised position-left btn-red">
			<i class="fa fa-trash-o position-left"></i><?php echo __('Очистить таблицу'); ?>
		</a>
		
		<?php echo $this->admin_listtransactions->filterAndSortCancelButton($active_tab2); ?>
		
	</div>
</form>