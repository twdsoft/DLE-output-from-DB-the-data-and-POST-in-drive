<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

$this->adminpanel->showRow(
	__('Разрешить доступ только этим группам пользователей'),
	__('Вы можете указать определенные пользовательские группы, которым разрешен доступ к плагину на сайте. Если не указано - то доступ по группе не будет ограничен'),
	$this->webcash->getUsergroupsMultiSelect(
		'data[access_allowed_usergroups][]',
		$this->access_allowed_usergroups
	),
	'',
	$this->col_values
);