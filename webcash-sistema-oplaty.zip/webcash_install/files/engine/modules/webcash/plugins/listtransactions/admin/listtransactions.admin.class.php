<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

class Plugins_Admin_ListTransactions extends Admin_AddonSettings
{
	protected $base_alias = 'listtransactions';
	
	public function getGatewayInvoicesTblColumns() {
		$tbl_columns = array();
		
		$tbl_columns['nosort1']['column'] = __('№');
		
		$tbl_columns['a.amount']['column'] = __('Сумма');
		$tbl_columns['a.amount']['title_part'] = __('по сумме платежа');
		
		$tbl_columns['a.gateway']['column'] = __('Шлюз');
		$tbl_columns['a.gateway']['title_part'] = __('по платежному шлюзу');
		$tbl_columns['a.gateway']['sort_alpha'] = true;
		
		$tbl_columns['a.user_id']['column'] = __('Пользователь');
		$tbl_columns['a.user_id']['title_part'] = __('по ID пользователя-плательщика');
		
		$tbl_columns['a.email']['column'] = __('Емайл');
		$tbl_columns['a.email']['title_part'] = __('по Емайлу плательщика');
		$tbl_columns['a.email']['sort_alpha'] = true;
		
		$tbl_columns['a.ip']['column'] = __('IP-адрес');
		$tbl_columns['a.ip']['title_part'] = __('по IP-адресу плательщика');
		$tbl_columns['a.ip']['sort_alpha'] = true;
		
		$tbl_columns['a.area_alias']['column'] = __('Плагин');
		$tbl_columns['a.area_alias']['title_part'] = __('по плагину');
		$tbl_columns['a.area_alias']['sort_alpha'] = true;
		
		$tbl_columns['a.rel_item_type']['column'] = __('Тип');
		$tbl_columns['a.rel_item_type']['title_part'] = __('по типу транзакции');
		$tbl_columns['a.rel_item_type']['sort_alpha'] = true;
		
		$tbl_columns['a.rel_item_id']['column'] = __('Подробнее');
		
		$tbl_columns['a.created']['column'] = __('Дата');
		$tbl_columns['a.created']['title_part'] = __('по дате платежа');
		
		$tbl_columns['a.state']['column'] = __('Статус');
		$tbl_columns['a.state']['title_part'] = __('по статусу платежа');
		$tbl_columns['a.state']['sort_alpha'] = true;
		
		$tbl_columns['nosort2']['column'] = __('Действие');
		
		$tbl_columns['a.id']['column'] = 'ID';
		$tbl_columns['a.id']['title_part'] = __('по идентификационному номеру');
		
		
		$tbl_columns = $this->endHandleTblColumns($tbl_columns, 'invoices_tbl_columns_list');
		
		return $tbl_columns;
	}
	
	public function listGatewayInvoices($tab, $sql_addon = '') {
		$sql_addon .= $sql_addon ? $this->adminfilter->makeFiltrationSQL("AND") : $this->adminfilter->makeFiltrationSQL();
		
		$total_count = $this->db->selectCell("
			SELECT COUNT(*)
			FROM {$this->webcash->gateway_invoices_table} AS a
			LEFT JOIN ".USERPREFIX."_users AS b
			ON a.user_id = b.user_id
			{$sql_addon}"
		);
		
		if (!$total_count)
			return __('Нет записей');
		
		$tbl_columns = $this->getGatewayInvoicesTblColumns();
		$sql_order_by = $this->commonInitList($total_count, $tbl_columns);
		
		$sql = "
		SELECT
			a.*,
			b.name, b.email AS b_email
			[ADDL.FIELDS]
		FROM {$this->webcash->gateway_invoices_table} AS a
		LEFT JOIN ".USERPREFIX."_users AS b
		ON a.user_id = b.user_id
		[ADDL.JOIN]
		{$sql_addon}
		{$sql_order_by}
		{$this->pager->limit}";
		
		$sql = $this->insertAdditional($sql, $tbl_columns, 'rows_sql');
		
        if ($rows = $this->db->select($sql)) {
		
			$this->pager->set('items_count', count($rows));
			$pagination_html = $this->pager->renderPaginationHtml();
			$pagination_info = $this->pager->getServiceInfo();
			$base_instance = $this->getBaseInstance();
			
			$html = '
			<div class="table-responsive">
			
				<table class="table table-xs table-hover">
					
					'.$this->renderItemsTableThead($tbl_columns).'
					
					<tbody>';

				foreach ($rows as $index => $row) {
					
					$this->adminfilter->set('filter_data|row', $row);
					
					$html .= '<tr>';
					
					
					if ($tbl_columns['nosort1']['state'])
						$html .= '<td>'.($index + $pagination_info['index']).'</td>';
					if ($tbl_columns['a.amount']['state'])
						$html .= '<td>'.$this->adminfilter->makeFiltrationLinkByKey('a.amount', $this->wc_currency->currCnvShort($row['amount'])).'</td>';
					if ($tbl_columns['a.gateway']['state'])
						$html .= '<td>'.$this->adminfilter->makeFiltrationLinkByKey('a.gateway', $this->webcash->getAddonInstanceByAlias($row['gateway'])->getServiceInfo()['name']).'</td>';
					if ($tbl_columns['a.user_id']['state'])
						$html .= '<td>'.$this->adminfilter->makeFiltrationLinkByKey('a.user_id', $row['name']).'</td>';
					if ($tbl_columns['a.email']['state'])
						$html .= '<td>'.$this->adminfilter->makeFiltrationLinkByKey('a.email').'</td>';
					if ($tbl_columns['a.ip']['state'])
						$html .= '<td>'.$this->adminfilter->makeFiltrationLinkByKey('a.ip').'</td>';
					
					
					$html .= $this->getGatewayInvoicesTblTds($tbl_columns, $row);
					
					
					if ($tbl_columns['a.state']['state'])
						$html .= '<td class="text-center">'.$this->adminfilter->makeFiltrationLinkByKey('a.state', '<i title="'.($row['state'] ? __('Успешно завершен') : __('Не завершен')).'" class="fa fa-exclamation-circle tip '.($row['state'] ? 'text-success' : 'text-danger').'"></i>').'</td>';
					if ($tbl_columns['nosort2']['state'])
						$html .= '
						<td class="text-center">
							<a href="#" data-do="ajax-webcash" data-vars="action=ajax.plugin.from_tab'.$tab.'|subaction=delete|id='.$row['id'].'|plg_alias='.$base_instance->alias.'"'.($base_instance->item_delete_button_confirm ? ' data-confirm="1"' : '').' title="'.__('Удалить запись').'"><i class="fa fa-trash-o text-danger position-left"></i></a>
						</td>';
					if ($tbl_columns['a.id']['state'])
						$html .= '<td>'.$row['id'].'</td>';
					
					$html .= '</tr>';
				}
				
				$html .= '
					</tbody>
				</table>
				
				'.$pagination_html.'
				
			</div>';
		
			return $html;
		}
	}
	
	public function getGatewayPaymentsTblColumns() {
		$tbl_columns = array();
		
		$tbl_columns['nosort1']['column'] = __('№');
		
		$tbl_columns['a.amount']['column'] = __('Сумма');
		$tbl_columns['a.amount']['title_part'] = __('по сумме платежа');
		
		$tbl_columns['a.gateway']['column'] = __('Шлюз');
		$tbl_columns['a.gateway']['title_part'] = __('по платежному шлюзу');
		$tbl_columns['a.gateway']['sort_alpha'] = true;
		
		$tbl_columns['a.user_id']['column'] = __('Пользователь');
		$tbl_columns['a.user_id']['title_part'] = __('по ID пользователя-плательщика');
		
		$tbl_columns['a.email']['column'] = __('Емайл');
		$tbl_columns['a.email']['title_part'] = __('по Емайлу плательщика');
		$tbl_columns['a.email']['sort_alpha'] = true;
		
		$tbl_columns['a.ip']['column'] = __('IP-адрес');
		$tbl_columns['a.ip']['title_part'] = __('по IP-адресу плательщика');
		$tbl_columns['a.ip']['sort_alpha'] = true;
		
		$tbl_columns['a.invoice_id']['column'] = __('Инвойс');
		
		$tbl_columns['a.area_alias']['column'] = __('Плагин');
		$tbl_columns['a.area_alias']['title_part'] = __('по плагину');
		$tbl_columns['a.area_alias']['sort_alpha'] = true;
		
		$tbl_columns['a.rel_item_type']['column'] = __('Тип');
		$tbl_columns['a.rel_item_type']['title_part'] = __('по типу транзакции');
		$tbl_columns['a.rel_item_type']['sort_alpha'] = true;
		
		$tbl_columns['a.rel_item_id']['column'] = __('Подробнее');
		
		$tbl_columns['a.created']['column'] = __('Дата');
		$tbl_columns['a.created']['title_part'] = __('по дате платежа');
		
		$tbl_columns['a.state']['column'] = __('Статус');
		$tbl_columns['a.state']['title_part'] = __('по статусу платежа');
		$tbl_columns['a.state']['sort_alpha'] = true;
		
		$tbl_columns['nosort2']['column'] = __('Действие');
		
		$tbl_columns['a.id']['column'] = 'ID';
		$tbl_columns['a.id']['title_part'] = __('по идентификационному номеру');
		
		
		$tbl_columns = $this->endHandleTblColumns($tbl_columns, 'payments_tbl_columns_list');
		
		return $tbl_columns;
	}
	
	public function listGatewayPayments($tab, $sql_addon = '') {
		$sql_addon .= $sql_addon ? $this->adminfilter->makeFiltrationSQL("AND") : $this->adminfilter->makeFiltrationSQL();
		
		$total_count = $this->db->selectCell("
			SELECT COUNT(*)
			FROM {$this->webcash->gateway_payments_table} AS a
			LEFT JOIN ".USERPREFIX."_users AS b
			ON a.user_id = b.user_id
			{$sql_addon}"
		);
		
		if (!$total_count)
			return __('Нет записей');
		
		$tbl_columns = $this->getGatewayPaymentsTblColumns();
		$sql_order_by = $this->commonInitList($total_count, $tbl_columns);
		
		$sql = "
		SELECT
			a.*,
			b.name, b.email AS b_email
			[ADDL.FIELDS]
		FROM {$this->webcash->gateway_payments_table} AS a
		LEFT JOIN ".USERPREFIX."_users AS b
		ON a.user_id = b.user_id
		[ADDL.JOIN]
		{$sql_addon}
		{$sql_order_by}
		{$this->pager->limit}";
		
		$sql = $this->insertAdditional($sql, $tbl_columns, 'rows_sql');
		
        if ($rows = $this->db->select($sql)) {
		
			$this->pager->set('items_count', count($rows));
			$pagination_html = $this->pager->renderPaginationHtml();
			$pagination_info = $this->pager->getServiceInfo();
			$base_instance = $this->getBaseInstance();
			
			$html = '
			<div class="table-responsive">
			
				<table class="table table-xs table-hover">
					
					'.$this->renderItemsTableThead($tbl_columns).'
					
					<tbody>';

				foreach ($rows as $index => $row) {
					
					$this->adminfilter->set('filter_data|row', $row);
					
					$html .= '<tr>';
					
					
					if ($tbl_columns['nosort1']['state'])
						$html .= '<td>'.($index + $pagination_info['index']).'</td>';
					if ($tbl_columns['a.amount']['state'])
						$html .= '<td>'.$this->adminfilter->makeFiltrationLinkByKey('a.amount', $this->wc_currency->currCnvShort($row['amount'])).'</td>';
					if ($tbl_columns['a.gateway']['state']) {
						$arr = $this->webcash->getAddonInstanceByAlias($row['gateway'])->getServiceInfo();
						$html .= '<td>'.$this->adminfilter->makeFiltrationLinkByKey('a.gateway', $arr['name']).'</td>';
					}
					if ($tbl_columns['a.user_id']['state'])
						$html .= '<td>'.$this->adminfilter->makeFiltrationLinkByKey('a.user_id', $row['name']).'</td>';
					if ($tbl_columns['a.email']['state'])
						$html .= '<td>'.$this->adminfilter->makeFiltrationLinkByKey('a.email').'</td>';
					if ($tbl_columns['a.ip']['state'])
						$html .= '<td>'.$this->adminfilter->makeFiltrationLinkByKey('a.ip').'</td>';
					if ($tbl_columns['a.invoice_id']['state'])
						$html .= '<td><a href="'.$base_instance->getAddonSettingsUrl('&tab2='.Plugins_ListTransactions::INVOICES_TAB.'&filter=field&val[a.id]='.$row['invoice_id']).'" title="'.__('Перейти к соответствующей записи таблицы инвойсов').'">ID'.$row['invoice_id'].'</a></td>';
					
					
					$html .= $this->getGatewayPaymentsTblTds($tbl_columns, $row);
					
					
					if ($tbl_columns['a.state']['state'])
						$html .= '<td class="text-center">'.$this->adminfilter->makeFiltrationLinkByKey('a.state', '<i title="'.($row['state'] ? __('Успешно завершен') : __('Не завершен')).'" class="fa fa-exclamation-circle tip '.($row['state'] ? 'text-success' : 'text-danger').'"></i>').'</td>';
					if ($tbl_columns['nosort2']['state'])
						$html .= '
						<td class="text-center">
							<a href="#" data-do="ajax-webcash" data-vars="action=ajax.plugin.from_tab'.$tab.'|subaction=delete|id='.$row['id'].'|plg_alias='.$base_instance->alias.'"'.($base_instance->item_delete_button_confirm ? ' data-confirm="1"' : '').' title="'.__('Удалить запись').'"><i class="fa fa-trash-o text-danger position-left"></i></a>
						</td>';
					if ($tbl_columns['a.id']['state'])
						$html .= '<td>'.$row['id'].'</td>';
					
					$html .= '</tr>';
				}
				
				$html .= '
					</tbody>
				</table>
				
				'.$pagination_html.'
				
			</div>';
		
			return $html;
		}
	}
	
	public function getBalanceTransactionsTblColumns() {
		$tbl_columns = array();
		
		$tbl_columns['nosort1']['column'] = __('№');
		
		$tbl_columns['a.amount']['column'] = __('Сумма');
		$tbl_columns['a.amount']['title_part'] = __('по сумме платежа');
		
		$tbl_columns['a.user_id']['column'] = __('Пользователь');
		$tbl_columns['a.user_id']['title_part'] = __('по ID пользователя-плательщика');
		
		$tbl_columns['a.email']['column'] = __('Емайл');
		$tbl_columns['a.email']['title_part'] = __('по Емайлу плательщика');
		$tbl_columns['a.email']['sort_alpha'] = true;
		
		$tbl_columns['a.is_plus']['column'] = __('Направление');
		$tbl_columns['a.is_plus']['title_part'] = __('по направлению транзакции (приход/расход)');
		$tbl_columns['a.is_plus']['sort_alpha'] = true;
		
		$tbl_columns['a.area_alias']['column'] = __('Плагин');
		$tbl_columns['a.area_alias']['title_part'] = __('по плагину');
		$tbl_columns['a.area_alias']['sort_alpha'] = true;
		
		$tbl_columns['a.rel_item_type']['column'] = __('Тип');
		$tbl_columns['a.rel_item_type']['title_part'] = __('по типу транзакции');
		$tbl_columns['a.rel_item_type']['sort_alpha'] = true;
		
		$tbl_columns['a.rel_item_id']['column'] = __('Подробнее');
		
		$tbl_columns['a.created']['column'] = __('Дата');
		$tbl_columns['a.created']['title_part'] = __('по дате платежа');
		
		$tbl_columns['a.state']['column'] = __('Статус');
		$tbl_columns['a.state']['title_part'] = __('по статусу платежа');
		$tbl_columns['a.state']['sort_alpha'] = true;
		
		$tbl_columns['nosort2']['column'] = __('Действие');
		
		$tbl_columns['a.id']['column'] = 'ID';
		$tbl_columns['a.id']['title_part'] = __('по идентификационному номеру');
		
		
		$tbl_columns = $this->endHandleTblColumns($tbl_columns, 'balance_transactions_tbl_columns_list');
		
		return $tbl_columns;
	}
	
	public function listBalanceTransactions($tab, $sql_addon = '') {
		$sql_addon .= $sql_addon ? $this->adminfilter->makeFiltrationSQL("AND") : $this->adminfilter->makeFiltrationSQL();
		
		$total_count = $this->db->selectCell("
			SELECT COUNT(*)
			FROM {$this->webcash->balance_transactions_table} AS a
			LEFT JOIN ".USERPREFIX."_users AS b
			ON a.user_id = b.user_id
			{$sql_addon}"
		);
		
		if (!$total_count)
			return __('Нет записей');
		
		$tbl_columns = $this->getBalanceTransactionsTblColumns();
		$sql_order_by = $this->commonInitList($total_count, $tbl_columns);
		
		$sql = "
		SELECT
			a.*,
			b.name, b.email
			[ADDL.FIELDS]
		FROM {$this->webcash->balance_transactions_table} AS a
		LEFT JOIN ".USERPREFIX."_users AS b
		ON a.user_id = b.user_id
		[ADDL.JOIN]
		{$sql_addon}
		{$sql_order_by}
		{$this->pager->limit}";
		
		$sql = $this->insertAdditional($sql, $tbl_columns, 'rows_sql');
		
        if ($rows = $this->db->select($sql)) {
		
			$this->pager->set('items_count', count($rows));
			$pagination_html = $this->pager->renderPaginationHtml();
			$pagination_info = $this->pager->getServiceInfo();
			$base_instance = $this->getBaseInstance();
			
			$html = '
			<div class="table-responsive">
			
				<table class="table table-xs table-hover">
					
					'.$this->renderItemsTableThead($tbl_columns).'
					
					<tbody>';

				foreach ($rows as $index => $row) {
					
					$this->adminfilter->set('filter_data|row', $row);
					
					$html .= '<tr>';
					
					
					if ($tbl_columns['nosort1']['state'])
						$html .= '<td>'.($index + $pagination_info['index']).'</td>';
					if ($tbl_columns['a.amount']['state'])
						$html .= '<td>'.$this->adminfilter->makeFiltrationLinkByKey('a.amount', $this->wc_currency->currCnvShort($row['amount'])).'</td>';
					if ($tbl_columns['a.user_id']['state'])
						$html .= '<td>'.$this->adminfilter->makeFiltrationLinkByKey('a.user_id', $row['name']).'</td>';
					if ($tbl_columns['a.email']['state'])
						$html .= '<td>'.$this->adminfilter->makeFiltrationLinkByKey('a.email').'</td>';
					if ($tbl_columns['a.is_plus']['state'])
						$html .= '<td>'.$this->adminfilter->makeFiltrationLinkByKey('a.is_plus',  $row['is_plus'] ? __('Приход') : __('Расход')).'</td>';
					
					
					$html .= $this->getBalanceTransactionsTblTds($tbl_columns, $row);
					
					
					if ($tbl_columns['a.state']['state'])
						$html .= '<td class="text-center">'.$this->adminfilter->makeFiltrationLinkByKey('a.state', '<i title="'.($row['state'] ? __('Успешно завершен') : __('Не завершен')).'" class="fa fa-exclamation-circle tip '.($row['state'] ? 'text-success' : 'text-danger').'"></i>').'</td>';
					if ($tbl_columns['nosort2']['state'])
						$html .= '
						<td class="text-center">
							<a href="#" data-do="ajax-webcash" data-vars="action=ajax.plugin.from_tab'.$tab.'|subaction=delete|id='.$row['id'].'|plg_alias='.$base_instance->alias.'"'.($base_instance->item_delete_button_confirm ? ' data-confirm="1"' : '').' title="'.__('Удалить запись').'"><i class="fa fa-trash-o text-danger position-left"></i></a>
						</td>';
					if ($tbl_columns['a.id']['state'])
						$html .= '<td>'.$row['id'].'</td>';
					
					$html .= '</tr>';
				}
				
				$html .= '
					</tbody>
				</table>
				
				'.$pagination_html.'
				
			</div>';
		
			return $html;
		}
	}
	
	public function getOneTimePaymentsTblColumns() {
		$tbl_columns = array();
		
		$tbl_columns['nosort1']['column'] = __('№');

		$tbl_columns['a.amount']['column'] = __('Сумма');
		$tbl_columns['a.amount']['title_part'] = __('по сумме платежа');
		
		$tbl_columns['a.email']['column'] = __('Емайл');
		$tbl_columns['a.email']['title_part'] = __('по Емайлу плательщика');
		$tbl_columns['a.email']['sort_alpha'] = true;
		
		$tbl_columns['a.user_id']['column'] = __('Пользователь');
		$tbl_columns['a.user_id']['title_part'] = __('по ID пользователя-плательщика');
		
		$tbl_columns['a.pay_source']['column'] = __('Источник платежа');
		$tbl_columns['a.pay_source']['title_part'] = __('по источнику платежа');
		
		$tbl_columns['a.pay_source_entry_id']['column'] = __('Подробнее');
		
		$tbl_columns['a.created']['column'] = __('Дата');
		$tbl_columns['a.created']['title_part'] = __('по дате платежа');
		
		$tbl_columns['a.state']['column'] = __('Статус');
		$tbl_columns['a.state']['title_part'] = __('по статусу платежа');
		$tbl_columns['a.state']['sort_alpha'] = true;
		
		$tbl_columns['nosort2']['column'] = __('Действие');
		
		$tbl_columns['a.id']['column'] = 'ID';
		$tbl_columns['a.id']['title_part'] = __('по идентификационному номеру');
		
		
		$tbl_columns = $this->endHandleTblColumns($tbl_columns, 'one_time_payments_tbl_columns_list');
		
		return $tbl_columns;
	}
	
	public function listOneTimePayments() {
		$sql_common = "
		FROM
		(
			SELECT
				a.id, a.amount, a.email AS email, a.user_id, a.created, a.state, a.area_alias, a.rel_item_type,
				b.name,
				".WebCash::PAY_SOURCE_GATEWAY." AS pay_source, a.id AS pay_source_entry_id
			FROM {$this->webcash->gateway_payments_table} AS a
			LEFT JOIN ".USERPREFIX."_users AS b
			ON a.user_id = b.user_id
			
			UNION
			
			SELECT
				a.id, a.amount, b.email AS email, a.user_id, a.created, a.state, a.area_alias, a.rel_item_type,
				b.name,
				".WebCash::PAY_SOURCE_BALANCE." AS pay_source, a.id AS pay_source_entry_id
			FROM {$this->webcash->balance_transactions_table} AS a
			LEFT JOIN ".USERPREFIX."_users AS b
			ON a.user_id = b.user_id
		) AS a";
		
		$base_instance = $this->getBaseInstance();
        $reflector = new \ReflectionClass($base_instance);
        $rel_item_type = $reflector->getConstant('ONE_TIME_PAYMENT');
		
		$sql_addon = "WHERE a.area_alias = '{$base_instance->alias}' AND a.rel_item_type = '{$rel_item_type}'";
		$sql_addon .= $this->adminfilter->makeFiltrationSQL("AND");
		
		
		$total_count = $this->db->selectCell("
			SELECT COUNT(*)
			{$sql_common}
			{$sql_addon}"
		);
		
		if (!$total_count)
			return __('Нет записей');
		
		$tbl_columns = $this->getOneTimePaymentsTblColumns();
		$sql_order_by = $this->commonInitList($total_count, $tbl_columns);
		
        if ($rows = $this->db->select("
			SELECT *
			{$sql_common}
			{$sql_addon}
			{$sql_order_by}
			{$this->pager->limit}"
		)) {
		
			$this->pager->set('items_count', count($rows));
			$pagination_html = $this->pager->renderPaginationHtml();
			$pagination_info = $this->pager->getServiceInfo();
			
			$html = '
			<div class="table-responsive">
			
				<table class="table table-xs table-hover">
					
					'.$this->renderItemsTableThead($tbl_columns).'
					
					<tbody>';

				foreach ($rows as $index => $row) {
					
					$this->adminfilter->set('filter_data|row', $row);
					
					$html .= '<tr>';
					
					
					if ($tbl_columns['nosort1']['state'])
						$html .= '<td>'.($index + $pagination_info['index']).'</td>';
					if ($tbl_columns['a.amount']['state'])
						$html .= '<td>'.$this->adminfilter->makeFiltrationLinkByKey('a.amount', $this->wc_currency->currCnvShort($row['amount'])).'</td>';
					if ($tbl_columns['a.email']['state'])
						$html .= '<td>'.$this->adminfilter->makeFiltrationLinkByKey('a.email').'</td>';
					if ($tbl_columns['a.user_id']['state'])
						$html .= '<td>'.$this->adminfilter->makeFiltrationLinkByKey('a.user_id', $row['name']).'</td>';
					if ($tbl_columns['a.pay_source']['state'])
						$html .= '<td>'.$this->adminfilter->makeFiltrationLinkByKey('a.pay_source', __($this->webcash->getConst('pay_sources|'.$row['pay_source'].'|title'))).'</td>';
					if ($tbl_columns['a.pay_source_entry_id']['state'])
						$html .= '<td>'.$this->adminpanel->makePaySourceLink($row).'</td>';
					if ($tbl_columns['a.created']['state'])
						$html .= '<td class="text-center">'.$this->adminfilter->makeFiltrationLinkByKey('a.created').'</td>';
					if ($tbl_columns['a.state']['state'])
						$html .= '<td class="text-center">'.$this->adminfilter->makeFiltrationLinkByKey('a.state', '<i title="'.($row['state'] ? __('Успешно завершен') : __('Не завершен')).'" class="fa fa-exclamation-circle tip '.($row['state'] ? 'text-success' : 'text-danger').'"></i>').'</td>';
					if ($tbl_columns['nosort2']['state'])
						$html .= '
						<td class="text-center">
							<a href="#" data-do="ajax-webcash" data-vars="action=ajax.plugin.from_tab4|subaction=delete|id='.$row['id'].'|pay_source='.$row['pay_source'].'|plg_alias='.$base_instance->alias.'"'.($base_instance->item_delete_button_confirm ? ' data-confirm="1"' : '').' title="'.__('Удалить запись').'"><i class="fa fa-trash-o text-danger position-left"></i></a>
						</td>';
					if ($tbl_columns['a.id']['state'])
						$html .= '<td>'.$row['id'].'</td>';
					
					$html .= '</tr>';
				}
				
				$html .= '
					</tbody>
				</table>
				
				'.$pagination_html.'
				
			</div>';
		
			return $html;
		}
	}
	
	public function getGatewayInvoicesTblTds(array $tbl_columns, array $row) {
		return $this->buildCommonTblTds($tbl_columns, $row);
	}
	
	public function getGatewayPaymentsTblTds(array $tbl_columns, array $row) {
		return $this->buildCommonTblTds($tbl_columns, $row);
	}
	
	public function getBalanceTransactionsTblTds(array $tbl_columns, array $row) {
		return $this->buildCommonTblTds($tbl_columns, $row);
	}
	
	public function buildCommonTblTds(array $tbl_columns, array $row) {
		$html = '';
		$instance = $this->webcash->getAddonInstanceByAlias($row['area_alias']);
		$title = __($instance->getConst('pay_types|'.$row['rel_item_type'].'|title'));
		
		if ($tbl_columns['a.area_alias']['state']) {
			$html .= '<td>'.$this->adminfilter->makeFiltrationLinkByKey('a.area_alias', __($instance->display_name)).'</td>';
		}
		if ($tbl_columns['a.rel_item_type']['state'])
			$html .= '<td>'.$this->adminfilter->makeFiltrationLinkByKey('a.rel_item_type', $title).'</td>';
		if ($tbl_columns['a.rel_item_id']['state']) {
			if ($row['rel_item_id'] and $a = $instance->getConst('pay_types|'.$row['rel_item_type'].'|tab')) {
				$html .= '<td><a href="'.$instance->getAddonSettingsUrl('&tab2='.$a.'&filter=field&val[a.id]='.$row['rel_item_id']).'" title="'.__('Перейти к соответствующей записи').'">'.$title.' ID'.$row['rel_item_id'].'</a></td>';
			} elseif ($row['rel_item_id'] and method_exists($this->getBaseInstance(), 'makeRelItemLink')) {//список транзакций в плагине
				$html .= '<td>'.$this->getBaseInstance()->makeRelItemLink($row).'</td>';
			} elseif ($row['rel_item_id'] and method_exists($instance, 'makeRelItemLink')) {//общий список транзакций
				$html .= '<td>'.$instance->makeRelItemLink($row).'</td>';
			} else {
				$html .= '<td>--//--</td>';
			}
		}
		if ($tbl_columns['a.created']['state'])
			$html .= '<td class="text-center">'.$this->adminfilter->makeFiltrationLinkByKey('a.created').'</td>';
		
		return $html;
	}
	
	public function insertAdditional($sql, $tbl_columns, $context) {
		$arr = compact('tbl_columns', 'context');
		$sql = preg_replace_callback('#\[ADDL\.([^\]]+)\]#', function($matches) use ($arr) {
			$result = '';
			extract($arr);
			
			if (!empty($tbl_columns['a.rel_item_id']['state']) and $result = $this->getConst("list_additional|{$context}|{$matches[1]}")) {
				$replace_pairs = array('{PREFIX}' => PREFIX);
				$result = str_replace(array_keys($replace_pairs), array_values($replace_pairs), $result);
			}
			
			return $result;
		}, $sql);
		
		return $sql;
	}

}