<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

class Plugins_ListTransactions extends AddonSettings
{
	const INVOICES_TAB = 1;
	const PAYMENTS_TAB = 2;
	const BALANCE_TRANSACTIONS_TAB = 3;
	
	const USER_ORDER_BY = 'ORDER BY a.id DESC';
	
	protected $alias = 'listtransactions';
	
	public function webcashCall() {
		$this->mainIndexTopmenu();
	}
	
	public function renderIndex() {
		if ($str = $this->verifyPluginEnable())
			return $str;
		
		$tpl = $this->webcash->getTplInstance();
		$tpl->assign('payments_log_url', $this->getPluginFrontendUrl('&log=payments'));
		$tpl->assign('balance_transactions_log_url', $this->getPluginFrontendUrl('&log=balance_transactions'));
		$tpl->assign('payments_log_html', $this->getLog(GET('log')));
		$tpl->assign('plg_alias', $this->alias);
		$tpl->assign('plugin_cfg', $this->getCfgPublicParams());
		$tpl->assign('addon_settings_link', $this->renderAddonSettingsLink());
		$tpl->assign('user_hash', $this->user->nonce);
		$tpl->load_template('/modules/webcash/plugins/listtransactions/index.tpl');
		
		$tpl->compile('content');
		
		return $tpl->result['content'];
	}
	
	public function getLog($log_type) {
		if ($log_type == 'payments') {
			return $this->renderUserGatewayPaymentsLog('/modules/webcash/plugins/listtransactions/user_gateway_payments.tpl');
		}
		
		if ($log_type == 'balance_transactions') {
			return $this->renderUserBalanceTransactionsLog('/modules/webcash/plugins/listtransactions/user_balance_transactions.tpl');
		}
	}
	
	public function renderUserGatewayPaymentsLog($template_path, $plg_alias = '') {
		if ($this->user->isLoggedIn()) {	
			$alias_sql = $plg_alias ? "AND a.area_alias = '{$plg_alias}'" : "";
			
			if ($rows = $this->db->select("
				SELECT a.*
				FROM {$this->webcash->gateway_payments_table} AS a
				WHERE a.user_id = '{$this->user->id}'
				{$alias_sql}".
				self::USER_ORDER_BY
			)) {
				foreach ($rows as &$row) {
					$row = $this->handleCommonColumns($row);
					
					$row['gateway_name'] = safe_array_access($this->webcash->getGateways(), $row['gateway'], 'name');
					$row['created'] = $this->formatDate($row['created']);
				}
				unset($row);
				
				$tpl = $this->webcash->getTplInstance();
				$tpl->assign('items', $rows);
				$tpl->assign('plg_alias', $plg_alias);
				$tpl->assign('plugin_cfg', $this->getCfgPublicParams($plg_alias));
				$tpl->load_template($template_path);
				
				$tpl->compile('content');
				
				return $tpl->result['content'];
			} else {
				return $this->webcash->getMsgContent('Нет данных', 'Информация');
			}
		}
	}
	
	public function renderUserBalanceTransactionsLog($template_path, $plg_alias = '') {
		if ($this->user->isLoggedIn()) {
			$alias_sql = $plg_alias ? "AND a.area_alias = '{$plg_alias}'" : "";
			
			if ($rows = $this->db->select("
				SELECT a.*
				FROM {$this->webcash->balance_transactions_table} AS a
				WHERE a.user_id = '{$this->user->id}'
				{$alias_sql}".
				self::USER_ORDER_BY
			)) {
				foreach ($rows as &$row) {
					$row = $this->handleCommonColumns($row);
					
					$row['gateway_name'] = safe_array_access($this->webcash->getGateways(), $row['gateway'], 'name');
					$row['created'] = $this->formatDate($row['created']);
				}
				unset($row);
				
				$tpl = $this->webcash->getTplInstance();
				$tpl->assign('items', $rows);
				$tpl->assign('plg_alias', $plg_alias);
				$tpl->assign('plugin_cfg', $this->getCfgPublicParams($plg_alias));
				$tpl->load_template($template_path);
				
				$tpl->compile('content');
				
				return $tpl->result['content'];
			} else {
				return $this->webcash->getMsgContent('Нет данных', 'Информация');
			}
		}
	}
	
	public function renderUserBothPaySourcePaymentsLog($template_path, $plg_alias, $rel_item_type = 0) {
		if ($this->user->isLoggedIn()) {
			$plg_alias = only_alias($plg_alias);
			$rel_item_type_sql = $rel_item_type ? "AND a.rel_item_type = '{$rel_item_type}'" : ""; 
			
			if ($rows = $this->db->select("
				SELECT a.*
				FROM
				(
					SELECT
						a.id, a.amount, a.user_id, a.created, a.state, a.area_alias, a.rel_item_type, a.rel_item_id,
						".WebCash::PAY_SOURCE_GATEWAY." AS pay_source,
						a.gateway AS pay_name
					FROM {$this->webcash->gateway_payments_table} AS a
					
					UNION
					
					SELECT
						a.id, a.amount, a.user_id, a.created, a.state, a.area_alias, a.rel_item_type, a.rel_item_id,
						".WebCash::PAY_SOURCE_BALANCE." AS pay_source,
						'balance' AS pay_name
					FROM {$this->webcash->balance_transactions_table} AS a
				) AS a
				WHERE a.user_id = '{$this->user->id}'
				AND a.area_alias = '{$plg_alias}'
				{$rel_item_type_sql}
				ORDER BY a.created DESC"
			)) {
				foreach ($rows as &$row) {
					$row = $this->handleCommonColumns($row);
					
					$row['pay_name'] = ($row['pay_name'] == 'balance') ? __('Оплата с баланса') : safe_array_access($this->webcash->getGateways(), $row['pay_name'], 'name');
					$row['created'] = $this->formatDate($row['created']);
				}
				unset($row);
				
				$tpl = $this->webcash->getTplInstance();
				$tpl->assign('items', $rows);
				$tpl->assign('plg_alias', $plg_alias);
				$tpl->assign('plugin_cfg', $this->getCfgPublicParams($plg_alias));
				$tpl->load_template($template_path);
				
				$tpl->compile('content');
				
				return $tpl->result['content'];
			} else {
				return $this->webcash->getMsgContent('Нет данных', 'Информация');
			}
		}
	}

	public function handleCommonColumns($row) {
		if ($row['area_alias']) {
			$instance = $this->webcash->getAddonInstanceByAlias($row['area_alias']);
			
			$row['plugin_display_name'] = __($instance->display_name);
			$row['rel_item_type_title'] = __($instance->getConst('pay_types|'.$row['rel_item_type'].'|title'));
			
			if ($row['rel_item_id'] and method_exists($instance, 'makeRelItemLink')) {
				$row['rel_item_id_html'] = $instance->makeRelItemLink($row);
			}
		}
		
		return $row;
	}

}