<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

$webcash->listtransactions->readSettingsFromFile();


if ($action == 'ajax.plugin.from_tab1') {
	if ($subaction == 'empty_gateway_invoices_table') {
		$webcash->adminpanel->emptyTable($webcash->gateway_invoices_table);
		$webcash->helper->showMsgOk('Таблица очищена. Перезагрузка...', 'Информация', 'self');
	} elseif ($subaction == 'delete' and $id = (int)POST('id')) {
		if ($webcash->adminpanel->deleteRecordById($id, $webcash->gateway_invoices_table)) {
			$webcash->helper->showMsgOk('Запись в таблице инвойсов удалена. Перезагрузка...', 'Информация', 'self');
		}
	} elseif ($subaction == 'save_columns') {
		$webcash->admin_listtransactions->saveTblColumnsList('invoices_tbl_columns_list', POST('tbl_columns_list'));
	}
	
} elseif ($action == 'ajax.plugin.from_tab2') {
	if ($subaction == 'empty_gateway_payments_table') {
		$webcash->adminpanel->emptyTable($webcash->gateway_payments_table);
		$webcash->helper->showMsgOk('Таблица очищена. Перезагрузка...', 'Информация', 'self');
	} elseif ($subaction == 'delete' and $id = (int)POST('id')) {
		if ($webcash->adminpanel->deleteRecordById($id, $webcash->gateway_payments_table)) {
			$webcash->helper->showMsgOk('Запись в таблице платежей удалена. Перезагрузка...', 'Информация', 'self');
		}
	} elseif ($subaction == 'save_columns') {
		$webcash->admin_listtransactions->saveTblColumnsList('payments_tbl_columns_list', POST('tbl_columns_list'));
	}
	
} elseif ($action == 'ajax.plugin.from_tab3') {
	if ($subaction == 'empty_balance_transactions_table') {
		$webcash->adminpanel->emptyTable($webcash->balance_transactions_table);
		$webcash->helper->showMsgOk('Таблица очищена. Перезагрузка...', 'Информация', 'self');
	} elseif ($subaction == 'delete' and $id = (int)POST('id')) {
		if ($webcash->adminpanel->deleteRecordById($id, $webcash->balance_transactions_table)) {
			$webcash->helper->showMsgOk('Запись в таблице транзакций на балансах удалена. Перезагрузка...', 'Информация', 'self');
		}
	} elseif ($subaction == 'save_columns') {
		$webcash->admin_listtransactions->saveTblColumnsList('balance_transactions_tbl_columns_list', POST('tbl_columns_list'));
	}
}

$webcash->helper->showMsgError('Ошибка при выполнении запроса');