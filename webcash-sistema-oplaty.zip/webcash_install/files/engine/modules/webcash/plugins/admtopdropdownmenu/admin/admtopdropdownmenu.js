/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

//submenu
submenu = {
	init: function() {
		$(".dropdown-menu li").each(function() {
			var $this = $(this);
			if ($this.children("ul").length) {
				$this.addClass("sub-dropdown");
				$this.children("ul").addClass("sub-menu");
			}
		});
		
		$(".sub-dropdown").on("mouseenter",function() {
			$(this).addClass("active").children("ul").addClass("sub-open");
		}).on("mouseleave", function() {
			$(this).removeClass("active").children("ul").removeClass("sub-open");
		})
		
	}
};

submenu.init();//top submenu