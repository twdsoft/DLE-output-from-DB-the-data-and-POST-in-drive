<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

class Plugins_Admin_AdmTopDropdownMenu extends Admin_AbstractListEntries
{
	protected $base_alias = 'admtopdropdownmenu';
	protected $table_a = 'webcash_admtopdropdownmenu_base';
	protected $table_b = 'webcash_admtopdropdownmenu_favorites';
	protected $table_c = 'webcash_admtopdropdownmenu_recent';
	protected $active_id = 0;
	protected $admtopdropdownmenu = array();
	protected $admtopdropdownmenu_favorites = array();
	protected $admtopdropdownmenu_recent = array();
	
	public function refreshMenu() {
		$base_instance = $this->getBaseInstance();
		
		$this->adminpanel->emptyTable($this->table_a);
		
		$data = array(
			'id' => 10,
			'caption' => __('Платежные шлюзы'),
			'hint' => __('Список платежных шлюзов'),
			'url' => $this->dle->config['admin_path'].'?mod=webcash&tab='.Admin_Panel::GATEWAYS_TAB,
			'parent_id' => 0,
			'content' => '',
			'ordering' => 0,
			'attribs' => '',
		);
		$parent_id = $this->addItem(array('data' => $data), '', false, false);
		
		$i = 20;
		foreach ($this->webcash->getGateways(true) as $row) {
			$instance = $this->{$row['alias']};
		
			$data = array(
				'id' => ++$i,
				'caption' => $this->helper->htmlspecialchars(__($instance->display_name)),
				'hint' => $this->helper->htmlspecialchars(__($instance->description)),
				'url' => str_replace($this->webcash->site_url, '', $instance->getAddonSettingsUrl()),
				'parent_id' => $parent_id,
				'content' => '',
				'ordering' => 0,
				'attribs' => '',
			);
			$this->addItem(array('data' => $data));
		}
		
		$data = array(
			'id' => 100,
			'caption' => __('Плагины'),
			'hint' => __('Список плагинов'),
			'url' => $this->dle->config['admin_path'].'?mod=webcash&tab='.Admin_Panel::PLUGINS_TAB,
			'parent_id' => 0,
			'content' => '',
			'ordering' => 0,
			'attribs' => '',
		);
		$parent_id = $this->addItem(array('data' => $data));
		
		$i = 110;
		foreach ($this->webcash->getPlugins(true) as $row) {
			$instance = ($row['alias'] == $this->base_alias) ? $base_instance : $this->{$row['alias']};
			
			$data = array(
				'id' => ++$i,
				'caption' => $this->helper->htmlspecialchars(__($instance->display_name)),
				'hint' => $this->helper->htmlspecialchars(__($instance->description)),
				'url' => str_replace($this->webcash->site_url, '', $instance->getAddonSettingsUrl()),
				'parent_id' => $parent_id,
				'content' => '',
				'ordering' => 0,
				'attribs' => '',
			);
			$this->addItem(array('data' => $data));
		}
		
		return true;
	}
	
	public function buildMenu() {
		$base_instance = $this->getBaseInstance();
		
		if ($base_instance->on) {
			$base_instance->readSettingsFromFile(true);
			
			$this->prepareMenu();
			
			$this->js_css->addCSSFile($base_instance->getDirUrl().'admin/admtopdropdownmenu.css', true);
			
			$this->js_css->addJsFile($base_instance->getDirUrl().'admin/admtopdropdownmenu.js', true);
			
			
			require $base_instance->getPath().'admtopdropdownmenu_html.php';
		}
	}
	
	
	public function prepareMenu() {
		$base_instance = $this->getBaseInstance();
		
		$all_rows = $rows = $this->db->select("
			SELECT *
			FROM {$this->table_a} AS a
			WHERE state = 1
			AND parent_id = 0
			ORDER BY ordering"
		);
		
		$this->active_id = 0;
		$this->typeahead_source = '';
		$this->admtopdropdownmenu_favorites = array();
		
		$admin_sett = $this->adminsettings->getAllSettings();
		$recent_ids = ($str = safe_array_access($admin_sett, 'c_admtopdropdownmenu_recent')) ? explode(',' ,$str) : array();
		
		foreach ($rows as &$row) {
		
			$row = $this->handleItem($row);
			
			$sub_rows = $this->db->select("
				SELECT *
				FROM {$this->table_a}
				WHERE state = 1
				AND parent_id = '{$row['id']}'
				ORDER BY ordering"
			);
			
			foreach ($sub_rows as &$sub_row) {
			
				$sub_row = $this->handleItem($sub_row);
				
				$all_rows[] = $sub_row;
				
				$str = $this->base_instance->searchresult_show_parent ? '|'.$row['caption'] : '';//добавляем название родительского пункта
				$this->typeahead_source .= ($this->typeahead_source ? ',' : ''). '"'.$sub_row['url'].'|'.addslashes($sub_row['caption']).$str.'"';
			}
			unset($sub_row);
			
			$row['childs'] = $sub_rows;
		}
		unset($row);
		
		
		$this->admtopdropdownmenu_recent = array();
		foreach ($recent_ids as $id) {
			foreach ($all_rows as $row) {
				if ($id == $row['id']) {
					$this->admtopdropdownmenu_recent[] = $row;
				}
			}
		}
		
		if ($this->active_id) {
			if (($key = array_search($this->active_id, $recent_ids)) !== false) {
				unset($recent_ids[$key]);
			}
			
			array_unshift($recent_ids, $this->active_id);
			
			if (count($recent_ids) > $base_instance->menu_recent_limit) {
				array_pop($recent_ids);
			}
		}
		
		if ($recent_ids) {
			$this->adminsettings->saveParam('c_admtopdropdownmenu_recent', implode(',', $recent_ids));
		}
		
		
		$this->admtopdropdownmenu = $rows;
	}
	
	public function handleItem($row) {
		if (strpos($row['url'], $this->dle->config['admin_path']) === 0)
			$row['url'] = $this->webcash->site_url.$row['url'];
		
		if ($this->helper->getCurrentUrl() == $row['url']) {
			$this->active_id = $row['id'];//запоминаем номер пункта меню, где был переход
		}
		
		if ($row['is_favorite']) {
			$this->admtopdropdownmenu_favorites[] = $row;//заполняем массив для подменю "Избранное"
		}
		
		return $row;
	}
	
	public function getDefaultMenuItemsTblColumns() {
		$tbl_columns = array();
		
		$tbl_columns['nosort1']['column'] = __('№');
		
		$tbl_columns['a.caption']['column'] = __('Название');
		$tbl_columns['a.caption']['title_part'] = __('по названию пункта');
		$tbl_columns['a.caption']['sort_alpha'] = true;
		
		$tbl_columns['a.hint']['column'] = __('Подсказка');
		$tbl_columns['a.hint']['title_part'] = __('по подсказке пункта');
		$tbl_columns['a.hint']['sort_alpha'] = true;

		$tbl_columns['a.url']['column'] = __('Ссылка');
		$tbl_columns['a.url']['title_part'] = __('по ссылке пункта');
		$tbl_columns['a.url']['sort_alpha'] = true;
		
		$tbl_columns['a.parent_id']['column'] = __('Родитель');
		$tbl_columns['a.parent_id']['title_part'] = __('по пункту-родителю');
		$tbl_columns['a.parent_id']['sort_alpha'] = true;
		
		$tbl_columns['a.ordering']['column'] = __('Сортировка');
		$tbl_columns['a.ordering']['title_part'] = __('по номеру для сортировки пункта');
		
		$tbl_columns['a.attribs']['column'] = __('Аттрибуты');
		$tbl_columns['a.attribs']['title_part'] = __('по полю аттрибутов пункта');
		
		$tbl_columns['a.created']['column'] = __('Дата');
		$tbl_columns['a.created']['title_part'] = __('по дате создания пункта');
		
		$tbl_columns['a.state']['column'] = __('Статус');
		$tbl_columns['a.state']['title_part'] = __('по статусу пункта');
		$tbl_columns['a.state']['sort_alpha'] = true;
		
		$tbl_columns['nosort2']['column'] = __('Действие');

		$tbl_columns['a.id']['column'] = 'ID';
		$tbl_columns['a.id']['title_part'] = __('по идентификационному номеру');
		
		
		$tbl_columns = $this->endHandleTblColumns($tbl_columns, 'default_menu_items_tbl_columns_list');
		
		return $tbl_columns;
	}
	
	public function listDefaultMenuItems() {
		$sql_addon = $this->adminfilter->makeFiltrationSQL();
		
		$base_instance = $this->getBaseInstance();
		
		if (!$total_count = $this->db->selectCell("SELECT COUNT(*) FROM {$this->table_a} AS a {$sql_addon}"))
			return __('Нет записей');
		
		$tbl_columns = $this->getDefaultMenuItemsTblColumns();
		$sql_order_by = $this->commonInitList($total_count, $tbl_columns);
		
        if ($rows = $this->db->select("
			SELECT a.*
			FROM {$this->table_a} AS a
			{$sql_addon}
			{$sql_order_by}
			{$this->pager->limit}"
		)) {
			
			$this->pager->set('items_count', count($rows));
			$pagination_html = $this->pager->renderPaginationHtml();
			$pagination_info = $this->pager->getServiceInfo();
			
			$html = '
			<div class="table-responsive">

				<table class="table table-xs table-hover">
					
					'.$this->renderItemsTableThead($tbl_columns).'
					
					<tbody>';
				
				foreach ($rows as $index => $row) {
				
					$this->adminfilter->set('filter_data|row', $row);
				
					$edit_start_tag = '<a href="'.$base_instance->getAddonSettingsUrl('&tab2=2&id='.$row['id']).'" title="'.__('Редактировать пункт меню').'">';
					
					$html .= '<tr>';
					
					if ($tbl_columns['nosort1']['state'])
						$html .= '<td>'.($index + $pagination_info['index']).'</td>';
					if ($tbl_columns['a.caption']['state'])
						$html .= '<td>'.$edit_start_tag.$row['caption'].'</a></td>';
					if ($tbl_columns['a.hint']['state'])
						$html .= '<td>'.$row['hint'].'</td>';
					if ($tbl_columns['a.url']['state'])
						$html .= '<td>'.$row['url'].'</td>';
					if ($tbl_columns['a.parent_id']['state']) {
						$str = $row['parent_id'] ? $this->getItemById($row['parent_id'])['caption'] : '--//--';
						$html .= '<td>'.$this->adminfilter->makeFiltrationLinkByKey('a.parent_id', $str).'</td>';
					}
					if ($tbl_columns['a.ordering']['state'])
						$html .= '<td>'.$row['ordering'].'</td>';
					if ($tbl_columns['a.attribs']['state'])
						$html .= '<td>'.($row['attribs'] ? $row['attribs'] : '--//--').'</td>';
					if ($tbl_columns['a.created']['state'])
						$html .= '<td class="text-center">'.$this->adminfilter->makeFiltrationLinkByKey('a.created').'</td>';
					if ($tbl_columns['a.state']['state'])
						$html .= '<td class="text-center">'.$this->adminfilter->makeFiltrationLinkByKey('a.state', '<i title="'.($row['state'] ? __('Включен') : __('Отключен')).'" class="fa fa-exclamation-circle tip '.($row['state'] ? 'text-success' : 'text-danger').'"></i>').'</td>';
					if ($tbl_columns['nosort2']['state'])
						$html .= '
						<td class="text-center three-cols-actn">
							<a href="#" data-do="ajax-webcash" data-vars="action=ajax.plugin.from_tab2|subaction=delete|id='.$row['id'].'|plg_alias='.$base_instance->alias.'"'.($base_instance->item_delete_button_confirm ? ' data-confirm="1"' : '').' title="'.__('Удалить запись').'"><i class="fa fa-trash-o text-danger position-left"></i></a>
							
							<a href="#" data-do="ajax-webcash" data-vars="action=ajax.plugin.from_tab2|id='.$row['id'].'|subaction='.($row['is_favorite'] ? 'remove_from_favorites' : 'add_to_favorites').'|plg_alias='.$base_instance->alias.'" title="'.($row['is_favorite'] ? __('Удалить из подменю &laquo;Избранное&raquo;') : __('Добавить в подменю &laquo;Избранное&raquo;')).'"><i class="fa '.($row['is_favorite'] ? 'fa-star' : 'fa-star-o').' position-left"></i></a>
							
							'.$edit_start_tag.'<i class="fa fa-pencil"></i></a>
							
						</td>';
					if ($tbl_columns['a.id']['state'])
						$html .= '<td class="text-center">'.$row['id'].'</td>';
					
					$html .= '</tr>';
				}
				
				$html .= '
					</tbody>
				</table>
				
				'.$pagination_html.'
				
			</div>';
		
			return $html;
		}
	}

}