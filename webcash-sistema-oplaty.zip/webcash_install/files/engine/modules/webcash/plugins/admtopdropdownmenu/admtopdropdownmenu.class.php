<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

class Plugins_AdmTopDropdownMenu extends AddonSettings
{
	protected $alias = 'admtopdropdownmenu';
	
	public function getPluginsListDropdownItems() {
		return '<li><a href="#" data-do="ajax-webcash" data-vars="action=ajax.plugin.refresh_menu|plg_alias='.$this->alias.'" data-confirm="1" title="'.__('Обновление меню').'"><i class="fa fa-refresh position-left text-danger"></i>'.__('Обновить').'</a></li>';
	}
	
}