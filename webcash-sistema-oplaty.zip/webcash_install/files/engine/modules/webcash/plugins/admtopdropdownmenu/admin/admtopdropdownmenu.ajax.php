<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

$webcash->admtopdropdownmenu->readSettingsFromFile();


if ($action == 'ajax.plugin.from_tab1') {
	if ($subaction == 'create_admtopdropdownmenu') {
		$source_array = POST();
		$webcash->helper->emptyRequiredFields($source_array);
		
		if ($webcash->admin_admtopdropdownmenu->addItem($source_array)) {
			if ($webcash->admtopdropdownmenu->adm_reload_after_create)
				$webcash->helper->showMsgOk('Пункт базового подменю добавлен. Перезагрузка...', 'Информация', 'self');
			else
				$webcash->helper->showMsgOk('Пункт базового додменю добавлен');
		}
	}
	
} elseif ($action == 'ajax.plugin.from_tab2') {
	if ($subaction == 'empty_default_menu_items_table') {
		$webcash->adminpanel->emptyTable($webcash->admin_admtopdropdownmenu->table_a);
		$webcash->helper->showMsgOk('Таблица очищена. Перезагрузка...', 'Информация', 'self');
	} elseif ($subaction == 'edit_admtopdropdownmenu' and $id = (int)POST('id')) {
		$source_array = POST();
		$webcash->helper->emptyRequiredFields($source_array);
		
		if ($webcash->admin_admtopdropdownmenu->updateItem($source_array)) {
			$webcash->helper->showMsgOk('Параметры пункта базового подменю обновлены');
		}
	} elseif ($subaction == 'delete' and $id = (int)POST('id')) {
		if ($webcash->adminpanel->deleteRecordById($id, $webcash->admin_admtopdropdownmenu->table_a)) {
			$webcash->helper->showMsgOk('Пункт базового подменю удален. Перезагрузка...', 'Информация', 'self');
		}
	} elseif (in_array($subaction, array('add_current_item_to_favorites', 'del_current_item_from_favorites')) and $id = (int)POST('id')) {
		$value = ($subaction == 'add_current_item_to_favorites') ? 1 : 0;
		
		if ($webcash->db->query("UPDATE {$webcash->admin_admtopdropdownmenu->table_a} SET is_favorite = '{$value}' WHERE id = '{$id}' LIMIT 1")) {
			if ($subaction == 'add_current_item_to_favorites')
				$webcash->helper->showMsgOk('Пункт добавлен в подменю &laquo;Избранное&raquo;. Перезагрузка...', 'Информация', 'self');
			else
				$webcash->helper->showMsgOk('Пункт удален из подменю &laquo;Избранное&raquo;. Перезагрузка...', 'Информация', 'self');
		}
	} elseif (in_array($subaction, array('add_to_favorites', 'remove_from_favorites')) and $id = (int)POST('id')) {
		if ($subaction == 'add_to_favorites') {
			$re_action = 'remove_from_favorites';
			$value = 1;
			$class = 'fa-star';
			$title = lang('Удалить из подменю Избранное');
			$msg = lang('Пункт добавлен в подменю &laquo;Избранное&raquo;');
		} else {
			$re_action = 'add_to_favorites';
			$value = 0;
			$class = 'fa-star-o';
			$title = lang('Добавить в подменю Избранное');
			$msg = lang('Пункт удален из подменю &laquo;Избранное&raquo;');
		}
		
		$html = '
		<script>
		$("a[data-vars^=\"action=ajax.plugin.from_tab2|id='.$id.'|\"]")
			.data("vars", "action=ajax.plugin.from_tab2|id='.$id.'|subaction='.$re_action.'|plg_alias='.$webcash->admtopdropdownmenu->alias.'")
			.html("<i class=\"fa '.$class.' position-left\"></i>")
			.attr("title", "'.$title.'");
			
		WEBCASH.info("'.$msg.'");
		</script>';
		
		if ($webcash->db->query("UPDATE {$webcash->admin_admtopdropdownmenu->table_a} SET is_favorite = '{$value}' WHERE id = '{$id}' LIMIT 1")) {
			$webcash->helper->sendAjaxContent('body', $html, Helper::APPEND_AJAX_CONTENT);
		}
	} elseif ($subaction == 'save_columns') {
		$webcash->admin_admtopdropdownmenu->saveTblColumnsList('default_menu_items_tbl_columns_list', POST('tbl_columns_list'));
	}
	
} elseif ($action == 'ajax.plugin.refresh_menu') {
	if ($webcash->admin_admtopdropdownmenu->refreshMenu())
		$webcash->helper->showMsgOk('Меню обновлено. Перезагрузка...', 'Информация', 'self');
	else
		$webcash->helper->showMsgError('Ошибка при обновлении меню');
}

$webcash->helper->showMsgError('Ошибка при выполнении запроса');