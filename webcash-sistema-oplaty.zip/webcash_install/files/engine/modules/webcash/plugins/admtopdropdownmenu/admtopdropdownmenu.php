<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

if (!$this->readSettingsFromFile()) {
	$this->setCfgValue('display_name', 'Верхнее выпадающее меню в админпанели');
	$this->setCfgValue('description', 'С помощью этого плагина добавляется верхнее выпадающее меню в админпанели.');
	$this->setCfgValue('menu_recent_limit', 10);
	$this->setCfgValue('recent_navigation_show_parent', 1);
	$this->setCfgValue('add_current_item_to_favorites', 1);
	$this->setCfgValue('searchresult_show_parent', 1);
	$this->setCfgValue('default_ipp', 50);
	$this->setCfgValue('item_delete_button_confirm', 1);
	$this->setCfgValue('adm_reload_after_create', 1);
	$this->setConvCfgValue('date_format', 'j F Y г. H:i');
	$this->setNoneFormControlCfgValue('default_menu_items_tbl_columns_list', 'nosort1,a.caption,a.hint,a.url,a.parent_id,nosort2,a.id');
	
	
	$this->addHint(__FILE__.'1', 'Меню состоит из нескольких подменю:
	<b>История переходов</b> - пункты &laquo;Базового подменю&raquo;, которые были использованы в последнее время;
	<b>Избранное</b> - в это подменю можно добавить любой пункт &laquo;Базового подменю&raquo; для быстрого доступа;
	<b>Базовое подменю</b> - основной список пунктов, которым можно управлять (добавление/редактирование/удаление);
	<b>Служебное подменю</b> - фиксированные пункты меню;');
	
	
	$this->setFieldsItem('menu_recent_limit', array(
		'title' => 'Число ссылок в &laquo;Истории переходов&raquo;',
		'hint' => 'Максимальное количество ссылок в пункте подменю &laquo;История переходов&raquo;',
		'type' => 'text',
	));
	
	$this->setFieldsItem('recent_navigation_show_parent', array(
		'title' => 'Названия родительских пунктов в &laquo;Истории переходов&raquo;',
		'hint' => 'Если включено, то в данном пункте подменю рядом с каждым подпунктом справа будет отображаться название его родительского пункта',
		'type' => 'checkbox',
	));
	
	$this->setFieldsItem('add_current_item_to_favorites', array(
		'title' => 'Добавление текущего пункта подменю в &laquo;Избранное&raquo;',
		'hint' => 'Если включено, то в пункте подменю &laquo;Избранное&raquo; внизу будет отображаться ссылка &laquo;Добавить текущий пункт&raquo;',
		'type' => 'checkbox',
	));
	
	$this->setFieldsItem('default_ipp', array(
		'title' => 'Число записей на страницу',
		'hint' => 'Количество записей для постраничной навигации в списке',
		'type' => 'text',
	));

	$this->setFieldsItem('adm_reload_after_create', array(
		'title' => 'Перезагружать после создания пункта',
		'hint' => 'Перезагружать или нет в админпанели страницу после создания нового пункта &laquo;Базового подменю&raquo;',
		'type' => 'checkbox',
	));
	
	$this->setFieldsItem('refresh_menu', array(
		'title' => 'Обновление меню',
		'hint' => 'При необходимости, можно обновить записи в таблице &laquo;Базового подменю&raquo;. Это может понадобиться например, после добавления новых дополнений. Все вручную добавленные вами изменения будут сброшены.',
		'label' => 'Обновить',
		'tag_part' => 'data-confirm="1"',
		'type' => 'ajax_button',
	));
	
	$this->setFieldsItem('date_format', array(
		'title' => 'Формат даты',
		'hint' => 'Используется, например, при выводе даты в списке, <a href="#" onclick="javascript:Help(\'date\'); return false;">помощь по работе функции</a>',
		'type' => 'text',
	));
	
	
	if (!$this->db->selectCell("SELECT 1 FROM {$this->admin_admtopdropdownmenu->table_a} LIMIT 1")) {
		$this->admin_admtopdropdownmenu->refreshMenu();
	}
	
	$this->convertDefaultValues();
	$this->writeSettingsInFile(true);
}