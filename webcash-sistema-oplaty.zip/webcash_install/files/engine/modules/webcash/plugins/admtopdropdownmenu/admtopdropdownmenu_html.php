<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');
?>

<ul class="nav navbar-top-links navbar-right">	

	<li class="dropdown">
	
		<a class="dropdown-toggle" data-toggle="dropdown" href="#" title="<?php echo __('История переходов'); ?>">
			<i class="fa fa-history fa-fw"></i>  <i class="fa fa-caret-down"></i>
		</a>
		<ul class="dropdown-menu">
		
		<?php if ($this->admtopdropdownmenu_recent) {
			foreach ($this->admtopdropdownmenu_recent as $row) {
				$str = '';
				if ($base_instance->recent_navigation_show_parent and $parent_row = $this->getItemById($row['parent_id']))
					$str = ' <sup><i>'.$parent_row['caption'].'</i></sup>';//справа отображаем название родительского пункта
			?>
			<li><a href="<?php echo $row['url']; ?>" title="<?php echo $row['hint']; ?>"><?php echo $row['caption'].$str; ?></a></li>
			<?php
			}
		} else { ?>
			<li><a href="#"><?php echo __('Нет переходов...'); ?></a></li>
		<?php } ?>
		
		</ul>
		<!-- /.dropdown-tasks -->
	</li>
	<!-- /.dropdown -->
	
	
	
	<li class="dropdown">
	
		<a class="dropdown-toggle" data-toggle="dropdown" href="#" title="<?php echo __('Избранное'); ?>">
			<i class="fa fa-star fa-fw"></i>  <i class="fa fa-caret-down"></i>
		</a>
		<ul class="dropdown-menu">
		
		<?php if ($this->admtopdropdownmenu_favorites) {
			foreach ($this->admtopdropdownmenu_favorites as $row) { 
			?>
			<li><a href="<?php echo $row['url']; ?>" title="<?php echo $row['hint']; ?>"><?php echo $row['caption']; ?></a></li>
			<?php
			}
		} else { ?>
			<li><a href="<?php echo $this->base_instance->getAddonSettingsUrl('&tab2=2'); ?>&subaction=favorite_add"><?php echo __('Нет ссылок... Хотите добавить?'); ?></a></li>
		<?php } ?>
		
		
		<?php if ($this->base_instance->add_current_item_to_favorites and $this->active_id) { ?>
			<li class="divider"></li>
			
			<?php if ($this->admtopdropdownmenu_favorites and $arr = array_column($this->admtopdropdownmenu_favorites, 'id') and in_array($this->active_id, $arr)) { ?>
			<li><a href="#" data-do="ajax-webcash" data-vars="action=ajax.plugin.from_tab2|subaction=del_current_item_from_favorites|id=<?php echo $this->active_id; ?>|plg_alias=<?php echo $this->base_instance->alias; ?>" title="<?php echo __('Удалить текущий пункт меню из &laquo;Избранного&raquo;'); ?>"><i class="fa fa-minus-circle fa-fw"></i> <?php echo __('Исключить текущий пункт'); ?></a></li>
			<?php } else { ?>
			<li><a href="#" data-do="ajax-webcash" data-vars="action=ajax.plugin.from_tab2|subaction=add_current_item_to_favorites|id=<?php echo $this->active_id; ?>|plg_alias=<?php echo $this->base_instance->alias; ?>" title="<?php echo __('Добавить текущий пункт меню в &laquo;Избранное&raquo;'); ?>"><i class="fa fa-plus-circle fa-fw"></i> <?php echo __('Добавить текущий пункт'); ?></a></li>
			<?php } ?>
		<?php } ?>

		</ul>
		<!-- /.dropdown-tasks -->
	</li>
	<!-- /.dropdown -->
	
	
	
	<li class="dropdown">
	
		<a class="dropdown-toggle" data-toggle="dropdown" href="#" title="<?php echo __('Базовое подменю'); ?>">
			<i class="fa fa-navicon fa-fw"></i>  <i class="fa fa-caret-down"></i>
		</a>
		<ul class="dropdown-menu">
		
		<?php foreach ($this->admtopdropdownmenu as $row) { ?>
			<li><a href="<?php echo $row['url']; ?>" title="<?php echo $row['hint']; ?>"><?php echo $row['caption']; ?></a>
			
			<?php if ($row['childs']) { ?>
				<ul class="dropdown-menu" style="max-height:500px; overflow-y:auto;">
				<?php foreach ($row['childs'] as $sub_row) { ?>
				
					<li <?php if ($this->helper->getCurrentUrl() == $sub_row['url']) { ?>class="active"<?php } ?>>
						<a href="<?php echo $sub_row['url']; ?>" title="<?php echo $sub_row['hint']; ?>"><?php echo $sub_row['caption']; ?></a>
					</li>
					
				<?php } ?>
				</ul>
			<?php } ?>
			</li>
		<?php } ?>
		
		</ul>
		<!-- /.dropdown-tasks -->
	</li>
	<!-- /.dropdown -->
	
	
	
	<li class="dropdown">
		<a class="dropdown-toggle" data-toggle="dropdown" href="#" title="<?php echo __('Служебное подменю'); ?>">
			<i class="fa fa-asterisk fa-fw"></i>  <i class="fa fa-caret-down"></i>
		</a>
		<ul class="dropdown-menu dropdown-user">
			<li><a href="<?php echo $this->webcash->site_url.'index.php?do=webcash'; ?>"><i class="fa fa-globe fa-fw"></i> <?php echo __('Страница модуля на сайте'); ?></a></li>
			<li class="divider"></li>
			<li><a href="http://new-dev.ru" title="<?php echo __('Посетить оффициальный сайт модуля New-Dev.RU'); ?>" target="_blank"><i class="fa fa-external-link fa-fw"></i> <?php echo __('Сайт модуля New-Dev.RU'); ?></a></li>
		</ul>
		<!-- /.dropdown-user -->
	</li>
	<!-- /.dropdown -->	
	
</ul>
<!-- /.navbar-top-links -->