<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');
?>

<form action="" class="webcash_ajax_form form-horizontal" method="post" autocomplete="off">
	<div class="panel panel-flat">
		<div class="panel-body">
			
			<?php echo $this->adminpanel->hint(__FILE__.'1', 'Все поля отмеченные звездочкой - обязательны к заполнению. Можно указать URL скрипта или абсолютный путь к нему. Также как команду можно указать вызов метода класса.'); ?>
			
		</div>
		
		<div class="table-responsive">
			<table class="table table-striped">
				<?php
				$admtopdropdownmenu_item = array(
					'state' => 1,
				);
				
				
				require_once $this->getPath().'admin/uni_admtopdropdownmenu.php';
				
				?>
			</table>
			
			<div class="buttons_wrap">
				<input type="hidden" name="action" value="ajax.plugin.from_tab1" />
				<input type="hidden" name="subaction" value="create_admtopdropdownmenu" />
				<input type="hidden" name="user_hash" value="<?php echo $this->user->nonce; ?>" />
				<input type="hidden" name="plg_alias" value="<?php echo $this->alias; ?>" />
				<button type="submit" class="btn bg-teal btn-raised position-left btn-green">
					<i class="fa fa-floppy-o position-left"></i><?php echo __('Готово'); ?>
				</button>
			</div>
		</div>
	</div>
</form>