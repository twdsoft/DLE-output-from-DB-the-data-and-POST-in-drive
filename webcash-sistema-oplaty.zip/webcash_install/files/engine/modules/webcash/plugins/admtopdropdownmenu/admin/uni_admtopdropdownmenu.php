<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

$this->adminpanel->showRow(
	__('Название'),
	__('Название пункта меню'),
	$this->adminpanel->makeInputText(
		'data[caption]',
		safe_array_access($admtopdropdownmenu_item, 'caption')
	),
	'',
	array(),
	true
);

$this->adminpanel->showRow(
	__('Подсказка'),
	__('Подсказка пункта меню, отображается при наведении указателя мыши'),
	$this->adminpanel->makeInputText(
		'data[hint]',
		safe_array_access($admtopdropdownmenu_item, 'hint')
	)
);

$this->adminpanel->showRow(
	__('Ссылка'),
	__('Ссылка пункта меню'),
	$this->adminpanel->makeInputText(
		'data[url]',
		safe_array_access($admtopdropdownmenu_item, 'url')
	),
	'',
	array(),
	true
);

$this->adminpanel->showRow(
	__('ID родителя'),
	__('ID номер родительского пункта меню'),
	$this->adminpanel->makeInputText(
		'data[parent_id]',
		safe_array_access($admtopdropdownmenu_item, 'parent_id')
	)
);

$this->adminpanel->showRow(
	__('Сортировка'),
	__('Номер, используемый для сортировки пунктов'),
	$this->adminpanel->makeInputText(
		'data[ordering]',
		safe_array_access($admtopdropdownmenu_item, 'ordering')
	)
);

$this->adminpanel->showRow(
	__('Аттрибуты'),
	__('Служебные аттрибуты пункты меню'),
	$this->adminpanel->makeTextarea(
		'data[attribs]',
		safe_array_access($admtopdropdownmenu_item, 'attribs')
	)
);

$this->adminpanel->showRow(
	__('В меню &laquo;Избранное&raquo;'),
	__('Добавить/Удалить пункт меню в &laquo;Избранное&raquo;'),
	$this->adminpanel->makeCheckbox(
		'data[is_favorite]',
		safe_array_access($admtopdropdownmenu_item, 'is_favorite')
	)
);

$this->adminpanel->showRow(
	__('Статус'),
	__('Включить/выключить задачу'),
	$this->adminpanel->makeCheckbox(
		'data[state]',
		safe_array_access($admtopdropdownmenu_item, 'state')
	)
);