<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

class Plugins_Admin_SheduledTasks extends Admin_AbstractListEntries
{
	protected $base_alias = 'sheduledtasks';
	
	public function convertTasksToArray() {
		$cache_path = $this->helper->mkdir($this->webcash->cache_path.'sheduledtasks/');
		$this->helper->rmdir($cache_path, false);
		
		if ($rows = $this->getBaseInstance()->arrayKeyId()) {
			$tasks = array();
			
			foreach ($rows as $row) {
				$script = $cache_path.'script'.$row['id'].'.php';
				$tasks[$script] = array(
					'interval' => $row['interval'],
					'time' => time() + $row['interval'] * 60,
				);
				
				$command = $row['command'];
				
				if (strpos($command, '.php') !== false) {
					if (strpos($command, 'http://') === 0 or strpos($command, 'https://') === 0 or strpos($command, '//') === 0) {
						$content = '$this->http->loadUrl("'.$command.'")';
					} else {
						$content = 'require "'.$command.'"';
					}
				} else {
					$content = $command;
				}
				
				$content = '<?php '.$content.'; ?>';
				file_put_contents($script, $content);
			}
			
			$this->getBaseInstance()->writeArray($cache_path, $tasks);
		}
	}
	
	public function listTasks() {
		$sql_addon = $this->adminfilter->makeFiltrationSQL();
		
		$base_instance = $this->getBaseInstance();
		
		if (!$total_count = $this->db->selectCell("SELECT COUNT(*) FROM {$base_instance->table_a} AS a {$sql_addon}"))
			return __('Нет записей');
		
        if ($rows = $this->db->select("
			SELECT a.*
			FROM {$base_instance->table_a} AS a
			{$sql_addon}
			ORDER BY id DESC
			{$this->pager->limit}"
		)) {
			
			$this->pager->set('items_count', count($rows));
			$pagination_html = $this->pager->renderPaginationHtml();
			$pagination_info = $this->pager->getServiceInfo();

			$tbl_columns = array();
			$tbl_columns['nosort1']['column'] = __('№');
			$tbl_columns['command']['column'] = __('Путь к скрипту или команда');
			$tbl_columns['interval']['column'] = __('Интервал');
			$tbl_columns['description']['column'] = __('Описание');
			$tbl_columns['created']['column'] = __('Дата');
			$tbl_columns['state']['column'] = __('Статус');
			$tbl_columns['nosort2']['column'] = __('Действие');
			$tbl_columns['nosort3']['column'] = __('ID');
			
			foreach ($tbl_columns as $k => &$v) {
				$v['state'] = 1;
			}
			unset($v);
			
			$html = '
			<div class="table-responsive">

				<table class="table table-xs table-hover">
					
					'.$this->renderItemsTableThead($tbl_columns).'
					
					<tbody>';
				
				foreach ($rows as $index => $row) {
				
					$edit_start_tag = '<a href="'.$base_instance->getAddonSettingsUrl('&tab2=2&id='.$row['id']).'" title="'.__('Редактировать задачу').'">';
					
					$html .= '<tr>';
					
					$html .= '<td>'.($index + $pagination_info['index']).'</td>';
					$html .= '<td>'.$edit_start_tag.$row['command'].'</a></td>';
					$html .= '<td>'.$row['interval'].'</td>';
					$html .= '<td>'.($row['description'] ? $row['description'] : '--//--').'</td>';
					$html .= '<td class="text-center">'.$row['created'].'</td>';
					$html .= '<td class="text-center"><i title="'.($row['state'] ? __('Опубликован') : __('Снят с публикации')).'" class="fa fa-exclamation-circle tip '.($row['state'] ? 'text-success' : 'text-danger').'"></i></td>';
					$html .= '
					<td class="text-center">
						<a href="#" data-do="ajax-webcash" data-vars="action=ajax.plugin.from_tab2|subaction=delete|id='.$row['id'].'|plg_alias='.$base_instance->alias.'"'.($base_instance->item_delete_button_confirm ? ' data-confirm="1"' : '').' title="'.__('Удалить запись').'"><i class="fa fa-trash-o text-danger position-left"></i></a>'.$edit_start_tag.'<i class="fa fa-pencil"></i></a>
					</td>';
					$html .= '<td class="text-center">'.$row['id'].'</td>';
					
					$html .= '</tr>';
				}
				
				$html .= '
					</tbody>
				</table>
				
				'.$pagination_html.'
				
			</div>';
		
			return $html;
		}
	}

	
}