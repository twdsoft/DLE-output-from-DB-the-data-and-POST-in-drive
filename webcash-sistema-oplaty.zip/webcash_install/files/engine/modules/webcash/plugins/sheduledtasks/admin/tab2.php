<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

if ($id = (int)GET('id') and $sheduledtasks_item = $this->webcash->getRowById($this->table_a, $id)) {
?>
<form action="" class="webcash_ajax_form form-horizontal" method="post" autocomplete="off">
	<div class="panel panel-flat">
		<div class="panel-body">
			
			<?php echo $this->adminpanel->hint(__FILE__.'1', 'Все поля отмеченные звездочкой - обязательны к заполнению.'); ?>
			
		</div>
		
		<div class="table-responsive">
			<table class="table table-striped">
			
				<?php require_once $this->getPath().'admin/uni_sheduledtask.php'; ?>
			
			</table>
			
			<div class="buttons_wrap">
				<input type="hidden" name="action" value="ajax.plugin.from_tab2" />
				<input type="hidden" name="subaction" value="edit_sheduledtask" />
				<input type="hidden" name="id" value="<?php echo $id; ?>" />
				<input type="hidden" name="user_hash" value="<?php echo $this->user->nonce; ?>" />
				<input type="hidden" name="plg_alias" value="<?php echo $this->alias; ?>" />
				<button type="submit" class="btn bg-teal btn-raised position-left btn-green">
					<i class="fa fa-floppy-o position-left"></i><?php echo __('Готово'); ?>
				</button>
			</div>
		</div>
	</div>
</form>
<?php
}
?>

<form action="" class="webcash_ajax_form form-horizontal" method="post" autocomplete="off">
	<div class="panel panel-flat">
		<div class="panel-body">
			
            <div class="dataTables_wrapper">
				<?php echo $this->admin_sheduledtasks->listTasks(); ?>
			</div>
			
		
		</div>
	</div>
	<div class="buttons_wrap">
		<input type="hidden" name="action" value="ajax.plugin.from_tab2" />
		<input type="hidden" name="subaction" value="" />
		<input type="hidden" name="user_hash" value="<?php echo $this->user->nonce; ?>" />
		<input type="hidden" name="plg_alias" value="<?php echo $this->alias; ?>" />
		
		<a href="#" data-do="ajax-webcash" data-vars="action=ajax.plugin.from_tab2|subaction=empty_tasks_table|plg_alias=<?php echo $this->alias; ?>" data-confirm="1" title="<?php echo __('Очистить таблицу задач. Внимание, данная операция необратима!'); ?>" class="btn bg-danger btn-raised position-left btn-red">
			<i class="fa fa-trash-o position-left"></i><?php echo __('Очистить таблицу'); ?>
		</a>
		
		<a href="<?php echo $this->getAddonSettingsUrl('&tab2=1'); ?>" class="btn bg-success btn-raised position-left btn-red">
			<i class="fa fa-plus-circle position-left"></i><?php echo __('Добавить новую задачу'); ?>
		</a>
	</div>
</form>