<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

$this->adminpanel->showRow(
	__('Путь к скрипту или команда'),
	__('Укажите путь к скрипту (команду), который необходимо запускать с определенным интервалом времени'),
	$this->adminpanel->makeInputText(
		'data[command]',
		safe_array_access($sheduledtasks_item, 'command')
	),
	'',
	array(),
	true
);

$this->adminpanel->showRow(
	__('Интервал времени'),
	__('Укажите интервал времени в минутах'),
	$this->adminpanel->makeInputText(
		'data[interval]',
		safe_array_access($sheduledtasks_item, 'interval')
	),
	'',
	array(),
	true
);

$this->adminpanel->showRow(
	__('Описание к задаче'),
	__('Используется только для удобства использования'),
	$this->adminpanel->makeTextarea(
		'data[description]',
		safe_array_access($sheduledtasks_item, 'description')
	)
);

$this->adminpanel->showRow(
	__('Статус'),
	__('Включить/выключить задачу'),
	$this->adminpanel->makeCheckbox(
		'data[state]',
		safe_array_access($sheduledtasks_item, 'state')
	)
);