<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

class Plugins_SheduledTasks extends AddonSettings
{
	const INVOICES_TAB = 1;
	const PAYMENTS_TAB = 2;
	
	protected $alias = 'sheduledtasks';
	protected $table_a = 'webcash_sheduledtasks';
	protected $constants = array(
		'methods_aliases' => array(
			'cronpixel' => 'cronPixel',
		),
	);
	
	public function handleMainContent($content) {
		$content = str_replace(
			'</body>',
			'<img src="'.$this->webcash->site_url.'index.php?do=webcash&action=plugin&alias=sheduledtasks&subaction=cronpixel" alt=""></body>',
			$content
		);
		
		return $content;
	}
	
	public function cronPixel() {
		$cache_path = $this->webcash->cache_path.'sheduledtasks/';
		$tasksfile = $cache_path.'tasks.php';
		
		if (file_exists($tasksfile)) {
			$tasks = require $tasksfile;
			foreach ($tasks as $script => $row) {
				if ($row['time'] < time()) {
					$lock = $cache_path.md5($script).'.lock';
					if (file_exists($lock) or !$this->helper->mkdir($lock)) {
						continue;
					}
					
					register_shutdown_function(function () use ($lock) {
						rmdir($lock);
					});
					
					include $script;
					
					$tasks[$script] = array(
						'interval' => $row['interval'],
						'time' => time() + $row['interval'] * 60,
					);
					
					$this->writeArray($cache_path, $tasks);
				}
			}
		}
		
		if (WebCash::DEBUG_SETTINGS) {
			echo 'ok';
		} else {
			header('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT');
			$im = imagecreate(1, 1);
			$blk = imagecolorallocate($im, 0, 0, 0);
			imagecolortransparent($im, $blk);
			header('Content-type: image/gif');
			imagegif($im);
			imagedestroy($im);
		}
		
		exit;
	}
	
	public function writeArray($cache_path, $tasks) {
		file_put_contents($cache_path.'tasks.php', '<?php return '.var_export($tasks, true).'; ?>');
	}

}