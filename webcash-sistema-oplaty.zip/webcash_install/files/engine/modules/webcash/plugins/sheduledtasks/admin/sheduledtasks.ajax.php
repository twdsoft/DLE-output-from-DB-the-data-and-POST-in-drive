<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

$webcash->sheduledtasks->readSettingsFromFile();


if ($action == 'ajax.plugin.from_tab1') {
	if ($subaction == 'create_sheduledtask') {
		$source_array = POST();
		$webcash->helper->emptyRequiredFields($source_array);
		
		if ($webcash->sheduledtasks->addItem($source_array)) {
			$webcash->admin_sheduledtasks->convertTasksToArray();
			
			if ($webcash->sheduledtasks->adm_reload_after_create)
				$webcash->helper->showMsgOk('Задача добавлена. Перезагрузка...', 'Информация', 'self');
			else
				$webcash->helper->showMsgOk('Задача добавлена');
		}
	}
	
} elseif ($action == 'ajax.plugin.from_tab2') {
	if ($subaction == 'empty_tasks_table') {
		$webcash->adminpanel->emptyTable($webcash->sheduledtasks->table_a);
		$webcash->admin_sheduledtasks->convertTasksToArray();
		
		$webcash->helper->showMsgOk('Таблица очищена. Перезагрузка...', 'Информация', 'self');
	} elseif ($subaction == 'edit_sheduledtask' and $id = (int)POST('id')) {
		$source_array = POST();
		$webcash->helper->emptyRequiredFields($source_array);
		
		if ($webcash->sheduledtasks->updateItem($source_array)) {
			$webcash->admin_sheduledtasks->convertTasksToArray();
			
			$webcash->helper->showMsgOk('Параметры задачи обновлены');
		}
		
	} elseif ($subaction == 'delete' and $id = (int)POST('id')) {
		if ($webcash->adminpanel->deleteRecordById($id, $webcash->sheduledtasks->table_a)) {
			$webcash->admin_sheduledtasks->convertTasksToArray();
			
			$webcash->helper->showMsgOk('Задача удалена. Перезагрузка...', 'Информация', 'self');
		}
	}
}

$webcash->helper->showMsgError('Ошибка при выполнении запроса');