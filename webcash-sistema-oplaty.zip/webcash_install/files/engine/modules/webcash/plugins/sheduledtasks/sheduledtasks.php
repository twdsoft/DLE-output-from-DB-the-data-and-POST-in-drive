<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

if (!$this->readSettingsFromFile()) {
	$this->setCfgValue('display_name', 'Выполнение задач по расписанию');
	$this->setCfgValue('description', 'С помощью этого плагина пользователь может осуществить выполнение запланированных задач по через определенные интервалы времени (упрощенный аналог крона).');
	$this->setCfgValue('on', false);
	$this->setConvCfgValue('frontend_header', 'Задачи по расписанию');
	$this->setCfgValue('default_amount', '100');
	$this->setCfgValue('default_ipp', 50);
	$this->setCfgValue('item_delete_button_confirm', 1);
	$this->setCfgValue('adm_reload_after_create', 1);
	$this->setConvCfgValue('date_format', 'j F Y г. H:i');
	
	
	$url = $this->webcash->site_url.'index.php?do=webcash&action=plugin&alias=sheduledtasks&subaction=cronpixel';
	$this->addHint(__FILE__.'1', 'Проверка запланированных задач и их запуск осуществляется с помощью однопиксельного изображения на сайте <a href="'.$url.'" target="_blank"><code>'.htmlentities('<img src="'.$url.'" alt="" />').'</code></a>.
	Помните, что вы в любой момент можете использовать стандартный крон вместо данного модуля.');
	
	
	$this->setFieldsItem('frontend_header', array(
		'title' => 'Название плагина на сайте',
		'hint' => 'Данное название плагина отображается для пользователей на сайте',
		'type' => 'text',
	));
	
	$this->setFieldsItem('default_ipp', array(
		'title' => 'Число записей на страницу',
		'hint' => 'Количество записей для постраничной навигации в списке',
		'type' => 'text',
	));
	
	$this->setFieldsItem('item_delete_button_confirm', array(
		'title' => 'Предупреждение перед удалением',
		'hint' => 'Если включено - то при удалении отдельной записи в списке при помощи кнопки, необходимо подтвердить действие',
		'type' => 'checkbox',
	));

	$this->setFieldsItem('adm_reload_after_create', array(
		'title' => 'Перезагружать после создания задачи',
		'hint' => 'Перезагружать или нет в админпанели страницу после создания новой задачи',
		'type' => 'checkbox',
	));
	
	$this->setFieldsItem('date_format', array(
		'title' => 'Формат даты',
		'hint' => 'Используется, например, при выводе даты в списке, <a href="#" onclick="javascript:Help(\'date\'); return false;">помощь по работе функции</a>',
		'type' => 'text',
	));
	
	
	$this->convertDefaultValues();
	$this->writeSettingsInFile(true);
}