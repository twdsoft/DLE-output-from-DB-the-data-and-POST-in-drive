<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

if (!$this->readSettingsFromFile()) {
	$this->setCfgValue('display_name', 'Пополнение баланса пользователя');
	$this->setCfgValue('description', 'С помощью этого плагина пользователь может осуществить пополнение своего баланса через любую платежную систему.');
	$this->setConvCfgValue('frontend_header', 'Пополнение баланса');
	$this->setCfgValue('default_amount', WebCash::DEBUG_SETTINGS ? 1 : 100);
	$this->setCfgValue('default_ipp', 50);
	$this->setCfgValue('item_delete_button_confirm', 1);
	$this->setCfgValue('access_allowed_usergroups', array());
	$this->setConvCfgValue('date_format', 'j F Y г. H:i');
	$this->setConvCfgValue('off_message', 'Пополнение баланса выключено');
	$this->setConvCfgValue('access_denied_message', 'Вашей группе доступ к плагину запрещен');
	$this->setNoneFormControlCfgValue('invoices_tbl_columns_list', 'nosort1,a.amount,a.gateway,a.user_id,a.email,a.ip,a.created,a.state,nosort2,a.id');
	$this->setNoneFormControlCfgValue('payments_tbl_columns_list', 'nosort1,a.amount,a.gateway,a.user_id,a.email,a.ip,a.invoice_id,a.created,a.state,nosort2,a.id');
	$this->setNoneFormControlCfgValue('public_cfg_fields', array(
		'frontend_header',
		'access_denied_message',
		'off_message',
		'frontend_list_rel_item_id_off',
	));
	$this->setNoneFormControlCfgValue('frontend_list_rel_item_id_off', 1);	
	
	
	$str = $this->getPluginFrontendUrl();
	$this->addHint(__FILE__.'1', 'Адрес страницы плагина на сайте <a href="'.$str.'" target="_blank">'.$str.'</a>.');
	
	
	$this->setFieldsItem('frontend_header', array(
		'title' => 'Название плагина на сайте',
		'hint' => 'Данное название плагина отображается для пользователей на сайте',
		'type' => 'text',
	));
	
	$this->setFieldsItem('default_amount', array(
		'title' => 'Сумма пополнения по умолчанию',
		'hint' => 'Данная сумма будет указана в форме пополнения баланса, если она не была определена в параметре ссылки на страницу пополнения. При необходимости, пользователь сможет изменить ее.',
		'type' => 'text',
	));
	
	$this->setFieldsItem('default_ipp', array(
		'title' => 'Число записей на страницу',
		'hint' => 'Количество записей для постраничной навигации в списке',
		'type' => 'text',
	));
	
	$this->setFieldsItem('item_delete_button_confirm', array(
		'title' => 'Предупреждение перед удалением',
		'hint' => 'Если включено - то при удалении отдельной записи в списке при помощи кнопки, необходимо подтвердить действие',
		'type' => 'checkbox',
	));
	
	$this->setFieldsItem('date_format', array(
		'title' => 'Формат даты на сайте',
		'hint' => 'Используется на сайте, например, при выводе даты в списке активированных промокодов, <a href="#" onclick="javascript:Help(\'date\'); return false;">помощь по работе функции</a>',
		'type' => 'text',
	));
	
	$this->setFieldsItem('off_message', array(
		'title' => 'Сообщение при выключенном плагине',
		'hint' => 'Данное сообщение отображается для пользователей на сайте, если плагин выключен',
		'type' => 'text',
	));
	
	$this->setFieldsItem('access_denied_message', array(
		'title' => 'Сообщение о запрете доступа',
		'hint' => 'Сообщение, которое будет показано пользователю, если ему на сайте будет закрыт доступ по группе',
		'type' => 'textarea',
		'tag_part' => 'style="height:90px;"',
	));
	
	
	$this->convertDefaultValues();
	$this->writeSettingsInFile(true);
}