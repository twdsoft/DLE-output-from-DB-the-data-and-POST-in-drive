<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

class Plugins_Admin_UpBalance extends Admin_AbstractListEntries
{
	protected $base_alias = 'upbalance';
	
	public function getGatewayInvoicesTblColumns() {
		$tbl_columns = parent::getGatewayInvoicesTblColumns();
		$tbl_columns = $this->filterUnusedColumns($tbl_columns);
		return $tbl_columns;
	}
	
	public function listGatewayInvoices($tab, $sql_addon = '') {
		return parent::listGatewayInvoices($tab, "WHERE a.area_alias = 'upbalance'");
	}
	
	public function getGatewayPaymentsTblColumns() {
		$tbl_columns = parent::getGatewayPaymentsTblColumns();
		$tbl_columns = $this->filterUnusedColumns($tbl_columns, 'a.rel_item_type,a.rel_item_id');
		return $tbl_columns;
	}
	
	public function listGatewayPayments($tab, $sql_addon = '') {
		return parent::listGatewayPayments($tab, "WHERE a.area_alias = 'upbalance'");
	}
}