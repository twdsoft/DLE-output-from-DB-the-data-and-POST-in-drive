<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

class Plugins_UpBalance extends AddonSettings
{
	const INVOICES_TAB = 1;
	const PAYMENTS_TAB = 2;
	
	protected $alias = 'upbalance';
	protected $constants = array(
		'methods_aliases' => array(
			'payments_log' => 'renderUserGatewayPaymentsLog',
		),
		'pay_types' => array(
			self::DEFAULT_PAYMENT => array(
				'title' => 'Пополнение через шлюз пользователем',
				'tab' => self::PAYMENTS_TAB,
			),
		),
	);
	
	public function webcashCall() {
		$this->mainIndexTopmenu();
	}
	
	public function renderIndex() {
		if ($str = $this->verifyPluginEnable())
			return $str;
		
		$tpl = $this->webcash->getTplInstance();
		$amount = only_float(GET('amount')) or $amount = $this->default_amount;
		$tpl->assign('amount', $amount);
		$tpl->assign('payments_log_url', $this->getPluginFrontendUrl('&subaction=payments_log'));
		$tpl->assign('plg_alias', $this->alias);
		$tpl->assign('plugin_cfg', $this->getCfgPublicParams());
		$tpl->assign('addon_settings_link', $this->renderAddonSettingsLink());
		$tpl->assign('user_hash', $this->user->nonce);
		$tpl->load_template('/modules/webcash/plugins/upbalance/index.tpl');
		
		$tpl->compile('content');
		
		$this->js_css->addJsFile($this->getDirUrl().'upbalance.js', true);
		
		return $tpl->result['content'];
	}
	
	public function setCheckoutStoreAndRedirect() {
		if ($this->user->isLoggedIn()) {
			if (!(float)POST('amount'))
				$this->helper->showMsgError('Укажите сумму пополнения');
			
			$checkout_store = array();
			$checkout_store['amount'] = only_float(POST('amount'));
			$checkout_store['email'] = $this->user->email;
			
			$this->checkout->endSetCheckoutStoreAndRedirect($this, $checkout_store);
		}
	}
	
	public function checkoutSuccessPayment($invoice_row, $payment_row) {
		return $this->incrementUserBalance($payment_row['amount'], self::DEFAULT_PAYMENT, $payment_row['id'], $payment_row['user_id']);
	}
	
	public function renderUserGatewayPaymentsLog() {
		return $this->listtransactions->renderUserGatewayPaymentsLog('/modules/webcash/plugins/upbalance/user_gateway_payments.tpl', $this->alias);
	}

}