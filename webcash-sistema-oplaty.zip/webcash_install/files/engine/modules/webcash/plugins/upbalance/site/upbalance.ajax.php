<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

$webcash->upbalance->readSettingsFromFile();


if ($action == 'checkout_set_store_and_redirect') {
	$webcash->upbalance->setCheckoutStoreAndRedirect();
}


$webcash->helper->showMsgError('Ошибка при выполнении запроса');