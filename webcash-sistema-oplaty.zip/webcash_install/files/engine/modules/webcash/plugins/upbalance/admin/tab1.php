<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

$tbl_columns = $this->admin_upbalance->getGatewayInvoicesTblColumns();
?>

<form action="" class="webcash_ajax_form form-horizontal" method="post" autocomplete="off">
	<div class="panel panel-flat">
		<div class="panel-body">
			
			<?php echo $this->adminpanel->renderCommonListPart(__FILE__, $tbl_columns); ?>
			
            <div class="dataTables_wrapper">
				<?php echo $this->admin_upbalance->listGatewayInvoices($active_tab2); ?>
			</div>
			
		
		</div>
	</div>
	<div class="buttons_wrap">
		<input type="hidden" name="action" value="ajax.plugin.from_tab1" />
		<input type="hidden" name="subaction" value="" />
		<input type="hidden" name="user_hash" value="<?php echo $this->user->nonce; ?>" />
		<input type="hidden" name="plg_alias" value="<?php echo $this->alias; ?>" />
		
		<a href="#" data-do="ajax-webcash" data-vars="action=ajax.plugin.from_tab1|subaction=empty_gateway_invoices_table|plg_alias=<?php echo $this->alias; ?>" data-confirm="1" title="<?php echo __('Очистить таблицу. Внимание, данная операция необратима!'); ?>" class="btn bg-danger btn-raised position-left btn-red">
			<i class="fa fa-trash-o position-left"></i><?php echo __('Очистить таблицу'); ?>
		</a>
		
		<?php echo $this->admin_upbalance->filterAndSortCancelButton($active_tab2); ?>
		
	</div>
</form>