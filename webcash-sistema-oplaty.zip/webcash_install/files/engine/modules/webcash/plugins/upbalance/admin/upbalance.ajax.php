<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

$webcash->upbalance->readSettingsFromFile();


if ($action == 'ajax.plugin.from_tab1') {
	if ($subaction == 'empty_gateway_invoices_table') {
		$webcash->admin_upbalance->deleteOwnedInvoicesEntries();
	} elseif ($subaction == 'delete' and $id = (int)POST('id')) {
		if ($webcash->adminpanel->deleteRecordById($id, $webcash->gateway_invoices_table)) {
			$webcash->helper->showMsgOk('Запись удалена. Перезагрузка...', 'Информация', 'self');
		}
	} elseif ($subaction == 'save_columns') {
		$webcash->admin_upbalance->saveTblColumnsList('invoices_tbl_columns_list', POST('tbl_columns_list'));
	}
	
} elseif ($action == 'ajax.plugin.from_tab2') {
	if ($subaction == 'empty_gateway_payments_table') {
		$webcash->admin_upbalance->deleteOwnedPaymentsEntries();
	} elseif ($subaction == 'delete' and $id = (int)POST('id')) {
		if ($webcash->adminpanel->deleteRecordById($id, $webcash->gateway_payments_table)) {
			$webcash->helper->showMsgOk('Запись удалена. Перезагрузка...', 'Информация', 'self');
		}
	} elseif ($subaction == 'save_columns') {
		$webcash->admin_upbalance->saveTblColumnsList('payments_tbl_columns_list', POST('tbl_columns_list'));
	}
}

$webcash->helper->showMsgError('Ошибка при выполнении запроса');