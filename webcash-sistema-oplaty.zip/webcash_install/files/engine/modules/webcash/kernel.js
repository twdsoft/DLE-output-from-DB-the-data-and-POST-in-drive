/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

WEBCASH = {

	lang: function (text) {
		return text;
	},

	callFunction: function (func) {
		var dim = func.split(".");
		if (dim.length > 1) {
			return window[dim[0]][dim[1]]();
		} else {
			return window[func]();
		}
	},

	redirectTo: function (url) {
		window.location.href = url;
	},
	
	declination: function(value, words) {
		var w = words.split("|"),
			n = Math.abs(value);
		return n % 10 == 1 && n % 100 != 11 ? w[0] + w[1] : (n % 10 >= 2 && n % 10 <= 4 && (n % 100 < 10 || n % 100 >= 20) ? w[0] + w[2] : w[0] + w[3]);
	},
	
	confirmDialog: function (dialogText, okFunc, cancelFunc, dialogTitle, options) {

		var wc = this,
			btns = {};
		
		btns[wc.lang("Нет")] = function() { 
			if (typeof (cancelFunc) == "function") {
				setTimeout(cancelFunc, 50);
			}
			$(this).dialog("destroy");
		};
		
		btns[wc.lang("Да")] = function() { 
			if (typeof (okFunc) == "function") {
				setTimeout(okFunc, 50);
				var win = $(this);
				setTimeout(function () {
					win.dialog("destroy");
				}, 250);
			} else {
				$(this).dialog("destroy");
			}
		};
		
		
		var defaults = {
			modal: true,
			resizable: false,
			width: "auto",
			minHeight: 75,
			zIndex: 99999,
			title: dialogTitle || wc.lang("Необходимо подтверждение"),
			buttons: btns
		};	

		$.extend(defaults, options);
		
		$('<div style="padding: 10px; max-width: 100%; word-wrap: break-word;">' + (dialogText || wc.lang("Вы уверены, что хотите это сделать?")) + "</div>").dialog(defaults);
	},

	showAjaxError: function (data) {
		if (typeof $.ui.dialog === "function") {		
			this.confirmDialog(
				data.responseText,
				function() {
					$(this).dialog("close");
				},
				null,
				"Ajax error",
				{buttons: null}
			);
		} else {
			alert(data.responseText);
		}
	},

	showResponse: function (data, sender) {
		var wc = this;
		
		if (!data.redirect)
			HideLoading();

		
		var sticky_options = (typeof data.sticky_options !== "undefined") ? data.sticky_options : {};
		
		if (data.msg) {
			if (data.status == "ok") {
				wc.info({ title: data.msg.title, text: data.msg.text, life: sticky_options.autoclose });
			} else if (data.status == "error") {
				wc.error({ title: data.msg.title, text: data.msg.text, life: sticky_options.autoclose });
			}
		}
		
		if (data.container && data.func) {
			var $target = (data.container == "sender") ? sender : $(data.container);
			$target.html(data.response).fadeIn("slow",function() {
				wc.callFunction(data.func);
			});
		} else if (data.container) {
			var $target = (data.container == "sender") ? sender : $(data.container);
			$target.html(data.response);
		} else if (data.append_container && data.func) {
			$(data.append_container).append(data.response);
			wc.callFunction(data.func);
		} else if (data.append_container) {
			$(data.append_container).append(data.response);
		} else if (data.func) {
			wc.callFunction(data.func);
		}
		
		if (data.redirect) {
			setTimeout(function() {
				if (data.redirect == "self")
					window.location.reload();
				else
					wc.redirectTo(data.redirect);
			}, 1000);
		}
	},

	doAjax: function (sender) {
		var wc = this,
			url = sender.data("url"),
				str = sender.data("vars"),
					query_str = str.replace(/\|/g, "&"),
						silent = query_str.indexOf("&silent=1") !== -1;
		
		if (query_str.indexOf("&user_hash=") == -1)
			query_str += "&user_hash=" + WEBCASH_OPTIONS.USER_HASH;
		
		if (typeof url === "undefined") {
			url = WEBCASH_OPTIONS.IN_ADMINPANEL ? WEBCASH_OPTIONS.ADMIN_URL : WEBCASH_OPTIONS.SITE_AJAX_URL;
		}
		
		if (!silent)
			ShowLoading("");
		
		$.ajax({
			type: "POST",
			url: url,
			data: query_str,
			dataType: "json",
			success: function(data) {
				if (!data.redirect) {
					sender.attr("disabled", false);
				}
				
				if (silent)
					data.msg = "";
				
				wc.showResponse(data, sender);
			},
			error: function(data) {
				HideLoading();
				wc.showAjaxError(data);
			}
		});
		
		return false;
	},
	
	linked_select: {
		get_elements: function() {
			return $("select[data-linked_select]");
		},
		init: function(disable_hidden) {
			if (typeof disable_hidden === "undefined")
				disable_hidden = false;
			
			var self = this;
			this.get_elements().change(function() {
				self.exec($(this), disable_hidden);
			});
			
			//this.refresh();
		},
		refresh: function(elements) {
			if (typeof elements === "undefined")
				elements = this.get_elements();
			
			var self = this;
			$.each(elements, function(i, elem) {
				var $container = $(this).parents(":dataStartsWith(linked_container_)");
				
				if (!$container.length || $container.is(":visible")) {
					self.exec(elem);
				}
			});
		},
		exec: function(element, disable_hidden) {
			var prefix = $(element).data("linked_select");
			WEBCASH.linkedContainer($(element).val(), prefix, disable_hidden);
		},
	},

	linked_checkbox: {
		get_elements: function() {
			return $("input[data-linked_checkbox]");
		},
		init: function(disable_hidden) {
			if (typeof disable_hidden === "undefined")
				disable_hidden = false;

			var self = this;
			this.get_elements().change(function() {
				self.exec($(this), disable_hidden);
			});
			
			//this.refresh();
		},
		refresh: function(elements) {
			if (typeof elements === "undefined")
				elements = this.get_elements();
			
			var self = this;
			$.each(elements, function(i, elem) {
				var $container = $(this).parents(":dataStartsWith(linked_container_)");
				
				if (!$container.length || $container.is(":visible")) {
					self.exec(elem);
				}
			});
		},
		exec: function(element, disable_hidden) {
			var prefix = $(element).data("linked_checkbox");
			
			if ($(element).prop("checked"))
				WEBCASH.linkedContainer("1", prefix, disable_hidden);
			else
				WEBCASH.linkedContainer("0", prefix, disable_hidden);
		}
	},
	
	linkedContainer: function (val, prefix, disable_hidden) {
		var $elements_has = $("[data-linked_container_" + prefix + "~='" + val + "']");
		var $elements_not = $("[data-linked_container_" + prefix + "]").not($elements_has);
		this.toggleContainer($elements_has, $elements_not, disable_hidden);
		
		$elements_has = $("[data-linked_container_" + prefix + "_not~='" + val + "']");
		$elements_not = $("[data-linked_container_" + prefix + "_not]").not($elements_has);
		this.toggleContainer($elements_not, $elements_has, disable_hidden);
	},

	toggleContainer: function ($elements_has, $elements_not, disable_hidden) {
		var wc = this;
		
		if ($elements_not.length) {
			$elements_not.slideUp("slow", function() {
				if (disable_hidden)
					$elements_not.find(wc.getDisabledSelectors()).attr("disabled", "disabled");
				
				if ($elements_has.length) {
					$elements_has.slideDown("slow", function() {
						wc.nextLinked($elements_has, $elements_not);
					}).find(wc.getDisabledSelectors()).removeAttr("disabled");
				} else {
					wc.nextLinked($elements_has, $elements_not);
				}
			});

		} else {
			if ($elements_has.length) {
				$elements_has.slideDown("slow", function() {
					wc.nextLinked($elements_has, $elements_not);
				}).find(wc.getDisabledSelectors()).removeAttr("disabled");
			}
		}
	},
	
	nextLinked: function ($elements_has, $elements_not) {
		this.linked_select.refresh($elements_has.find("select[data-linked_select]"));//элемент стал видим - переключаем связанные элементы
		this.hideLinked($elements_not.find("select[data-linked_select]"));//элемент был скрыт - скрываем связанные элементы
		
		this.linked_checkbox.refresh($elements_has.find("input[data-linked_checkbox]"));//элемент стал видим - переключаем связанные элементы
		this.hideLinked($elements_not.find("input[data-linked_checkbox]"));//элемент был скрыт - скрываем связанные элементы
	},
	
	hideLinked: function(elements) {
		$.each(elements, function(i, elem) {
			var prefix = $(elem).data("linked_select");
			if (typeof prefix === "undefined")
				prefix = $(elem).data("linked_checkbox");
			
			$("[data-linked_container_" + prefix + "]").not("[data-linked_container_options_" + prefix + "~='ignore_hide_linked']").slideUp("slow");
			$("[data-linked_container_" + prefix + "_not]").not("[data-linked_container_options_" + prefix + "~='ignore_hide_linked']").slideUp("slow");
		});
	},
	
	disableHidden: function(elements) {
		if (typeof elements === "undefined")
			elements = $(":dataStartsWith(linked_container_):hidden");
		
		elements.find(this.getDisabledSelectors()).attr("disabled", "disabled");
	},
	
	getDisabledSelectors: function () {
		return "input[name='required_fields[]']";
	},
	
	info: function(options) {
		if (typeof options === "string") {
			var str = options;
			options = {};
			options.title = this.lang("Информация");
			options.text = str;
		}
		
		return $.jGrowl({
			header: options.title,
			message: options.text,
			life: options.life,
			theme: 'alert-styled-left alert-styled-custom alpha-teal',
			closerTemplate:	"<div>[ " + WEBCASH_OPTIONS.NDGROWL_CLOSER_CAPTION + " ]</div>"
		});
	},
	
	error: function(options) {
		if (typeof options === "string") {
			var str = options;
			options = {};
			options.title = this.lang("Ошибка");
			options.text = str;
		}
		
		return $.jGrowl({
			header: options.title,
			message: options.text,
			life: options.life,
			theme: 'alert-styled-left alert-danger',
			closerTemplate:	"<div>[ " + WEBCASH_OPTIONS.NDGROWL_CLOSER_CAPTION + " ]</div>"
		});
	},
	
	inWindow: function() {
		if (typeof jQuery.fn.inWindow === "undefined") {
			jQuery.fn.inWindow = function() {
				var scrollTop = $(window).scrollTop() + 50;/*40*/
				var windowHeight = $(window).height();
				var scrollBottom = scrollTop + windowHeight;
				var result = [];
				var top, bottom, temp, ratio = 0;
				
				this.each(function() {
					var el = $(this);
					var offset = el.offset();
					var el_bottom = el.height() + offset.top;

					if ((offset.top > scrollTop && offset.top < scrollBottom) || (el_bottom > scrollTop && el_bottom < scrollBottom) || (offset.top < scrollTop && el_bottom > scrollBottom)) {
						top = Math.max(offset.top, scrollTop);
						bottom = Math.min(el_bottom, scrollBottom);
						
						temp = (bottom - top) / (el_bottom - offset.top);
						if (temp > ratio) {
							ratio = temp;
							result[0] = this;
						}
					}
				});

				return $(result);
			};
		}
	},
	
	dataStartsWith: function() {
		if (typeof jQuery.expr[":"].dataStartsWith === "undefined") {
			
			jQuery.extend(jQuery.expr[":"], { 
				"dataStartsWith" : function(el, i, p, n) {  
					var pCamel = p[3].replace(/-([a-z])/ig, function(m, $1) {
						return $1.toUpperCase();
					});
					return Object.keys(el.dataset).some(function(i, v){
						return i.indexOf(pCamel) > -1;
					});
				}
			});
		}
	},
	
	setDataVarsValue: function(sender, key, value) {
		var vars = sender.data("vars"),
			str = "|" + key + "=" + value;
		
		if (vars.indexOf(key) === -1) {
			vars += str;
		} else {
			var re = new RegExp("\\|" + key + "=[^\\|]*"); 
			vars = vars.replace(re, str);
		}
		
		sender.data("vars", vars);
	},
	
	updateRelatedElementAmount: function(sender) {
		var value = sender.val().replace(/[^\d]/g, ""),
			a = sender.data("multiplication"),
				dim = a.split("|"),
					price = dim[0],
						selector = dim[1],
							declination = dim[2];
		
		sender.val(value);
		value = value * parseInt(price);
		
		if (typeof declination !== "undefined") {
			value += " " + this.declination(value, declination.replace(/\*/g, "|"));
		}
		
		$(selector).html(value);
	},
	
	bindAjaxForms: function() {
		var kernel = this;
		
		$(document).on("submit", "form.webcash_ajax_form", function() {
			var url = $(this).attr("action"),
				query_str = $(this).serialize(),
					silent = query_str.indexOf("&silent=1") !== -1;
			
			if (!silent)
				ShowLoading("");
			
			if (typeof url === "undefined" || !url) {
				url = WEBCASH_OPTIONS.IN_ADMINPANEL ? WEBCASH_OPTIONS.ADMIN_URL : WEBCASH_OPTIONS.SITE_AJAX_URL;
			}
			
			$.post(url, query_str, function( data ) {
				if (silent)
					data.msg = "";
				
				kernel.showResponse(data);
			}, "json")
			.fail(function(response) {
				HideLoading();
				kernel.showAjaxError(response);
			});
			
			return false;
		});
	},	
	
	bindAjaxButtons: function() {
		var kernel = this;
		
		$(document).on("click", 'a[data-do="ajax-webcash"], input[data-do="ajax-webcash"]', function(event) {
			var sender = $(this);
				
			if (typeof sender.data("confirm") !== "undefined") {

				kernel.confirmDialog(
					sender.data("msg"),
					function() {
						kernel.doAjax(sender);
					}, 
					null,
					sender.data("title")
				);

			} else {
				kernel.doAjax(sender);
			}
			
			return false;
		});

	},


};



jQuery(document).ready(function($) {
	WEBCASH.bindAjaxForms();
	WEBCASH.bindAjaxButtons();
	
});