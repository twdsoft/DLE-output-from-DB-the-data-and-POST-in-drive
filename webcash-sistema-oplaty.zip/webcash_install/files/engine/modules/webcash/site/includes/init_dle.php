<?php
@error_reporting(E_ALL ^ E_WARNING ^ E_DEPRECATED ^ E_NOTICE);
@ini_set('error_reporting', E_ALL ^ E_WARNING ^ E_DEPRECATED ^ E_NOTICE);
@ini_set('display_errors', true);
@ini_set('html_errors', false);

define('DATALIFEENGINE', true);

$fname = ENGINE_DIR.'/classes/plugins.class.php';
if (file_exists($fname)) {
	require_once $fname;

	date_default_timezone_set($config['date_adjust']);

	require_once DLEPlugins::Check(ENGINE_DIR.'/modules/functions.php');
	require_once DLEPlugins::Check(ENGINE_DIR.'/classes/mysql.php');
	require_once DLEPlugins::Check(ENGINE_DIR.'/classes/templates.class.php');
} else {
	require_once ENGINE_DIR.'/data/config.php';

	date_default_timezone_set($config['date_adjust']);
	
	require_once ENGINE_DIR.'/modules/functions.php';
	require_once ENGINE_DIR.'/classes/mysql.php';
	require_once ENGINE_DIR.'/classes/templates.class.php';	
}

require_once ENGINE_DIR.'/data/dbconfig.php';
include_once ROOT_DIR.'/language/'.$config['langs'].'/website.lng';


if (function_exists('dle_session'))
	dle_session();
else
	@session_start();

$user_group = get_vars('usergroup');
$is_logged = false;
require_once ENGINE_DIR.'/modules/sitelogin.php';
if (!$is_logged)
	$member_id['user_group'] = 5;


if (defined('IS_AJAX')) {
	$cat_info = get_vars('category');
	
	if (!is_array($cat_info)) {
		$cat_info = array();
		
		if ($rows = $webcash->db->select("SELECT * FROM ".PREFIX."_category ORDER BY posi ASC")) {
			foreach ($rows as $row) {
				$cat_info[$row['id']] = array();
				
				foreach ($row as $key => $value) {
					$cat_info[$row['id']][$key] = stripslashes($value);
				}
			}
		}
		
		set_vars('category', $cat_info);
	}
}