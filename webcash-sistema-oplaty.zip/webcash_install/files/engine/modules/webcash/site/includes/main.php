<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

require ENGINE_DIR.'/modules/webcash/init.php';

if ($webcash->frontendIsEnable()) {
	$tpl->result['main'] = $webcash->handleMainContent($tpl->result['main']);
}