/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

jQuery(document).ready(function($) {

	WEBCASH.dataStartsWith();
	WEBCASH.linked_select.init(true);
	WEBCASH.linked_select.refresh();
	
});