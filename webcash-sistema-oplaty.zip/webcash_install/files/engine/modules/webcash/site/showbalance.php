<?php
require ENGINE_DIR.'/modules/webcash/init.php';

if ($webcash->user->isLoggedIn()) {
	//echo $webcash->user->getUserBalance();//просто баланс
	echo $webcash->wc_currency->currCnvDeclension($webcash->user->getUserBalance());//баланс с полным названием валюты
	//echo $webcash->wc_currency->currCnvShort($webcash->user->getUserBalance());//баланс с сокращенным названием валюты
}