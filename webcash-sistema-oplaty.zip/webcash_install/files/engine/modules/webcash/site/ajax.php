<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

define('ROOT_DIR', dirname(dirname(dirname(dirname(dirname(__FILE__))))));
define('ENGINE_DIR', ROOT_DIR.'/engine');
define('IS_AJAX', true);

require_once ENGINE_DIR.'/modules/webcash/site/includes/init_dle.php';
require_once ENGINE_DIR.'/modules/webcash/init.php';


if (!$action = POST('action'))
	$webcash->helper->showMsgError('Не указан тип операции');

if (!$str = POST('user_hash') or $str != $webcash->user->nonce) 
	$webcash->helper->showMsgError('Пустой или неверный ключ, попробуйте обновить страницу');

if (!$webcash->frontendIsEnable())
	$webcash->helper->showMsgError('Запрещенная операция');


$subaction = POST('subaction');


if ($gw_alias = only_word(POST('gw_alias'))) {
	require_once $webcash->module_path.'gateways/'.$gw_alias.'/site/'.$gw_alias.'.ajax.php';
} elseif ($plg_alias = only_word(POST('plg_alias'))) {
	if ($instance = $webcash->getAddonInstanceByAlias($plg_alias)) {
		if ($instance->on)
			require_once $webcash->module_path.'plugins/'.$plg_alias.'/site/'.$plg_alias.'.ajax.php';
		else
			$webcash->helper->showMsgErrorNotTranslate($instance->off_message);
	}
}


$webcash->helper->showMsgError('Ошибка при выполнении запроса');