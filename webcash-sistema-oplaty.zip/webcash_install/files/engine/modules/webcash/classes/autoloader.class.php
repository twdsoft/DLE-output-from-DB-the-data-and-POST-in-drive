<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

class Autoloader
{
	private static $basepath;
	private static $imports;
	
	public function __construct() {
		self::$basepath = ENGINE_DIR.'/modules/webcash/';
		spl_autoload_register(array($this, 'autoload'));
	}
	
	public static function autoload($class) {
		if (strpos($class, 'WebCash') !== 0) {
			return;
		}
		
		$class = str_replace('WebCash\\', '', $class);
		
		if (strpos($class, '\\') === false or strpos($class, 'Plugins_') === 0 or strpos($class, 'Gateways_') === 0) {
		
			if ($double_line_finded = (strpos($class, '__') !== false))
				$class = str_replace('__', '/', $class);
			
			$class = strtolower($class);
			
			if (strpos($class, '_') !== false) {
				if (strpos($class, 'plugins_admin_') === 0) {
					$alias = basename(str_replace('plugins_admin_', '', $class));
					$file = 'plugins/'.$alias.'/admin/'.$alias.'.admin';// Plugins_Admin_PayHideContent: $filepath --> /engine/modules/webcash/plugins/payhidecontent/admin/payhidecontent.admin.class.php
				} elseif (strpos($class, 'gateways_admin_') === 0) {
					$alias = basename(str_replace('gateways_admin_', '', $class));
					$file = 'gateways/'.$alias.'/admin/'.$alias.'.admin';// Gateways_Admin_Webmoney: $filepath --> /engine/modules/webcash/gateways/webmoney/admin/webmoney.admin.class.php
				} elseif (strpos($class, 'plugins_') === 0) {
					$file = str_replace('plugins_', 'plugins/', $class);
					
					if (!$double_line_finded) {
						$file .= '/'.basename($file);// Plugins_ChangeGroup: $filepath --> /engine/modules/webcash/plugins/changegroup/changegroup.class.php
					}
					//else Plugins_PayHideContent__Admin__Classes__PayHideContent: $filepath --> /engine/modules/webcash/plugins/payhidecontent/classes/payhidecontent.class.php
					
				} elseif (strpos($class, 'gateways_') === 0) {
					$file = str_replace('gateways_', 'gateways/', $class);
					
					if (!$double_line_finded) {
						$file .= '/'.basename($file);// Gateways_YandexMoney: $filepath --> /engine/modules/webcash/gateways/yandexmoney/yandexmoney.class.php
					}
					
				} elseif (strpos($class, 'admin_plugins_') === 0) {
					$alias = str_replace('admin_plugins_', '', $class);
					$alias = strtolower($alias);
					$file = 'admin/plugins/'.$alias.'/'.$alias;
				} elseif (strpos($class, 'admin_') === 0) {
					$file = str_replace('admin_', 'admin/classes/admin', $class);// Admin_Panel: $filepath --> /admin/classes/adminpanel.class.php
				}
				
			} else {
				$file = 'classes/'.$class;// Application: $filepath --> /engine/modules/webcash/classes/application.class.php
			}

			$filepath = self::$basepath.$file.'.class.php';
			
		} else {
			$class = str_replace('\\', '/', $class);
			$filepath = self::$basepath.'lib/'.$class.'.php';
		}
		
		
		try {
			self::import($filepath);
			return true;
		} catch (\Exception $exc) {
			echo $exc;
			exit;
		}
	}
	
	private static function import($filepath) {
		global $db;
		
		if (empty(self::$imports[$filepath])) {
			//LAST
			if (is_file($filepath)) {
				self::$imports[$filepath] = true;
				if (strpos($filepath, 'webcash.class.php') !== false or strpos($filepath, 'application.class.php') !== false or empty($db)) {
					return require $filepath;
				} else {
					return require WebCash::checkPlugins($filepath);
				}
			} else {
				trigger_error('Oops! System file lost: '.$filepath, E_USER_ERROR);
			}
		}
		
		return true;
	}

}