<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

class UserXfields extends Application
{
	const XFIELDS_FILE = 'xprofile.txt';
	
	public function addXfield($xfieldline) {
		$path = ENGINE_DIR.'/data/'.$this::XFIELDS_FILE;
		$xfields_lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
		
		$arr = explode('|', $xfieldline);
		$fieldname = $arr[0];
		
		if ($xfields_lines and is_array($xfields_lines)) {
			foreach ($xfields_lines as $line) {
				if (strpos($line, $fieldname.'|') === 0)
					return true;
			}
		}
		
		$xfields_lines[] = $xfieldline;
		
		return file_put_contents($path, implode("\r\n", $xfields_lines));
	}
	
	public function deleteXfield($fieldname) {
		$path = ENGINE_DIR.'/data/'.$this::XFIELDS_FILE;
		$xfields_lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

		if ($xfields_lines and is_array($xfields_lines)) {
			foreach ($xfields_lines as $index => $line) {
				if (strpos($line, $fieldname.'|') === 0)
					unset($xfields_lines[$index]);
			}
			$xfields_lines = array_values($xfields_lines);
		}
		
		return file_put_contents($path, implode("\r\n", $xfields_lines));
	}
	
	public function makeXfieldLine($name, $title, $type = 'text') {
		return implode('|', array(
            $name,//[0] Имя
            $title,//[1] Название
            0,//Добавить на страницу регистрации?
            $type,//[3] Тип поля
            0,//Поле может быть изменено пользователем?
            0,//Сделать это поле личным?
            '',
		));
	}
	
	public function getXfieldValue($name, $user_id = 0) {
		if ($xfields = $this->loadXfieldsArrayFromDb($user_id)) {
			if (isset($xfields[$name]))
				return $xfields[$name];
		}
	}
	
	public function setXfieldValue($name, $value, $user_id = 0) {
		$xfields = $this->loadXfieldsArrayFromDb($user_id);
		
		$xfields[$name] = $value;
		return $this->saveXfieldsArrayToDb($xfields, $user_id);
	}
	
	public function removeXfieldValue($name, $user_id = 0) {
		$xfields = $this->loadXfieldsArrayFromDb($user_id);
		
		unset($xfields[$name]);
		return $this->saveXfieldsArrayToDb($xfields, $user_id);
	}
	
	public function loadXfieldsArrayFromDb($user_id = 0) {
		$user_id or $user_id = $this->user->id;
		$user_id = (int)$user_id;
		
		if ($str = $this->db->selectCell("SELECT xfields FROM ".USERPREFIX."_users WHERE user_id = '{$user_id}' LIMIT 1")) {
			return $this->getXfieldsWithKeyName($str);
		}
		
		return array();
	}
	
	public function saveXfieldsArrayToDb($xfields, $user_id = 0) {
		$user_id or $user_id = $this->user->id;
		$user_id = (int)$user_id;
		
		$str = '';
		foreach ($xfields as $key => $value) {
			$str .= ($str ? '||' : '')."{$key}|{$value}";
		}
		$str = $this->db->escape($str);
		
		return $this->db->query("UPDATE ".USERPREFIX."_users SET xfields = '{$str}' WHERE user_id = '{$user_id}' LIMIT 1");
	}
	
	public function getXfieldsWithKeyName($xfields_str) {
		$result_array = array();
		if ($xfields_str) {
			$lines = explode('||', $xfields_str);
			foreach ($lines as $line) {
				$arr = explode('|', $line);
				$result_array[$arr[0]] = $arr[1];
			}
		}
		return $result_array;
	}
	
}