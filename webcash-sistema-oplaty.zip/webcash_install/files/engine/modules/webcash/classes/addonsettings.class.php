<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

class AddonSettings extends Application
{
	const DEFAULT_PAYMENT = 1;
	
	protected $alias = '';
	protected $path = '';
	protected $dir_url = '';
	protected $rel_dir_url = '';
	protected $ff = array();
	protected $cfg = array(
		'on' => 1,
		'cache_on' => 1,
		'required_usergroup' => 0,
		'col_values' => array(
			'xs' => array(6, 6),
			'sm' => array(6, 6),
			'md' => array(7, 5)
		),
		'convertable' => array(),
	);
	protected $access_can_managed = false;//управляет показом выпадающего списка "Ограничение по группе" в настройках дополнения, то есть можно или нет назначать группу для ограничения доступа к дополнению
	protected $settings_already_read = false;
	protected $admin_instance = null;
	protected $data_array = array();
	protected $data = array();
	
	public function __get($name) {
		if (isset($this->cfg[$name])) {
			$value = $this->cfg[$name];
			
			if ($this->helper->isAjax() and $this->helper->isWin1251Charset() and $convertable = safe_array_access($this->cfg, 'convertable')) {
				if ($convertable and in_array($name, $convertable)) {
					$value = to_utf8($value);
				}
			}
			
			return $value;
		} else {
			return parent::__get($name);
		}
	}
	
	public function getPath() {
		$this->path or $this->path = $this->webcash->module_path.$this->checkPluginOrGateway('plugins/', 'gateways/').$this->alias.'/';
		return $this->path;
	}
	
	public function getAbsDirUrl() {
		$this->dir_url or $this->dir_url = $this->webcash->module_url.$this->checkPluginOrGateway('plugins/', 'gateways/').$this->alias.'/';
		return $this->dir_url;
	}
	
	public function getDirUrl() {
		$this->rel_dir_url or $this->rel_dir_url = $this->webcash->rel_module_url.$this->checkPluginOrGateway('plugins/', 'gateways/').$this->alias.'/';
		return $this->rel_dir_url;
	}
	
	public function checkPluginOrGateway($plugin_word, $gateway_word) {
		return $this->isPlugin() ? $plugin_word : $gateway_word;
	}
	
	public function isPlugin() {//это плагин или шлюз
		$class = get_class($this);
		return strpos($class, 'WebCash\Plugins_') === 0;//это плагин
	}
	
	public function readSettingsFromFile($enable_init_addon = false, $anyway_read = false) {
		static $init_addon_flag = false;
		
		if ($this->settings_already_read and !$anyway_read) {
			return true;
		}
		
		$filepath = $this->getPath().'settings.dat.php';
		if (file_exists($filepath)) {
			$data = unserialize(file_get_contents($filepath));
			if (is_array($data)) {
				$this->cfg = $data;
				$this->settings_already_read = true;
				return true;
			}
		} elseif (!$init_addon_flag and $enable_init_addon) {
			$init_addon_flag = true;
			$this->initAddon($this->alias);
		}
	}
	
	public function writeSettingsInFile($write_adm = false) {
		if (!is_writable($this->getPath()))
			trigger_error('Not permission to write: '.$this->getPath(), E_USER_ERROR);
		
		if ($write_adm) {
			$filepath = $this->getPath().'settings_adm.dat.php';
			file_put_contents($filepath, serialize($this));
		}

		$filepath = $this->getPath().'settings.dat.php';
		file_put_contents($filepath, serialize($this->cfg));
		return file_exists($filepath);
	}
	
	public function initAddon($addon_alias = '') {
		$addon_alias or $addon_alias = $this->alias;
		$filepath = $this->getPath().$addon_alias.'.php';
		$webcash = $this->webcash;
		return require $filepath;
	}
	
	public function setSettings($source_array) {//кроме всего, если есть изменения - сбрасывает кэш дополнения
		$this->helper->emptyRequiredFields($source_array);
		
		$was_changed = false;
		$addon_alias = $source_array['addon_alias'];
		$filepath = $this->getPath().'settings_adm.dat.php';

		if (file_exists($filepath)) {
		
			$addon_sett = unserialize(file_get_contents($filepath));
			$addon_sett->readSettingsFromFile(false, true);
			$convertable = safe_array_access($addon_sett->cfg, 'convertable');
			
			$source_array = $this->helper->fixMissedElements(safe_array_access($source_array, 'fix_missed_integer'), $source_array, 0);
			$source_array = $this->helper->fixMissedElements(safe_array_access($source_array, 'fix_missed_array'), $source_array, array());
			
			if (!empty($source_array['data'])) {
				
				foreach ($source_array['data'] as $k => $v) {
				
					if ($convertable and in_array($k, $convertable))
						$v = to_win1251($v);
				
					if ($addon_sett->cfg[$k] != $v) {
						$was_changed = true;
						$addon_sett->cfg[$k] = $v;
						
						if ($arr = POST('redirect_after_changing') and in_array($k, $arr)) {//перезагрузка страницы в случае изменения указанных параметров (ключей)
						
							$this->helper->assignAjaxResultVar('redirect', 'self');
							$this->helper->assignAjaxResultVar('msg', array(
								'title' => 'Информация',
								'text' => 'Параметры дополнения обновлены. Перезагрузка...'
							));
						}
					}
				}
			}


			if ($was_changed) {
				return $addon_sett->writeSettingsInFile(true);
			}
			
		} else {
			$this->helper->showMsgErrorNotTranslate(sprintf(lang('Не найден конфигурационный файл дополнения &laquo;%s&raquo;'), $filepath));
		}
		
		return false;
	}
	
	public function writeCfgValue($key, $value) {
		if ($this->readSettingsFromFile()) {
			if ($this->cfg[$key] != $value) {
				$this->setCfgValue($key, $value);
				return $this->writeSettingsInFile();
			}
		}
	}
	
	public function setConvCfgValue($key, $value) {
		$this->setCfgValue($key, $value);
		$this->cfg['convertable'][] = $key;
	}
	
	public function setNoneFormControlCfgValue($key, $value) {//синоним
		$this->setCfgValue($key, $value);
	}
	
	public function setCfgValue($key, $value) {
		$this->cfg[$key] = $value;
	}
	
	public function setFieldsItem($key, $params) {
		$this->ff[$key] = $params;
	}
	
	public function addCustomPositionBlocks($suffix = '') {
		$this->ff[] = array('type' => 'custompos_blocks', 'content' => $suffix);
	}
	
	public function addSeparator() {
		$this->ff[] = array('type' => 'separator');
	}
	
	public function addHtml($html) {
		$this->ff[] = array('type' => 'html', 'content' => $html);
	}
	
	public function addHint($hint_name, $hint_content, $translate = true) {
		$str = totranslit(basename($hint_name), true, false);
		$this->ff[] = array('type' => 'hint', 'name' => $this->alias.'_'.$str, 'hint' => $hint_content, 'translate' => $translate);
	}
	
	public function getPluginFrontendUrl($ending = '') {
		return $this->webcash->site_url.'index.php?do=webcash&action=plugin&alias='.$this->alias.$ending;
	}
	
	public function renderAddonSettingsLink($ending = '') {
		$str = !empty($this->cfg['frontend_header']) ? $this->frontend_header : __($this->display_name);
		return ($this->config->adm_fastlink_on and $this->user->isAdminGroup()) ? '<div class="addon_settings"><a href="'.$this->getAddonSettingsUrl($ending).'" title="'.__('Перейти в настройки дополнения').' &laquo;'.__($this->display_name).'&raquo;">'.__('НАСТРОЙКИ ДОПОЛНЕНИЯ').' &laquo;'.$str.'&raquo;</a></div>' : '';
	}
	
	public function getAddonSettingsUrl($ending = '') {
		return $this->webcash->module_admin_url.'&tab='.$this->checkPluginOrGateway(Admin_Panel::PLUGINS_TAB, Admin_Panel::GATEWAYS_TAB).'&action=addonsett&'.$this->checkPluginOrGateway('plg_alias', 'gw_alias').'='.$this->alias.$ending;
	}	
	
	public function convertDefaultValues() {
		if ($this->helper->isWin1251Charset() and $convertable = safe_array_access($this->cfg, 'convertable')) {
			foreach ($this->cfg as $k => &$v) {
				if (in_array($k, $convertable)) {
					$v = __($v);
				}
			}
		}
	}
	
	public function getCfgPublicParams($addon_alias = '') {
		$instance = $addon_alias ? $this->webcash->getAddonInstanceByAlias($addon_alias) : $this;
		
		$output_array = array();
		if ($arr = safe_array_access($instance->cfg, 'public_cfg_fields')) {
			foreach ($instance->cfg as $k => $v) {
				if (in_array($k, $arr)) {
					$output_array[$k] = $v;
				}
			}
		}
		
		return $output_array;
	}
	
	public function formatDate($datetime, $is_timestamp = false) {
		$timestamp = $is_timestamp ? $datetime : strtotime($datetime);
		
		if ($timestamp === false) {
			return $datetime;
		}
		
		$result = langdate($this->date_format, $timestamp);
		if ($this->helper->isAjax()) {
			$result = to_utf8($result);
		}
		return $result;
	}
	
	public function incrementUserBalance($value, $rel_item_type = 0, $rel_item_id = 0, $user_id = 0) {
		return $this->user->incrementUserBalance($value, $this->alias, $rel_item_type, $rel_item_id, $user_id);
	}
	
	public function decrementUserBalance($value, $rel_item_type = 0, $rel_item_id = 0, $user_id = 0) {
		return $this->user->decrementUserBalance($value, $this->alias, $rel_item_type, $rel_item_id, $user_id);
	}
	
	public function mainIndexTopmenu() {
		$arr = array(
			'url' => $this->webcash->site_url.'index.php?do=webcash&action=plugin&alias='.$this->alias,
			'encore' => $this->frontend_header,
			'title' => __($this->display_name),
			'class' => (GET('do') == 'webcash' and GET('action') == 'plugin' and GET('alias') == $this->alias) ? 'wc-btn-active' : '',
		);
		
		$this->webcash->set('main_index_topmenu|'.$this->alias, $arr);
	}
	
	public function verifyPluginEnable($guest_allowed = false) {
		if (!$this->on)
			return $this->webcash->getMsgContentNotTranslateNotConvert($this->off_message, __('Информация'));
		
		if (!$guest_allowed and !$this->user->isLoggedIn())
			return $this->webcash->getMsgContent('Раздел доступен только для зарегистрированных пользователей');
		
		if ($this->access_allowed_usergroups and !in_array($this->user->group, $this->access_allowed_usergroups))
			return $this->webcash->getMsgContent('Вашей группе доступ запрещен');
	}
	
	public function verifyGatewayEnable() {
		if (!$this->on)
			return $this->webcash->getMsgContent('Платежный шлюз выключен');
		
		if ($this->access_allowed_usergroups and !in_array($this->user->group, $this->access_allowed_usergroups))
			return $this->webcash->getMsgContent('Вашей группе доступ запрещен');
	}
	
	public function getItemById($id, $all = false, $table = '') {
		$id = (int)$id;
		$table or $table = $this->table_a;
		
		if (!isset($this->data_array[$table][$all])) {
			$this->arrayKeyId($all, $table);
		}
		
		return safe_array_access($this->data_array, $table, $all, $id);
	}
	
	public function arrayKeyId($all = false, $table = '') {
		$table or $table = $this->table_a;
		$key = $all ? 1 : 0;
		
		if (!isset($this->data_array[$table][$key])) {
			$cache_key = $this->getCacheKey('data_array');
			
			if (!$this->cacheEnabled() or !$this->data_array = $this->helper->getCache($cache_key, 0, true)) {//nocache
				$rows = $this->db->select("SELECT * FROM {$table}".($all ? "" : " WHERE state = 1").$this->getItemsOrderBy());
				
				if ($rows) {
					foreach ($rows as $v) {
						$this->data_array[$table][$key][$v['id']] = $v;
					}

					if ($this->cacheEnabled()) {
						$this->helper->putCache($cache_key, $this->data_array, true);
					}
				} else {
					$this->data_array[$table][$key] = array();
				}
			}
		}
		
		return safe_array_access($this->data_array, $table, $key);
	}
	
	public function getItemsOrderBy() {
		return " ORDER BY ".(defined('static::ITEMS_SORTING') ? static::ITEMS_SORTING : "id");
	}
	
	public function cleanDataArrayCache() {
		if ($this->cacheEnabled()) {
			$cache_key = $this->getCacheKey('data_array');
			return $this->helper->cleanCache($cache_key);
		}
	}
	
	public function cacheEnabled() {
		return $this->config->cache_on and ($this->cache_on or (!isset($this->cfg['cache_on']) and !isset($this->cache_on)));
	}
	
	public function getCacheKey($id = '') {//ключ кэша
		return $this->alias.'_'.md5($this->alias.$id);
	}
	
	public function toggleState($id, $state = 1, $table = '') {
		$table or $table = $this->table_a;
		$id = (int)$id;
		if ($this->db->query("UPDATE {$table} SET state = '{$state}' WHERE id = '{$id}' LIMIT 1")) {
			$this->cleanDataArrayCache();
			return true;
		}
	}
	
	public function addItem($source_array = array(), $table = '', $html_special_chars = false, $ajax_to_win1251 = false) {
		$source_array or $source_array = $_POST;

		$table or $table = $this->table_a;
		
		if (!empty($source_array)) {
			$source_array = $this->helper->fixMissedElements(safe_array_access($source_array, 'fix_missed_integer'), $source_array, 0);
			$source_array = $this->helper->fixMissedElements(safe_array_access($source_array, 'fix_missed_array'), $source_array, array());
			
			if ($data = safe_array_access($source_array, 'data')) {
				$sql_part = $this->db->prepareSqlPart($data, $html_special_chars, $ajax_to_win1251);
				
				if ($id = $this->db->query("INSERT IGNORE INTO {$table} SET {$sql_part}")) {
					$this->cleanDataArrayCache();
					return $id;
				}
			}
		}
		
		$this->webcash->exitMsg('Не указаны необходимые данные');
	}
	
	public function updateItem($source_array = array(), $table = '', $html_special_chars = false, $ajax_to_win1251 = true) {
		$source_array or $source_array = $_POST;

		$table or $table = $this->table_a;
		
		if (!empty($source_array['id'])) {
			$source_array = $this->helper->fixMissedElements(safe_array_access($source_array, 'fix_missed_integer'), $source_array, 0);
			$source_array = $this->helper->fixMissedElements(safe_array_access($source_array, 'fix_missed_array'), $source_array, '');
			
			if ($data = safe_array_access($source_array, 'data')) {
				$sql_part = $this->db->prepareSqlPart($data, $html_special_chars, $ajax_to_win1251);
				
				if ($this->db->query("UPDATE {$table} SET {$sql_part} WHERE id = '{$source_array['id']}' LIMIT 1")) {
					$this->cleanDataArrayCache();
					return true;
				} else {
					$this->helper->showMsgError('Нет изменившихся данных');
				}
			}
		}
		
		$this->helper->showMsgError('Не указаны необходимые данные');
		
		return false;
	}

	public function deleteItem($id, $table = '') {
		if (!empty($id)) {
			$table or $table = $this->table_a;
			$id = (int)$id;
			if ($this->adminpanel->deleteRecordById($id, $table)) {
				$this->cleanDataArrayCache();
				return true;
			}
		}
		
		return false;
	}

	public function existsCheckedItems() {
		if (!POST('selected_items')) {
			$this->helper->showMsgError('Нет отмеченных записей');
		}
		
		if (!POST('selected_action')) {
			$this->helper->showMsgError('Выберите действие из выпадающего списка');
		}
		
		return true;
	}
	
	public function renderSettingsPanel() {
		$addon_alias = $this->alias;
		
		$filepath = $this->getPath().'settings_adm.dat.php';
		
		if (!file_exists($filepath)) {
			require $this->getPath().$addon_alias.'.php';
		}
		
		
		if (file_exists($filepath)) {
			$addon_sett = unserialize(file_get_contents($filepath));
			$addon_sett->readSettingsFromFile(false, true);
			
			$filepath = $this->getPath().'admin/'.$addon_alias.'.php';
			
			if (file_exists($filepath)) {
				require_once $filepath;
			}
			
			$filepath = $this->getPath().'admin/'.$addon_alias.'.tmpl.php';
			$addon_tmpl_exists = file_exists($filepath);
			
			
			$admin_sett = $this->adminsettings->getAllSettings();
			
			if ($addon_tmpl_exists) {
				$this->adminsettings->setDefaultValue($admin_sett, 'i_'.$addon_alias.'_accordion_1', 1);
			}
			
			ob_start();
			require $this->webcash->module_path.'admin/addonsettings.tmpl.php';
			$html = ob_get_clean();
			
			return $html;
		} else {
			echo __('Нет файла конфигурации дополнения. Перейти на <a href="'.$this->webcash->site_url.'">главную страницу</a> сайта.');
			exit;
		}
	}
	
	public function makeAddonLinkedPart($name, $possible = 1) {
		$params = array(
			'name' => $name,
			'value' => $this->{$name},
			'possible' => $possible,
		);
		
		return $this->adminpanel->makeLinkedPartArray($params);
	}
	
	public function getAdminInstance() {
		if (is_null($this->admin_instance)) {
			$alias = 'admin_'.$this->alias;
			$this->admin_instance = $this->{$alias};
			
			if (!$this->admin_instance or !is_object($this->admin_instance)) {
				trigger_error(sprintf('Объект не существует для этого псевдонима: %s', $alias), E_USER_ERROR);
			}
		}
		
		return $this->admin_instance;
	}

}