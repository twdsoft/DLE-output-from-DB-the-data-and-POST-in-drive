<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

class Paginator extends Application
{
	const BASE_SEPARATOR_ON = true;
	
	const BASE_SEPARATOR = 1;
	const BASE_CURRENT = 2;
	const BASE_DEFAULT = 3;
	
	protected $items_count;
	protected $items_total;
	protected $num_pages;
	protected $limit;
	protected $default_ipp;
	protected $nonsef = true;//если true - номер страницы будет в виде обычного GET параметра
	protected $mid_range = 7;
	protected $custom_offset;
	protected $low;
	protected $not_display_first = true;
	protected $has_trailing_slash = true;
	protected $current_page = 1;
	protected $querystring;
	
	private $items_perpage;
	private $high;
	private $custom_ipp = array();
	private $return = array();
	private $in_admincp;
	
	public function __construct($in_admincp = null) {
		if (!is_null($in_admincp))
			$this->in_admincp = $in_admincp;
		else
			$this->in_admincp = defined('IN_ADMINPANEL');
		
		$this->items_perpage = empty($_COOKIE['ipp']) ? $this->default_ipp : (int)$_COOKIE['ipp'];
		
		$this->return['pages'] = $this->in_admincp ? '' : array();
	}
	
	public function buildURI($pg) {
		if ($this->in_admincp or $this->nonsef) {
			if ($this->not_display_first and $pg == 1)
				return $_SERVER['SCRIPT_NAME'].($this->querystring ? '?' : '').$this->querystring;
			else
				return $_SERVER['SCRIPT_NAME'].'?'.$this->querystring.($this->querystring ? '&amp;' : '').'pg='.$pg;
		} else {
			if ($this->not_display_first and $pg == 1)
				return rtrim($this->webcash->site_url_ws.$this->querystring, '/').($this->has_trailing_slash ? '/' : '');
			else
				return rtrim($this->webcash->site_url_ws.$this->querystring, '/').'/'.$this->config->page_preword.'/'.$pg.'/';
		}
		
		
		if (isset($_POST)) {
			return $_SERVER['SCRIPT_NAME']."?pg=".$pg.$this->querystring;
		}
	}
	
	public function paginate() {
		if (!is_numeric($this->items_perpage) or $this->items_perpage <= 0) {
			$this->items_perpage = $this->default_ipp;
		}
		
		if ($this->custom_ipp and $this->custom_ipp['val'] > $this->items_perpage) {
			unset($this->custom_ipp);
		}

		if ($this->custom_ipp) {
			$this->num_pages = ceil(($this->items_total - $this->custom_ipp['val']) / $this->items_perpage) + 1;

			if ($this->custom_ipp['page'] > $this->num_pages) {//указана страница с номером большим максимально возможного
				unset($this->custom_ipp);
				$this->num_pages = ceil($this->items_total / $this->items_perpage);
			}
		} else {
			$this->num_pages = ceil($this->items_total / $this->items_perpage);
		}
		
		
		$this->current_page = intval(safe_array_access($_GET, 'pg'));
		
		if ($this->current_page < 1) {
			$this->current_page = 1;
		} elseif ($this->current_page > $this->num_pages) {
			$this->items_total = 0;
			$this->limit = 'LIMIT 0';
			return false;
		}

		$prev_page = $this->current_page - 1;
		$next_page = $this->current_page + 1;

		$this->querystring = '';
	

		if ($this->in_admincp or $this->nonsef) {
			if (strpos($_SERVER['QUERY_STRING'], '=') !== false) {
				$arr = array();
				$args = explode('&', $_SERVER['QUERY_STRING']);
				
				foreach ($args as $arg) {
				
					$keyval = explode('=', $arg);
					if ($keyval[0] != 'pg') {
						$arr[] = $this->helper->htmlspecialchars($arg);
					}
				}

				$this->querystring = implode('&amp;', $arr);
			}
		} else {
			$this->querystring = preg_replace('#(/'.$this->config->page_preword.'/[\d]+/)#', '', safe_array_access($_SERVER, 'REQUEST_URI'));
		}
		

		if (isset($_POST)) {
			foreach ($_POST as $key => $val) {
			
				if ($key != 'pg') {
					$this->querystring .= "&amp;{$key}=".$this->helper->htmlspecialchars($val);
				}
			}
		}


		if ($this->num_pages > 1) {
			if ($this->in_admincp) {
				if ($this->current_page != 1 and $this->items_total >= $this->default_ipp)
					$this->return['prev'] = '<li class="prev"><a href="'.$this->buildURI($prev_page).'">'.__('Назад').'</a></li>';
				else
					$this->return['prev'] = '<li class="prev disabled"><a href="#">&lt; '.__('Назад').'</a></li>';
			} else {
				if ($this->current_page != 1 and $this->items_total >= $this->default_ipp)
					$this->return['prev'] = '<a href="'.$this->buildURI($prev_page).'" title="'.__('Предыдущая страница').'">$1</a>';
				else
					$this->return['prev'] = '<span>$1</span>';
			}
			
			$this->start_range = $this->current_page - floor($this->mid_range / 2);
			$this->end_range = $this->current_page + floor($this->mid_range / 2);
			
			if ($this->start_range <= 0) {
				$this->end_range += abs($this->start_range) + 1;
				$this->start_range = 1;
			}
			
			if ($this->end_range > $this->num_pages) {
				$this->start_range -= $this->end_range - $this->num_pages;
				$this->end_range = $this->num_pages;
			}
			
			$this->range = range($this->start_range, $this->end_range);

			
			for ($i = 1; $i <= $this->num_pages; $i++) {
				if ($this->range[0] > 2 and $i == $this->range[0]) {
					if ($this->in_admincp)
						$this->return['pages'] .= '<li><a href="javascript:;">...</a></li>';
					elseif (self::BASE_SEPARATOR_ON)
						$this->return['pages'][] = array('type' => self::BASE_SEPARATOR);
				}
				
				if ($i == 1 or $i == $this->num_pages or in_array($i, $this->range)) {
					$title = sprintf(__('Перейти к %d из %d'), $i, $this->num_pages);
					
					if ($this->in_admincp) {
						if ($i == $this->current_page)
							$this->return['pages'] .= '<li class="active"><a href="#" title="'.$title.'">'.$i.'</a></li>';
						else
							$this->return['pages'] .= '<li><a class="number" title="'.$title.'" href="'.$this->buildURI($i).'">'.$i.'</a></li>';
					} else {
						if ($i == $this->current_page) {
							$this->return['pages'][] = array('type' => self::BASE_CURRENT, 'number' => $i);
						} else {
							$this->return['pages'][] = array(
								'type' => self::BASE_DEFAULT,
								'number' => $i,
								'href' => $this->buildURI($i),
								'title' => $title,
							);
						}
					}
				}
				
				if ($this->range[$this->mid_range - 1] < $this->num_pages - 1 and $i == $this->range[$this->mid_range - 1]) {
					if ($this->in_admincp)
						$this->return['pages'] .= '<li><a href="javascript:;">...</a></li>';
					elseif (self::BASE_SEPARATOR_ON)
						$this->return['pages'][] = array('type' => self::BASE_SEPARATOR);
				}
			}
			
			if ($this->in_admincp) {
				if ($this->current_page != $this->num_pages and $this->items_total >= $this->default_ipp)
					$this->return['next'] = '<li class="next"><a href="'.$this->buildURI($next_page).'">'.__('Вперед').'</a></li>';
				else
					$this->return['next'] = '<li class="next disabled"><a href="#">'.__('Вперед').' &gt; </a></li>';
			} else {
				if ($this->current_page != $this->num_pages and $this->items_total >= $this->default_ipp)
					$this->return['next'] = '<a href="'.$this->buildURI($next_page).'" title="'.__('Следующая страница').'">$1</a>';
				else
					$this->return['next'] = '<span>$1</span>';
			}
		}

		
		if ($this->custom_ipp and $this->custom_ipp['page'] < $this->current_page) {
			$this->low = ($this->current_page - 1) * $this->items_perpage - ($this->items_perpage - $this->custom_ipp['val']);
		} elseif ($this->custom_offset) {
			$this->low = $this->custom_offset;
		} else {
			$this->low = ($this->current_page - 1) * $this->items_perpage;
		}
		
		
		$this->high = $this->current_page * $this->items_perpage - 1;
		
		if ($this->custom_ipp and $this->custom_ipp['page'] == $this->current_page) {
			$this->limit = "LIMIT {$this->low}, {$this->custom_ipp['val']}";
		} else {
			$this->limit = "LIMIT {$this->low}, {$this->items_perpage}";
		}
	}//END paginate()
	
	public function getServiceInfo() {
		if ($this->items_total > $this->default_ipp) {
			$this->return['current_page'] = $this->current_page;
			$this->return['num_pages'] = $this->num_pages;
			$this->return['items_total'] = $this->items_total;
		} else {
			$this->return['current_page'] = 1;
			$this->return['num_pages'] = 1;
			$this->return['pages'] = false;
			$this->return['prev'] = ''; 
			$this->return['next'] = '';
		}
		
		if ($this->items_count) {
			$this->return['info'] = sprintf(__('От %d по %d из %d'), ($this->low + 1), ($this->low + $this->items_count), $this->items_total);
		}
		
		$this->return['index'] = $this->low + 1;			
		$this->return['items_perpage'] = $this->items_perpage;
		$this->return['default_ipp'] = $this->default_ipp;

		return $this->return;
	}
	
	public function renderPaginationHtml($tpl_file = 'navigation.tpl') {
		if ($data = $this->getServiceInfo() and $data['num_pages'] > 1) {
			if ($this->in_admincp) {
				return '
				<div class="clearfix mb-20 mt-20 ml-20 mr-20">
					<div class="pull-left">
						<div class="pagination_info">'.$data['info'].'</div>
					</div>
					<div class="pull-right">
						<ul class="pagination pagination-sm">
							'.$data['prev'].$data['pages'].$data['next'].'
						</ul>
					</div>
				</div>';
			}
			
			
			$tpl = $this->webcash->getTplInstance();
			$str = '';
			foreach ($data['pages'] as $node_array) {
				$str .= $this->makeNodeHtml($node_array);
			}
			
			$tpl->load_template($tpl_file);
			$tpl->set('{pages}', $str);
			
			$tpl->set_block('#\[prev-link\](.*)\[/prev-link\]#Usi', $data['prev']);
			$tpl->set_block('#\[next-link\](.*)\[/next-link\]#Usi', $data['next']);
			
			$tpl->compile('pagination');
			
			return $tpl->result['pagination'];
		}
	}
	
	private function makeNodeHtml(array $node_array) {
		switch ($node_array['type']) {
			case self::BASE_SEPARATOR:
				return '<span> ... </span>';
			case self::BASE_CURRENT:
				return '<span>'.$node_array['number'].'</span>';
			case self::BASE_DEFAULT:
				return '<a href="'.$node_array['href'].'" title="'.$node_array['title'].'">'.$node_array['number'].'</a>';
		}
	}
}