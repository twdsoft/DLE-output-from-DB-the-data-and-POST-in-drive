<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

class Helper extends Application
{
	const SET_AJAX_CONTENT = 1;
	const APPEND_AJAX_CONTENT = 2;

	protected $current_url = null;
	
	private $ajax_result_vars = array();

	public function getJsOptions() {
		$js_options = array(
			'SITE_AJAX_URL' => $this->webcash->site_ajax_url,
			'SITE_URL' => $this->webcash->site_url,
			'DEBUG_ON' => (bool)$this->config->debug_on,
			'USER_HASH' => $this->user->nonce,
			'CHARSET' => $this->dle->config['charset'],
			'IN_ADMINPANEL' => defined('IN_ADMINPANEL'),
			'NDGROWL_CLOSER_CAPTION' => lang('Закрыть все'),
		);
		
		if (defined('IN_ADMINPANEL'))
			$js_options['ADMIN_URL'] = $this->webcash->module_admin_url;
		
		return json_encode($js_options);
	}
	
	public function sendAjaxContent($selector, $content, $mode = self::SET_AJAX_CONTENT) {
		$arr = array(
			'response' => $content,
		);
		
		if ($mode == self::SET_AJAX_CONTENT)
			$arr['container'] = $selector;
		else
			$arr['append_container'] = $selector;

		$this->printAjaxResult($arr);
	}
	
	public function showMsgOk($text, $title = 'Информация', $redirect = '') {
		$this->showMsgOkNotTranslate(__($text, false), __($title, false), $redirect);
	}
	
	public function showMsgOkNotTranslate($text, $title = 'Информация', $redirect = '') {
		$arr = array(
			'status' => 'ok',
			'msg' => array(
				'title' => $title,
				'text' => $text,
			),
			'redirect' => $redirect,
		);

		$this->printAjaxResult($arr);
	}
	
	public function showMsgError($text, $title = 'Ошибка', $redirect = '') {
		$this->showMsgErrorNotTranslate(__($text, false), __($title, false), $redirect);
	}
	
	public function showMsgErrorNotTranslate($text, $title = 'Ошибка', $redirect = '') {
		$arr = array(
			'status' => 'error',
			'msg' => array(
				'title' => $title,
				'text' => $text,
			),
			'redirect' => $redirect,
		);

		$this->printAjaxResult($arr);
	}
	
	public function printAjaxResult($data = array()) {
		$data = array_merge($data, $this->ajax_result_vars);
		
		if (!empty($data['status']) and !empty($data['msg'])) {
			if (empty($data['sticky_options'])) {
				$data['sticky_options'] = array();
			}
			
			if (!empty($data['redirect'])) {
				$data['sticky_options'] += array('autoclose' => false);
			}
			
			$data['sticky_options'] += array('autoclose' => is_numeric($this->config->sticky_autoclose) ? $this->config->sticky_autoclose : 5000);
		}
		
		echo json_encode($data, JSON_UNESCAPED_UNICODE);
		exit;
	}
	
	public function assignAjaxResultVar($key, $value) {
		$this->ajax_result_vars[$key] = $value;
	}
	
	public function fixMissedElements($missed_elements, $post, $val = 0) {
		$output = $post;
		
		if ($missed_elements) {
			foreach ($missed_elements as $key => $value) {
				$str = str_replace(array('][', '[', ']'), ',', $value);
				$str = trim($str, ',');
				$keys_arr = explode(',', $str);

				$reference =& $output;
				foreach ($keys_arr as $key) {

					if (!$reference or !array_key_exists($key, $reference)) {
						$reference[$key] = array();
					}
					
					$reference = &$reference[$key];
				}
				
				$reference = $val;
				unset($reference);
			}

			$output = $this->arrayMergeRecursiveEx($output, $post);
		}

		return $output;
	}

	public function arrayMergeRecursiveEx(array $array1, array $array2, $exclude_keys = array()) {
		$merged = $array1;

		foreach ($array2 as $key => $value) {
			if (in_array($key, $exclude_keys)) {
				$merged[$key] = $value;
				continue;
			}
			
			if (is_array($value) and isset($merged[$key]) and is_array($merged[$key])) {
				$merged[$key] = $this->arrayMergeRecursiveEx($merged[$key], $value, $exclude_keys);
			} elseif (is_numeric($key)) {
				if (!in_array($value, $merged))
					$merged[] = $value;
			} else
				$merged[$key] = $value;
		}

		return $merged;
	}

	public function arrayDiffRecursive($array1, $array2) {
		$result = array();

		foreach ($array1 as $key => $value) {
			if (array_key_exists($key, $array2)) {
				if (is_array($value)) {
					$temp_result = $this->arrayDiffRecursive($value, $array2[$key]);
					if (count($temp_result)) {
						$result[$key] = $temp_result;
					}
				} else {
					if ($value != $array2[$key]) {
						$result[$key] = $value;
					}
				}
			} else {
				$result[$key] = $value;
			}
		}
		return $result;
	}
	
	public function writeArrayToFile($filepath, $config_array) {
		if (is_writeable($filepath)) {
			$str = var_export($config_array, true);
			$str = str_replace('  ', "\t", $str);
			$str = trim(preg_replace('#\s*array\s+\(#U', ' array(', $str));
			$str = '<?php'.PHP_EOL.'$webcash_config = '.$str.';'.PHP_EOL.'?>';
			return file_put_contents($filepath, $str);
		}
	}
	
	public function printRequiredHtml($title, $name) {
		return '<input type="hidden" name="required_fields[]" value="'.$name.'" /><input type="hidden" name="required_fields_titles['.base64_encode($name).']" value="'.$title.'" />';
	}
	
	public function emptyRequiredFields($source_array = array()) {
		if ($required_fields = safe_array_access($source_array, 'required_fields')) {
			$errors = array();
			
			foreach ($required_fields as $key => $value) {
				$str = str_replace(array('][', '[', ']'), ',', $value);
				$str = trim($str, ',');
				$keys_arr = explode(',', $str);
				
				$arr = $source_array;

				foreach ($keys_arr as $key) {
					if ($arr and is_array($arr) and !empty($arr[$key])) {
						$arr = $arr[$key];
					} else {
						$errors[] = lang('Пустое поле').' &laquo;'.safe_array_access($source_array, 'required_fields_titles', base64_encode($value)).'&raquo;';
					}
				}
			}
			
			if ($errors) {
				$this->showMsgErrorNotTranslate(implode('<br>', $errors));
			}
		}
	}
	
	public function mkdir($dir) {
		if (!file_exists($dir)) {
			if (!mkdir($dir, 0755, true)) {
				trigger_error('No permission to create dir: ['.$dir.']', E_USER_ERROR);
			}
		}
		
		return $dir;
	}

	public function rmdir($dir, $delete_self = true, $exclude = '') {
		if (is_dir($dir)) {
			$entries = scandir($dir);
			
			foreach ($entries as $entry) {
				if ($entry != '.' and $entry != '..') {
					if (is_dir($dir.'/'.$entry)) {
						$this->rmdir($dir.'/'.$entry);
					} else {
						if ($exclude and $exclude == $entry) {
							$delete_self = false;//anyway, empty folder can't delete
						} else {
							$this->unlink($dir.'/'.$entry, false);
						}
					}
				}
			}

			return $delete_self ? rmdir($dir) : true;
		}
	}

	public function unlink($path, $verify_exists = true) {
		if (!$verify_exists or is_file($path)) {
			if (!unlink($path)) {
				trigger_error('No permission to delete: ['.$path.']', E_USER_ERROR);
			}
			
			return true;
		}
		
		return false;
	}

	public function htmlspecialchars($text) {
		return htmlspecialchars($text, ENT_QUOTES, $this->dle->config['charset']);
	}
	
	public function getCacheKey($id = '') {//ключ кэша
		return 'webcash_'.md5('webcash_'.$id);
	}
	
	public function getCache($cache_key, $expired_seconds = 0, $is_array = false) {
		$expired_seconds or $expired_seconds = 345600;
		$result = false;
		
		$filepath = $this->webcash->cache_path.$cache_key.'.php';
		if (file_exists($filepath)) {
			if (time() > filemtime($filepath) + $expired_seconds) {
				$this->unlink($filepath, false);
			} else {
				$result = file_get_contents($filepath);
				
				if ($is_array) {
					$result = unserialize($result);
				}
			}
		}

		return $result;
	}

	public function putCache($cache_key, $data, $is_array = false) {
		$filepath = $this->mkdir($this->webcash->cache_path).$cache_key.'.php';
		if ($is_array) {
			$data = serialize($data);
		}
		
		return file_put_contents($filepath, $data);
	}
	
	public function cleanCache($cache_key) {
		$filepath = $this->webcash->cache_path.$cache_key.'.php';
		return $this->unlink($filepath);
	}
	
	public function fixLongWords($text, $max_length = 15, $custom_breaker = '') {
		$max_length = (int)min(65535, $max_length);
		
		if ($max_length <= 0) {
			return $text;
		}

		if ($max_length > 5) {
			ob_start();
			if ($custom_breaker == '') {
				if (!empty($_SERVER['HTTP_USER_AGENT']) and strpos($_SERVER['HTTP_USER_AGENT'], 'Opera') !== false) {
					$breaker = '<span style="margin: 0 -0.65ex 0 -1px;padding:0;"> </span>';
				} else {
					$breaker = '<span style="font-size:0;padding:0;margin:0;"> </span>';
				}
			} else {
				$breaker = $custom_breaker;
			}

			$plain_text = $text;

			$plain_text = preg_replace('#([\w\.\-]+)@(\w+[\w\.\-]*\.\w{2,4})#iu', '', $plain_text);
			$plain_text = preg_replace('#<br\s?/?>#isu', '', $plain_text);
			$plain_text = preg_replace('#<img[^\>]+/>#isu', '', $plain_text);
			$plain_text = preg_replace('#<a.*?>(.*?)</a>#isu', '', $plain_text);
			$plain_text = preg_replace('#<span class="quote">(.*?)</span>#is', '', $plain_text);
			$plain_text = preg_replace('#<p.*?>(.*?)</p>#is', '', $plain_text);
			$plain_text = preg_replace('#<strong.*?>(.*?)</strong>#is', '', $plain_text);
			$plain_text = preg_replace('#<span[^\>]*?>(.*?)</span>#is', '$1', $plain_text);
			$plain_text = preg_replace('#<pre.*?>(.*?)</pre>#Usiu', '', $plain_text);
			$plain_text = preg_replace('#<blockquote.*?>(.*?)</blockquote>#Usiu', '$1 ', $plain_text);
			$plain_text = preg_replace('#<code.*?>(.*?)</code>#Usiu', '', $plain_text);
			$plain_text = preg_replace('#<embed.*?>(.*?)</embed>#isu', '', $plain_text);
			$plain_text = preg_replace('#<object.*?>(.*?)</object>#isu', '', $plain_text);
			$plain_text = preg_replace('#(^|\s|\>|\()((http://|https://|news://|ftp://|www.)\w+[^\s\[\]\<\>\"\'\)]+)#iu', '', $plain_text);
			$plain_text = preg_replace('#<(b|strong|i|em|u|s|del|sup|sub|li)>(.*?)</(b|strong|i|em|u|s|del|sup|sub|li)>#isu', '$2 ', $plain_text);

			$words = explode(' ', $plain_text);

			foreach ($words as $word) {
				if (mb_strlen($word) > $max_length) {
					$text = str_replace($word, $this->wordwrap($word, $max_length, $breaker, true), $text);
				}
			}
			
			ob_end_clean();
		}
		return $text;
	}
	
	public function wordwrap($str, $width, $break, $cut = false) {
		if (!$cut) {
			$regex = '#^(?:[\x00-\x7F]|[\xC0-\xFF][\x80-\xBF]+){'.$width.',}\b#U';
		} else {
			$regex = '#^(?:[\x00-\x7F]|[\xC0-\xFF][\x80-\xBF]+){'.$width.'}#';
		}

		$i = 1;
		$j = ceil(mb_strlen($str) / $width);
		$return = '';

		while ($i < $j) {
			preg_match($regex, $str, $matches);
			$return .= $matches[0].$break;
			$str = mb_substr($str, mb_strlen($matches[0]));
			$i++;
		}
		
		return $return.$str;
	}
	
	public function truncateText($text, $maxchar = 70, $maxwords = 0, $ellipsis = true, $notag = true, $sep = ' ') {
		if (!$text or (!$maxwords and !$maxchar)) {
			return $text;
		}
		
		if ($notag) {
			$text = strip_tags($text);
		}

		$text = trim($text);
		
		$cutted = false;

		if ($maxchar) {
			$char = mb_strlen($text, $this->dle->config['charset']);
			
			if ($char > $maxchar) {
				$text = mb_substr($text, 0, $maxchar, $this->dle->config['charset']);
				$i = mb_strlen(strrchr($text, $sep), $this->dle->config['charset']);
				$text = mb_substr($text, 0, mb_strlen($text, $this->dle->config['charset']) - $i, $this->dle->config['charset']);
				$cutted = true;
			}
		} elseif ($maxwords) {
			$words = explode($sep, $text);
			if (count($words) > $maxwords) {
				$text = join($sep, array_slice($words, 0, $maxwords));
				$cutted = true;
			}
		}
		
		
		$text = trim($text, ',-');
		
		if ($cutted and $ellipsis)
			$text .= '..';
		
		return $text;
	}
	
	public function truncateHtml($text, $maxchar = 70, $ellipsis = true) {
		$patterns = array(
			'#<!--dle_spoiler(.+)<!--spoiler_text-->#Usi',
			'#<!--spoiler_text_end-->(.+)<!--/dle_spoiler-->#Usi',
			'#\[attachment=(.*)\]#Usi',
			'#\[hide(.*)\](.+)\[/hide\]#Usi',
		);
		$text = preg_replace($patterns, '', $text);

		$text = str_replace('><', '> <', $text);
		$text = strip_tags($text, '<br>');

		$search = array('<br />', '<br>', "\n", "\r");
		$replace = array(' ', ' ', ' ', '');
		$text = trim(str_replace($search, $replace, $text));
		$text = preg_replace('#\s+#', ' ', $text);

		$cutted = false;

		if ($maxchar) {
			$char = mb_strlen($text, $this->dle->config['charset']);

			if ($char > $maxchar) {
				$text = mb_substr($text, 0, $maxchar, $this->dle->config['charset']);
				$i = mb_strlen(strrchr($text, ' '), $this->dle->config['charset']);
				$text = mb_substr($text, 0, mb_strlen($text) - $i, $this->dle->config['charset']);
				$cutted = true;
			}
		}

		$text = trim($text, ',-');

		if ($cutted and $ellipsis)
			$text .= '..';

		return $text;
	}
	
	public function toggleTagContent($tpl, $tag_name, $show) {
		if ($show) {
			$this->showTagContent($tpl, $tag_name);
		} else {
			$this->hideTagContent($tpl, $tag_name);
		}
		
		return $show;
	}
	
	public function showTagContent($tpl, $tag_name) {
		$tpl->set('['.$tag_name.']', '');
		$tpl->set('[/'.$tag_name.']', '');
	}
	
	public function hideTagContent($tpl, $tag_name) {
		$tpl->set_block('#\['.$tag_name.'\].*\[/'.$tag_name.'\]#Usi', '');
	}
	
	public function lang($text) {
		if ($text and $language = $this->config->language) {
			$filepath = $this->webcash->module_path.'language/'.$language.'/language.php';
			
			require $filepath;
			
			if (isset($webcash_config[$text])) {
				return $webcash_config[$text];
			} elseif (!in_array($text, $webcash_config)) {
				$webcash_config[$text] = '';
				$this->writeArrayToFile($filepath, $webcash_config);
				return '';
			}
		}
	}
	
	public function isWin1251Charset() {
		return $this->dle->config['charset'] != 'utf-8';
	}
	
	public function isVersionLess($version) {//true - если версии меньше указанной
		return version_compare($this->dle->config['version_id'], $version, '<');
	}
	
	public function isVersionLarger($version) {//true - если версии больше указанной
		return version_compare($this->dle->config['version_id'], $version, '>');
	}
	
	public function isAjax() {
		return defined('IS_AJAX') and IS_AJAX;
	}
	
	public function getCurrentUrl() {
		if (is_null($this->current_url)) {
			$str = $this->getRequestUri();
			
			$this->current_url = $this->webcash->site_url_ws.$str;
		}
		
		return $this->current_url;
	}
	
	public function getRequestUri() {
		$str = $this->htmlspecialchars($_SERVER['REQUEST_URI']);
		$str = str_replace('&amp;', '&', $str);
		//$str = $this->removeUtmPart($str);
		
		if ($this->webcash->site_folder) {
			$length = strlen($this->webcash->site_folder);
			if (substr($str, 0, $length) == $this->webcash->site_folder) {
				$str = substr($str, $length);
			}
		}
		
		return $str;
	}
	
	public function sendEmailToAdmin($text) {
		$this->sendEmail($text);
	}
	
	public function sendEmail($text, $email = '', $subject = '') {
		require_once WebCash::checkPlugins(ENGINE_DIR.'/classes/mail.class.php');
		
		$mail = new \dle_mail($this->dle->config, true);		
		
		$email or $email = $this->dle->config['admin_mail'];
		$subject or $subject = __('Извещение');
		
		$mail->send($email, $subject, $text);
		
		if ($mail->send_error) {
			echo $mail->smtp_msg;
		}
	}
}