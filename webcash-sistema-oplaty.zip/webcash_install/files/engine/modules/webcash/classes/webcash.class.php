<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

class WebCash extends Application
{
	const UPDATES_API_URL = 'https://new-dev.ru/updates_api.php?product_id=27&action=checknewmodule';

	const PAY_SOURCE_GATEWAY = 1;
	const PAY_SOURCE_BALANCE = 2;
	
	const TWIG_CACHE_FOLDER = 'twig_cache';
	
	const DEBUG = false;
	const DEBUG_SETTINGS = false;
	
	protected $gateway_invoices_table = 'webcash_gateway_invoices';
	protected $gateway_payments_table = 'webcash_gateway_payments';
	protected $balance_transactions_table = 'webcash_balance_transactions';
	protected $site_url = '';
	protected $module_url = '';
	protected $rel_module_url = '';
	protected $module_path = '';
	protected $admin_url = '';
	protected $module_admin_url = '';
	protected $cache_path = '';
	protected $gateways = array();
	protected $plugins = array();
	protected $default_gateway = '';
	protected $default_item = '';
	protected $main_index_topmenu = array();
	protected $constants = array(
		'pay_sources' => array(
			self::PAY_SOURCE_GATEWAY => array(
				'title' => 'Платежный шлюз',
				'short_title' => 'шлюз',
				'tab' => Plugins_ListTransactions::PAYMENTS_TAB,
			),
			self::PAY_SOURCE_BALANCE => array(
				'title' => 'Оплата с баланса',
				'short_title' => 'баланс',
				'tab' => Plugins_ListTransactions::BALANCE_TRANSACTIONS_TAB,
			),
		),
	);
	
	private $current_date = null;
	private static $instance;
	
    public static function instance() {
        if (!isset(self::$instance)) {
            self::$instance = new self();
        }
        return self::$instance;
    }
	
	public function __construct() {
		
		$this->cache_path = ENGINE_DIR.'/cache/webcash/';
		
		$arr = preg_split('#(/\w+\.php|/admin/|/engine/)#', $_SERVER['SCRIPT_NAME']);
		$this->site_folder = reset($arr);
		
		$this->site_url = $this->getSiteUrl();
		$this->site_url_ws = rtrim($this->site_url, '/');
		$this->rel_module_url = $this->site_folder.'/engine/modules/webcash/';
		$this->module_url = $this->site_url_ws.$this->rel_module_url;
		$this->module_path = ENGINE_DIR.'/modules/webcash/';
		$this->admin_url = $this->site_url.$this->dle->config['admin_path'];
		$this->module_admin_url = $this->admin_url.'?mod=webcash';
		$this->site_ajax_url = $this->module_url.'site/ajax.php';
		
		
		$this->gateway_invoices_table = PREFIX.'_'.$this->gateway_invoices_table;
		$this->gateway_payments_table = PREFIX.'_'.$this->gateway_payments_table;
		$this->balance_transactions_table = PREFIX.'_'.$this->balance_transactions_table;
	}
	
	public static function checkPlugins($filepath) {
		if (class_exists('\DLEPlugins', false))
			return \DLEPlugins::Check($filepath);
		
		return $filepath;
	}
	
	public function getGateways($all = false) {
		if (!$this->gateways)
			$this->initGateways();
		
		$gateways = $this->gateways;
		
		$active_gateways = array_filter($gateways, function ($element) {
			return $element['on'];
		});
		
		if (count($active_gateways) == 1) {
			$str = key($active_gateways);
			
			if (count($active_gateways[$str]['items']) == 1) {
				$this->default_gateway = $str;
				$this->default_item = key($active_gateways[$str]['items']);
			}
		}
		
		return $all ? $gateways : $active_gateways;
	}
	
	public function initGateways() {
		if ($arr = $this->config->getSection('GATEWAYS')) {
			foreach ($arr as $gw_alias) {
			
				$instance = $this->getAddonInstanceByAlias($gw_alias);
				
				if (method_exists($instance, 'getServiceInfo')) {
					$this->gateways[$gw_alias] = $instance->getServiceInfo();
					$this->gateways[$gw_alias]['on'] = $instance->on;
					$this->gateways[$gw_alias]['site_url'] = safe_array_access($instance->cfg, 'site_url');
					$this->gateways[$gw_alias]['addon_settings_link'] = $instance->renderAddonSettingsLink();
				} else {
					trigger_error(basename(__FILE__).', line: '.__LINE__, E_USER_ERROR);
				}
			}
			
		} else {
			trigger_error(basename(__FILE__).', line: '.__LINE__, E_USER_ERROR);
		}
	}
	
	public function callPluginMethod($plg_alias, $method = '', $check_required_usergroup = true, $show_error = true) {
		if (!$plg_alias)
			return false;
		
		$this->getPlugins();
		
		$instance = $this->getAddonInstanceByAlias($plg_alias);
		
		if ($check_required_usergroup and $instance->required_usergroup and $this->user->group > $instance->required_usergroup)
			return __('Доступ для вашей группы закрыт');
		
		$method or $method = 'renderIndex';
		
		if ($method) {
			if (!method_exists($instance, $method)) {
				if ($str = $instance->getConst('methods_aliases|'.$method)) {
					$method = $str;
				}
			}
		}
		
		if ($method and method_exists($instance, $method)) {
			$numargs = func_num_args();
			$arguments = array();
			
			if ($numargs > 4) {
				$arguments = func_get_args();
				unset($arguments[0], $arguments[1], $arguments[2], $arguments[3]);
			}
			
			return call_user_func_array(array($instance, $method), $arguments);
		}
		
		if ($show_error)
			trigger_error(sprintf('Method not exists: %s', $method), E_USER_ERROR);
	}
	
	public function getPluginProperty($plg_alias, $property) {
		if (!$plg_alias)
			return false;
		
		$this->getPlugins();
		$instance = $this->getAddonInstanceByAlias($plg_alias);
		
		if (isset($instance->cfg[$property]))
			return $instance->cfg[$property];
		elseif (property_exists($instance, $property))
			return $instance->{$property};
	}
	
	public function getPlugins($all = false) {
		if (!$this->plugins)
			$this->initPlugins();
		
		if ($all) {
			$plugins = $this->plugins;
		} else {
			$plugins = array();
			
			foreach ($this->plugins as $row) {
				if ($row['on']) {
					$plugins[$row['alias']] = $row;
				}
			}
		}
		
		return $plugins;
	}
	
	public function initPlugins() {
		if ($arr = $this->config->getSection('PLUGINS')) {
			foreach ($arr as $plg_alias) {
			
				$instance = $this->getAddonInstanceByAlias($plg_alias);
				
				$this->plugins[$plg_alias]['display_name'] = $instance->display_name;
				$this->plugins[$plg_alias]['description'] = $instance->description;
				$this->plugins[$plg_alias]['alias'] = $plg_alias;
				$this->plugins[$plg_alias]['on'] = $instance->on;
				$this->plugins[$plg_alias]['site_url'] = safe_array_access($instance->cfg, 'site_url');
				
				if ($instance->on and method_exists($instance, 'webcashCall')) {
					$instance->webcashCall();
				}
			}
		} else {
			trigger_error(basename(__FILE__).', line: '.__LINE__, E_USER_ERROR);
		}
	}
	
	public function getAddonAdminInstanceByAlias($alias, $read_settings = true) {
		$instance = $this->getAddonInstanceByAlias($alias, $read_settings);
		return $instance->getAdminInstance();
	}
	
	public function getAddonInstanceByAlias($alias, $read_settings = true) {
		$instance = $this->{$alias};
		
		if ($instance and is_object($instance)) {
			if ($read_settings) {
				$instance->readSettingsFromFile(true);
			}
			
			return $instance;
		}
		
		trigger_error(sprintf('Объект не существует для этого псевдонима: %s', $alias), E_USER_ERROR);
	}
	
	public function getClassesConstants() {
		$output_array = array();
		
		if ($classes = $this->config->getSection('CLASSES')) {
			foreach ($classes as $class) {
				if (is_addon_class($class)) {
					$instance = new $class();
					$reflector = new \ReflectionClass($instance);
					
					if ($constants = $reflector->getConstants()) {
						$str = str_replace('WebCash\\', '', $class);
						$output_array[$str] = $constants;
					}
				}
			}
		}
		
		$output_array['WebCash'] = array(
			'PAY_SOURCE_GATEWAY' => self::PAY_SOURCE_GATEWAY,
			'PAY_SOURCE_BALANCE' => self::PAY_SOURCE_BALANCE,
			'DEBUG_SETTINGS' => self::DEBUG_SETTINGS,
		);
		
		$output_array['User'] = array(
			'ADMIN_ID' => User::ADMIN_ID,
			'ADMIN_USERGROUP_ID' => User::ADMIN_USERGROUP_ID,
			'VISITOR_USERGROUP_ID' => User::VISITOR_USERGROUP_ID,
			'GUEST_USERGROUP_ID' => User::GUEST_USERGROUP_ID,
		);
		
		return $output_array;
	}
	
	public function getRowById($table, $id, $fields = '*') {
		return $this->db->selectRow("SELECT {$fields} FROM {$table} WHERE id = ".(int)$id." LIMIT 1");
	}
	
	public function buildPostUrl($row) {
		$row['date'] = strtotime($row['date']);
		$row['category'] = intval($row['category']);

		if ($this->dle->config['allow_alt_url']) {
			if ($this->dle->config['seo_type'] == 1 or $this->dle->config['seo_type'] == 2) {
				if ($row['category'] and $this->dle->config['seo_type'] == 2) {
					$url = $this->site_url.get_url($row['category']).'/'.$row['id'].'-'.$row['alt_name'].'.html';
				} else {
					$url = $this->site_url.$row['id'].'-'.$row['alt_name'].'.html';
				}
			} else {
				$url = $this->site_url.date('Y/m/d/', $row['date']).$row['alt_name'].'.html';
			}
		} else {
			$url = $this->site_url.'index.php?newsid='.$row['id'];
		}

		return $url;
	}
	
	public function summarizeTimestamp($new_time_limit, $time_limit) {
		$diff_seconds = $time_limit - $this->getCurrTimestamp();
		$new_time_limit += $diff_seconds;
		return $new_time_limit;
	}
	
	public function getCurrTimestamp() {
		return strtotime($this->getCurrDate());
	}
	
	public function getCurrDate() {
		$this->current_date or $this->current_date = $this->db->selectCell("SELECT NOW()");
		return $this->current_date;
	}
	
	public function getUsergroupsMultiSelect($name, $selected = null, $exclude_array = array(User::VISITOR_USERGROUP_ID, User::GUEST_USERGROUP_ID)) {
		$usergroups_rows = $selected_array = array();
		
		if ($selected) {
			$selected_array = is_array($selected) ? $selected : explode(',', $selected);
		}
		
		foreach ($this->dle->user_group as $value) {
			if (!$exclude_array or !in_array($value['id'], $exclude_array))
				$usergroups_rows[$value['id']] = $value['group_name'];
		}
		
		$html = '<select data-placeholder="'.__('Выберите...').'" name="'.$name.'" class="usergroups_multiselect" multiple>';

		foreach ($usergroups_rows as $key => $value) {
			$html .= '<option value="'.$key.'"'.(in_array($key, $selected_array) ? ' selected' : '').'>'.$value.'</option>';
		}
		
		$html .= '</select>';
		$html .= '<input type="hidden" name="fix_missed_array[]" value="'.$name.'" />';
		$html .= '<script>$("select.usergroups_multiselect").chosen({allow_single_deselect:true});</script>';
		
		return $html;
	}
	
	public function renderIndex() {
		if ($this->frontendIsEnable()) {
		
			$this->initPlugins();
			
			$action = GET('action') or $action = 'index';
			
			$arr = array('gateway_processing', 'checkout', 'plugin');
			
			switch ($action) {
				case 'gateway_processing': echo $this->checkout->execGatewayProcessing(GET('gw_alias')); exit;
				case 'checkout': $content = $this->checkout->renderCheckoutHtml(); break;
				case 'plugin': $content = $this->callPluginMethod(GET('alias'), GET('subaction')); break;
				default: $content = '';
			}
			
			if ($this->user->isLoggedIn() or $content) {
				$tpl = $this->getTplInstance();
				$tpl->assign('action', $action);
				$tpl->assign('content', $content);
				$tpl->assign('SITEURL', $this->site_url_ws);
				
				$this->appendFrontendHtmlJsCSS();
				
				if ($this->user->isLoggedIn()) {
					$tpl->assign('main_index_topmenu', $this->main_index_topmenu);
					$tpl->assign('user_balance', $this->user->getUserBalance());
				}
				
				$tpl->load_template('/modules/webcash/main_index.tpl');
				
				$tpl->compile('content');
				
				$this->dle->tpl->result['content'] .= $tpl->result['content'];
				
			} else {
				$this->siteMsgError('Раздел доступен только для зарегистрированных пользователей');
			}
			
		} else {
			$this->siteMsgError('Модуль выключен');
		}
	}
	
	public function appendFrontendHtmlJsCSS() {
		$this->js_css->addCSSFile($this->rel_module_url.'site/site.css', true);
		$this->js_css->addCSSFile($this->rel_module_url.'lib/jGrowl/jquery.jgrowl.min.css', true);
		$this->js_css->addCSSFile($this->rel_module_url.'site/lib/fontello/css/fontawesome.css', true);
		$this->js_css->addCSSFile($this->rel_module_url.'site/boot.css', true);
		
		
		$this->js_css->addJsCode('var WEBCASH_OPTIONS = JSON.parse(\''.$this->helper->getJsOptions().'\');', false, false, true);
		
		$this->js_css->addJsFile($this->rel_module_url.'kernel.js', true);
		$this->js_css->addJsFile($this->rel_module_url.'site/site.js', true);
		$this->js_css->addJsFile($this->rel_module_url.'lib/jGrowl/jquery.jgrowl.js', true);
	}
	
	public function frontendIsEnable() {
		if ($this->config->state) {
			if (($this->config->enable_for_all or $this->user->isAdminGroup()) and (!$this->config->test_ip or $this->config->test_ip == $this->user->ip))
				return true;
		}
		
		return false;
	}
	
	public function isPostAuthor($post_id) {
		return $this->user->id == $this->getAuthorIdByPostId($post_id);
	}
	
	public function getAuthorIdByPostId($post_id) {
		return $this->db->selectCell("SELECT user_id FROM ".PREFIX."_post_extras WHERE news_id = '{$post_id}' LIMIT 1");
	}
	
	public function siteMsgError($text, $title = 'Ошибка') {
		msgbox(__($title), __($text));
	}
	
	public function siteMsgOk($text, $title = 'Информация') {
		msgbox(__($title), __($text));
	}

	public function getMsgContent($text, $title = 'Ошибка') {
		return $this->getMsgContentNotTranslateNotConvert(__($text), __($title));
	}
	
	public function getMsgContentNotTranslateNotConvert($text, $title = 'Ошибка') {
		$tpl = $this->getTplInstance();
		$tpl->load_template('info.tpl');
		
		$tpl->set('{title}', $title);
		$tpl->set('{error}', $text);
		
		$tpl->compile('content');
		return $tpl->result['content'];
	}
	
	public function exitMsg($text, $title = 'Ошибка') {
		if ($this->helper->isAjax()) {
			$this->helper->showMsgError($text, $title);
		} else {
			$title = lang($title);
			$text = lang($text);
			show_error_message($title, $text);
		}
	}
	
	public function getTplInstance() {
		if (!class_exists('dle_template', false))//for backend
			require_once self::checkPlugins(ENGINE_DIR.'/classes/templates.class.php');
		
		$tpl = new NewTemplates;
		$tpl->dir = ROOT_DIR.'/templates/'.totranslit($this->dle->config['skin'], false, false);
		return $tpl;
	}
	
	public function declension($n = 0, $words) {//варианты окончаний для 1|2|5 (1 рубль, 2 рубля, 5 рублей), пример использования: declension(3, 'рубл|ь|я|ей')
		$words = explode('|', trim($words));
		return $n % 10 == 1 && $n % 100 != 11 ? $words[0].$words[1] : ($n % 10 >= 2 && $n % 10 <= 4 && ($n % 100 < 10 || $n % 100 >= 20) ? $words[0].$words[2] : $words[0].$words[3]);
	}
	
	public function handleMainContent($content) {
		if ($rows = $this->getPlugins()) {
			foreach ($rows as $row) {
				$instance = $this->getAddonInstanceByAlias($row['alias']);
				
				if ($instance->on and method_exists($instance, 'handleMainContent')) {
					$content = $instance->handleMainContent($content);
				}
			}
		}
		
		
		$content = str_replace(
			'</head>',
			$this->js_css->renderCSSLinks().
			$this->js_css->renderJsLinks().
			$this->js_css->renderJsCode().
			'</head>',
			$content
		);
		
		$content = str_replace(
			'</body>',
			$this->js_css->renderCSSLinks(true).
			$this->js_css->renderJsLinks(true).
			$this->js_css->renderJsCode(true).
			'</body>',
			$content
		);
		
		return $content;
	}
	
	public function getPaySources() {
		$output_array = array();
		foreach ($this->webcash->getConst('pay_sources') as $key => $value) {
			if ($key == self::PAY_SOURCE_BALANCE and $this->user->group == User::GUEST_USERGROUP_ID)
				continue;
			
			$output_array[$key] = __($value['title']);
		}
		
		if (!$output_array)
			$this->webcash->exitMsg('У вас нет доступных источников оплаты');
		
		return $output_array;
	}
	
	public function getSiteUrl() {
		$protocol = $this->getSiteProtocol();

		if (!$this->dle->config['http_home_url']) {
			$url = $protocol.'://'.$_SERVER['HTTP_HOST'];
		} elseif (strpos($this->dle->config['http_home_url'], '//') === 0) {
			$url = $protocol.':'.$this->dle->config['http_home_url'];
		} elseif (strpos($this->dle->config['http_home_url'], '/') === 0) {
			$url = $protocol.'://'.$_SERVER['HTTP_HOST'].$this->dle->config['http_home_url'];
		} else {
			$url = $this->dle->config['http_home_url'];
			if ($protocol == 'https' and stripos($url, 'http://') !== false)
				$url = str_ireplace('http://', 'https://', $url);
		}
		$url = rtrim($url, '/').'/';
		return $url;
	}
	
	public function getSiteProtocol() {
		if (function_exists('isSSL'))
			return isSSL() ? 'https' : 'http';

		if ($str = safe_array_access($_SERVER, 'HTTP_X_FORWARDED_PROTO') and in_array($str, array('http', 'https')))
			return $str;

		if ($str = safe_array_access($_SERVER, 'HTTPS') and strtolower($str) == 'on')
			return 'https';

		return 'http';
	}
	
}