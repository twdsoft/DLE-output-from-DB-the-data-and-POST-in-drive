<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

class DleVars extends Application
{
	public function __get($property) {
		if (isset($this->{$property}) or property_exists($this, $property)) {
			return $this->{$property};
		} elseif (isset($GLOBALS[$property])) {
			return $GLOBALS[$property];
		} elseif ($property == 'tpl') {//��� ajax �������
			return $this->webcash->getTplInstance();
		}
	}
}