<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

class NewDb extends \db
{
	private $webcash = null;
	private $hooks_allowed = true;
	
	public function procQuery($query, $method_name) {
		global $member_id;
		
		if ($member_id) {
			if ($this->hooks_allowed) {
				$this->hooks_allowed = false;
				
				$webcash = $this->getWebCashInstance();
				
				if ($webcash->config->state) {
					$aliases = array();
					
					if ($method_name == 'hookNewDbBeforeQuery') {
						$aliases = $webcash->config->hook_newdb_before_query_aliases;
					} elseif ($method_name == 'hookNewDb') {
						$aliases = $webcash->config->hook_newdb_aliases;
					}
					
					foreach ($aliases as $alias) {
						$query = $webcash->callPluginMethod($alias, $method_name, true, true, $query);
					}
				}
				
				$this->hooks_allowed = true;
			}
		}
		
		return $query;
	}
	
	public function super_query($query, $multi = false, $show_error = true, $log_query = true) {
		$this->hooks_allowed = false;
		$result = parent::super_query($query, $multi, $show_error, $log_query);
		$this->hooks_allowed = true;
		
		return $result;
	}
	
	public function query($query, $show_error = true, $log_query = true) {
		$query = $this->procQuery($query, 'hookNewDbBeforeQuery');
		$result = parent::query($query, $show_error, $log_query);
		$this->procQuery($query, 'hookNewDb');
		return $result;
	}
	
	private function getWebCashInstance() {
		global $webcash;
		
		if (!$this->webcash) {
			require ENGINE_DIR.'/modules/webcash/init.php';
			
			$this->webcash = $webcash;
		}
		
		return $this->webcash;
	}
	
}