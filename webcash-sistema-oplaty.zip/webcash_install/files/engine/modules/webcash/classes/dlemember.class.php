<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

class DleMember extends Application
{
	public function getRow() {
		$db = new \db;
		
		require ENGINE_DIR.'/modules/sitelogin.php';
		
		return $member_id;
	}
}