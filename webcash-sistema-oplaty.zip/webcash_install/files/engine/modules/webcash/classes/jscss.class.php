<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

class JsCss extends Application
{
	const TAB = "\t";
	
	protected $css_files = array();
	protected $css_code_array = array();
	protected $js_files = array();
	protected $js_code_array = array();
	protected $html_code_array = array();
	
	private $only_once_hashes = array();
	
	public function addCSSFile($url, $footer = false, $minify_off = false, $media = null, $attribs = array()) {
		$key = $footer ? 'footer' : 'header';
		
		$this->css_files[$url]['footer'] = $footer;
		$this->css_files[$url]['media'] = $media;
		$this->css_files[$url]['attribs'] = $attribs;

		return $this;
	}
	
	public function addCSSCode($content, $footer = false) {
		$key = $footer ? 'footer' : 'header';
		
		$this->css_code_array[$key][] = array(
			'content' => $content,
		);

		return $this;
	}
	
	public function addJsFile($url, $footer = false, $minify_off = false, $defer = false, $async = false) {
		$key = $footer ? 'footer' : 'header';
		
		$this->js_files[$url]['footer'] = $footer;
		$this->js_files[$url]['defer'] = $defer;
		$this->js_files[$url]['async'] = $async;

		return $this;
	}
	
	public function addJsCode($content, $footer = false, $on_ready = false, $only_once_check = false) {
		if ($only_once_check) {
			$hash = md5($content);
			if (in_array($hash, $this->only_once_hashes)) {
				return $this;
			} else {
				$this->only_once_hashes[] = $hash;
			}
		}
		
		$key = $footer ? 'footer' : 'header';
		
		$this->js_code_array[$key][] = array(
			'content' => $content,
			'on_ready' => $on_ready,
		);
		
		return $this;
	}
	
	
	public function addHtmlCode($content, $footer = false) {
		$key = $footer ? 'footer' : 'header';

		if (empty($this->html_code_array[$key]))
			$this->html_code_array[$key] = $content;
		else
			$this->html_code_array[$key] .= PHP_EOL.$content;
		
		return $this;
	}
	
	public function renderCSSLinks($footer = false) {//Generate stylesheet links
		$html = '';
		$tab = self::TAB;
		
		$css_files = array_filter($this->css_files, function ($file) use ($footer) {
			return $footer ? $file['footer'] : !$file['footer'];
		});

		if ($css_files) {
			if ($css_files) {
				foreach ($css_files as $url => $params) {
				
					$html .= $tab.'<link rel="stylesheet" href="'.$url.'" type="text/css"';

					if (!is_null($params['media'])) {
						$html .= ' media="'.$params['media'].'"';
					}

					$html .= $this->buildTagAttributes($params['attribs']);
					$html .= ' />'.PHP_EOL;
				}
			}
		}
		
		return $html;
	}
	
	public function renderCSSCode($footer = false) {//Generate stylesheet declarations
		$html = '';
		$tab = self::TAB;
		$key = $footer ? 'footer' : 'header';
		
		if (isset($this->css_code_array[$key])) {
			$html .= $tab.'<style type="text/css">'.PHP_EOL;
			
			foreach ($this->css_code_array[$key] as $value) {
			
				$content = $value['content'];
				
				if (strpos($content, "\n") !== false) {
					$content = str_replace("\n", "\n".$tab, $content);
					$html .= $tab.$tab.$content.PHP_EOL;
				} else {
					$html .= $tab.$content.PHP_EOL;
				}
			}

			$html .= $tab.'</style>'.PHP_EOL;
		}
	
		return $html;
	}
	
	public function renderJsLinks($footer = false) {//Generate script file links
		$html = '';
		$tab = self::TAB;
		
		$js_files = array_filter($this->js_files, function ($file) use ($footer) {
			return $footer ? $file['footer'] : !$file['footer'];
		});
		
		if ($js_files) {
			foreach ($js_files as $url => $params) {
			
				$html .= $tab.'<script src="'.$url.'" type="text/javascript"';

				if ($params['defer']) {
					$html .= ' defer="defer"';
				}

				if ($params['async']) {
					$html .= ' async="async"';
				}
				
				if ($this->helper->isWin1251Charset()) {
					$html .= ' charset="utf-8"';
				}
				
				$html .= '></script>'.PHP_EOL;
			}
		}
		
		return $html;
	}
	
	public function renderJsCode($footer = false) {//Generate script declarations
		$html = '';
		$tab = self::TAB;
		$key = $footer ? 'footer' : 'header';
		
		if (isset($this->js_code_array[$key])) {
			$temp = '';
			$html .= $tab.'<script type="text/javascript">'.PHP_EOL;

			//немедленное выполнение JS кода
			foreach ($this->js_code_array[$key] as $value) {
			
				$content = $value['content'];
				
				if ($value['on_ready']) {
					$content = str_replace("\n", "\n".$tab.$tab, $content);
					$temp .= $tab.$tab.$content.PHP_EOL;
				} else {
					if (strpos($content, "\n") !== false) {
						$content = str_replace("\n", "\n".$tab, $content);
						$html .= $tab.$tab.$content.PHP_EOL;
					} else {
						$html .= $tab.$content.PHP_EOL;
					}
				}
			}
			
			//выполнение JS кода после загрузки страницы
			if ($temp) {
				$html .= PHP_EOL;
				$html .= $tab.'jQuery(document).ready(function($) {'.PHP_EOL;
				$html .= $temp;
				$html .= $tab.'});'.PHP_EOL;
			}

			$html .= $tab.'</script>'.PHP_EOL;
		}
	
		return $html;
	}


	public function renderHtmlCode($footer = false) {//Generate HTML declarations
		$tab = self::TAB;
		$key = $footer ? 'footer' : 'header';
		
		if (isset($this->html_code_array[$key])) {
			$content = $this->html_code_array[$key];
			$content = str_replace("\n", "\n".$tab, $content);
			return $tab.$content.PHP_EOL;
		}
	}

	public function buildTagAttributes(array $array) {
		$output = '';
		
		foreach ($array as $key => $value) {
			$output .= ' '.$key.'="'.$value.'"';
		}
		
		return $output;
	}

}