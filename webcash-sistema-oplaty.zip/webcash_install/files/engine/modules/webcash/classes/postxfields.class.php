<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

class PostXfields extends UserXfields
{
	const XFIELDS_FILE = 'xfields.txt';
	
	public function makeXfieldLine($name, $title, $optional = true, $type = 'text', $default_val = '', $hint = '') {
		return implode('|', array(
            $name,//[0] Имя
            $title,//[1] Название
            '',//[2] Категории
            $type,//[3] Тип поля
			($type != 'yesorno') ? $default_val : '',//[4] Значение по умолчанию
            (int)$optional,//[5] Значение для "select" (1 или 0) ?
            0,//[6] Значение для "text" и "select" (1 или 0)
            0,//[7] Значение для "textarea" (1 или 0)
            ($type == 'yesorno') ? 0 : 1,//[8] Значение для "text" и "textarea" (1 или 0)
            '',//[9] Максимальные размеры оригинального изображения
            '',//[10] Максимальный вес изображения
            0,//[11] Наложить водяные знаки (checkbox)
            0,//[12] Создать уменьшенную копию (checkbox)
			'',//[13] Размеры уменьшенной копии
			'',//[14] Расширения файлов, допустимых к загрузке
			'',//[15] Максимальный размер файла допустимый к загрузке на сервер (в килобайтах)
			'',//[16] Количество загружаемых изображений (для галлереи)
			($type == 'yesorno') ? $default_val : '',//[17] Значение по умолчанию для "yesorno"
			$hint,//[18] Подсказка для поля
			'',//[19] Группы пользователей для добавления
			'',//[20] Группы пользователей для просмотра
			'',//[21] Разделитель для списка перекрестных ссылок
		));
	}

	public function loadXfieldsArrayFromDb($post_id = 0) {
		$post_id = (int)$post_id;
		
		if ($str = $this->db->selectCell("SELECT xfields FROM ".PREFIX."_post WHERE id = '{$post_id}' LIMIT 1")) {
			return $this->getXfieldsWithKeyName($str);
		}
		
		return array();
	}
	
	public function saveXfieldsArrayToDb($xfields, $post_id = 0) {
		$post_id = (int)$post_id;
		
		$str = '';
		foreach ($xfields as $key => $value) {
			$str .= ($str ? '||' : '')."{$key}|{$value}";
		}
		$str = $this->db->escape($str);
		
		return $this->db->query("UPDATE ".PREFIX."_post SET xfields = '{$str}' WHERE id = '{$post_id}' LIMIT 1");
	}
	
}