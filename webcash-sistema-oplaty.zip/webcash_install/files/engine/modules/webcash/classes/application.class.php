<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

class Application
{
	protected $constants = array();
	
	private static $objects = array();
	
	public function __get($property) {
		if (isset($this->{$property}) or property_exists($this, $property)) {
			return $this->{$property};
		} else {
			
			if (isset(self::$objects[$property])) {//если такой объект уже существует, возвращаем его
				return self::$objects[$property];
			} else {
				$config = Config::instance();
				
				if ($class = $config->getValueBySectionAndKey('CLASSES', $property)) {//ищем в конфиге класс
					//сохраняем для будущих обращений к нему
					if (is_array($class)) {
						$str = array_shift($class);
						$reflector = new \ReflectionClass($str);
						self::$objects[$property] = $reflector->newInstanceArgs($class);//создаем объект класса через Reflection API с параметрами
					} else {
						if ($class == 'WebCash\\WebCash') {
							self::$objects[$property] = WebCash::instance();
						} elseif ($class == 'Twig') {
						
							require_once $this->webcash->module_path.'site/lib/Twig/Autoloader.php';
							
							Twig_Autoloader::register();
							$arr = $this->config->cache_twig_on ? array('cache' => $this->webcash->cache_path.WebCash::TWIG_CACHE_FOLDER) : array();
							$twig = new \Twig_Environment(new \Twig_Loader_String(), $arr);
							$twig->setCharset($this->dle->config['charset']);
							$twig->addGlobal('CONST', $this->webcash->getClassesConstants());
							$twig->addGlobal('USER_CURRENCY_DECLENSION', str_replace('|', '*', __(safe_array_access($this->config->currencies, $this->user->currency, 'declension'))));
							$twig->addGlobal('GET', $_GET);
							
							$filter = new \Twig_SimpleFilter('currCnvDcl', array($this->wc_currency, 'currCnvDeclension'));//15 рублей
							$twig->addFilter($filter);
							$filter = new \Twig_SimpleFilter('currCnvShort', array($this->wc_currency, 'currCnvShort'));//15 руб.
							$twig->addFilter($filter);
							$filter = new \Twig_SimpleFilter('currCnv', array($this->wc_currency, 'currCnv'));
							$twig->addFilter($filter);
							$filter = new \Twig_SimpleFilter('currCnvMainTo', array($this->wc_currency, 'convertMainCurrencyTo'));
							$twig->addFilter($filter);
							$filter = new \Twig_SimpleFilter('truncateHtml', array($this->helper, 'truncateHtml'));
							$twig->addFilter($filter);
							
							self::$objects[$property] = $twig;
							
							if ($arr = $this->config->getValueBySectionAndKey('MAIN', 'hook_twig_aliases')) {
								foreach ($arr as $alias) {
									$query = $this->webcash->callPluginMethod($alias, 'hookTwig');
								}
							}
							
						} else {
							$instance = new $class();//для большинства объектов
							
							if (property_exists($instance, 'table_a'))
								$instance->table_a = PREFIX.'_'.$instance->table_a;
								
							if (property_exists($instance, 'table_b'))
								$instance->table_b = PREFIX.'_'.$instance->table_b;
								
							if (property_exists($instance, 'table_c'))
								$instance->table_c = PREFIX.'_'.$instance->table_c;
							
							if (is_addon_class($class)) {
								if (empty($instance->alias))
									trigger_error('Object alias does not exist: '.$class, E_USER_ERROR);
							}
							
							self::$objects[$property] = $instance;
						}
					}
					
					return self::$objects[$property];//возвращаем созданный объект
				} else {
				
					if (method_exists($this, 'readSettingsFromFile')) {
						//trigger_error('Property not exists: '.$property, E_USER_ERROR);//LASTDELETE
						
						$this->readSettingsFromFile();
						
						if (isset($this->cfg[$property])) {
							return $this->{$property};
						}
					}
					
					trigger_error('Property ['.$property.'] not exists in class: '.get_class($this), E_USER_ERROR);
				}
			}
		}
	}
	
	public function set($key, $value) {
		if (strpos($key, '|') !== false) {
			$keys_arr = explode('|', $key);
			$array = array_shift($keys_arr);

			if (property_exists($this, $array) and is_array($this->{$array})) {
				$reference = &$this->{$array};
				
				foreach ($keys_arr as $key) {
				
					if (!$reference or !array_key_exists($key, $reference)) {
						$reference[$key] = array();
					}
					
					$reference = &$reference[$key];
				}
				
				$reference = $value;
				unset($reference);
				return $this;
			}
		} else {
			if (property_exists($this, $key)) {
				$this->{$key} = $value;
				return $this;
			}
		}
	}
	
	public function getConst($key, $default_value = null) {
		if (strpos($key, '|') !== false and $this->constants) {
			$value = get_nested_var($this->constants, $key);
			if ($value or is_null($default_value))
				return $value;
		} else {
			if (isset($this->constants[$key])) {
				return $this->constants[$key];
			}
		}

		return $default_value;
	}

}