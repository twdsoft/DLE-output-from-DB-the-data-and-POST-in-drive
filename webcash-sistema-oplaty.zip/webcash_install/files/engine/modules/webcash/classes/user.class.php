<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

class User extends Application
{
	const ADMIN_ID = 1;
	const ADMIN_USERGROUP_ID = 1;
	const VISITOR_USERGROUP_ID = 4;
	const GUEST_USERGROUP_ID = 5;
	
	public function __get($property) {
		if (isset($this->{$property}) or property_exists($this, $property)) {
			return $this->{$property};
		}
		
		if (in_array($property, array('ip', 'long_ip')) and $this->dle->_IP) {
			$this->user->ip = $this->dle->_IP;
			$a = ip2long($this->user->ip);
			$this->long_ip = sprintf('%u', $a);
			return $this->{$property};
		}
		
		if (in_array($property, array('id', 'group', 'login', 'email'))) {
			if (!$this->dle->member_id) {
				$this->dle->member_id = $this->dlemember->getRow();
			}
			
			$this->id = (int)safe_array_access($this->dle->member_id, 'user_id');
			$this->group = (int)safe_array_access($this->dle->member_id, 'user_group');
			$this->login = safe_array_access($this->dle->member_id, 'name');
			$this->email = safe_array_access($this->dle->member_id, 'email');
			return $this->{$property};
		}
		
		if (in_array($property, array('nonce'))) {
			if (!$this->nonce = $this->dle->dle_login_hash) {
				$this->nonce = $this->getOldVersionUserHash();
			}
			return $this->{$property};
		}
		
		if ($property == 'currency') {
			$this->currency = $this->config->main_currency;
		}
		
		return parent::__get($property);
	}
	
	public function getUserBalance($user_id = 0) {
		$user_id = (int)$user_id or $user_id = $this->id;
		
		if ($this->config->balance_in_xfield)
			$result = $this->userxfields->getXfieldValue($this->config->balance_field_name, $user_id);
		else
			$result = $this->db->selectCell("SELECT {$this->config->balance_field_name} FROM ".USERPREFIX."_users WHERE user_id = '{$user_id}' LIMIT 1");
			
		return $result > 0 ? $result : 0;
	}
	
	public function isLoggedIn() {
		return $this->dle->is_logged or (defined('LOGGED_IN') and LOGGED_IN);
	}
	
	public function isAdminGroup() {
		return $this->group == self::ADMIN_USERGROUP_ID;
	}
	
	public function incrementUserBalance($value, $area_alias, $rel_item_type = 0, $rel_item_id = 0, $user_id = 0) {
		return $this->updateUserBalance($value, 'plus', $area_alias, $rel_item_type, $rel_item_id, $user_id);
	}
	
	public function decrementUserBalance($value, $area_alias, $rel_item_type = 0, $rel_item_id = 0, $user_id = 0) {
		return $this->updateUserBalance($value, 'minus', $area_alias, $rel_item_type, $rel_item_id, $user_id);
	}
	
	public function updateUserBalance($value, $sign, $area_alias, $rel_item_type = 0, $rel_item_id = 0, $user_id = 0) {
		$area_alias = only_word($area_alias);
		$rel_item_type = (int)$rel_item_type or $rel_item_type = AddonSettings::DEFAULT_PAYMENT;
		$rel_item_id = (int)$rel_item_id;
		$user_id = (int)$user_id or $user_id = $this->id;
		
		if ($this->config->balance_in_xfield) {
			$xfields = $this->userxfields->loadXfieldsArrayFromDb($user_id);
			
			if ($sign == 'plus') {
				$xfields[$this->config->balance_field_name] = $xfields[$this->config->balance_field_name] + $value;
			} else {
				$xfields[$this->config->balance_field_name] = $xfields[$this->config->balance_field_name] > $value ? $xfields[$this->config->balance_field_name] - $value : 0;
			}
			
			$xfields[$this->config->balance_field_name] = nd_decpoint($xfields[$this->config->balance_field_name]);
			
			$result = $this->userxfields->saveXfieldsArrayToDb($xfields, $user_id);
		} else {
			$result = $this->db->query("
				UPDATE ".USERPREFIX."_users
				SET {$this->config->balance_field_name} = {$this->config->balance_field_name} ".($sign == 'plus' ? "+" : "-")." '{$value}'
				WHERE user_id = '{$user_id}'
				LIMIT 1"
			);
		}
		
		if ($result) {
			$id = $this->db->query(
				"INSERT INTO
				{$this->webcash->balance_transactions_table}
				SET
					amount = '{$value}',
					user_id = '{$user_id}',
					is_plus = '".($sign == 'plus' ? 1 : 0)."',
					area_alias = '{$area_alias}',
					rel_item_type = '{$rel_item_type}',
					rel_item_id = '{$rel_item_id}'"
			);
			
			return $id;
		}
	}
	
	public function saveBalanceTblRelItemId($rel_item_id, $id) {
		$rel_item_id = (int)$rel_item_id;
		$id = (int)$id;
		return $this->db->query("UPDATE {$this->webcash->balance_transactions_table} SET rel_item_id = '{$rel_item_id}' WHERE id = '{$id}' LIMIT 1");
	}
	
	public function setUsergroup($group_id, $new_time_limit, $user_id = 0) {
		$group_id = (int)$group_id;
		$new_time_limit = (int)$new_time_limit;
		$user_id = (int)$user_id or $user_id = $this->id;
		
		return $this->db->query("
			UPDATE ".USERPREFIX."_users
			SET user_group = '{$group_id}'
			".($new_time_limit ? ",time_limit = '{$new_time_limit}'" : "")."
			WHERE user_id = '{$user_id}'
			LIMIT 1"
		);
	}
	
	public function addUserTableColumn() {
		$name = $this->config->balance_field_name;	
		
		if (!$this->db->query("SHOW COLUMNS FROM ".USERPREFIX."_users LIKE '{$name}'")) {
			if ($this->db->query("ALTER TABLE ".USERPREFIX."_users ADD `{$name}` DECIMAL(10,2) UNSIGNED NOT NULL DEFAULT 0")) {
				return $this->db->query("CREATE INDEX `".USERPREFIX."_users_{$name}_Index` ON ".USERPREFIX."_users (`{$name}`)");
			}
		}
	}
	
	public function deleteUserTableColumn() {
		if ($this->db->query("SHOW COLUMNS FROM ".USERPREFIX."_users LIKE '{$this->config->balance_field_name}'")) {
			return $this->db->query("ALTER TABLE ".USERPREFIX."_users DROP {$this->config->balance_field_name}");
		}
	}
	
	public function getBalanceXfieldLine() {
		return implode('|', array(
            $this->config->balance_field_name,
            __($this->config->balance_xfield_title),
            0,//Добавить на страницу регистрации?
            'text',
            0,//Поле может быть изменено пользователем?
            0,//Сделать это поле личным?
            '',
		));
	}
	
	private function getOldVersionUserHash() {
		if (!$user_id = SESSION('dle_user_id')) {
			$user_id = COOKIE('dle_user_id');
		}
		
		if (!$str = SESSION('dle_password')) {
			$str = COOKIE('dle_password');
		}
		
		if ($user_id and $str) {
			return md5($_SERVER['HTTP_HOST'].$user_id.sha1($str).safe_array_access($this->dle->config, 'key').date('Ymd'));
		} else {
			return md5($_SERVER['HTTP_HOST'].sha1(session_id()).safe_array_access($this->dle->config, 'key').date('Ymd'));
		}
	}
	
	public function makeProfileLink($row, $encore = '', $profile_popup = true, $usergroups_colors = true) {
		$url = $this->webcash->site_url.'user/'.urlencode($row['name']).'/';
		$tag_part = '';
		$title = __('Перейти в профиль пользователя');
		if ($profile_popup) {
			$tag_part = 'onclick="ShowProfile(\''.urlencode($row['name']).'\', \''.$this->helper->htmlspecialchars($url).'\', \''.$this->dle->user_group[$this->user->group]['admin_editusers'].'\'); return false;"';
			$title = __('Открыть диалоговое окно с информацией о пользователе');
		}
		
		$encore or $encore = $row['name'];
		
		if ($usergroups_colors) {
			$encore = $this->dle->user_group[$row['user_group']]['group_prefix'].$encore.$this->dle->user_group[$row['user_group']]['group_suffix'];
		}
		
		return '<a '.$tag_part.' href="'.$url.'" title="'.$title.'">'.$encore.'</a>';
	}
	
}