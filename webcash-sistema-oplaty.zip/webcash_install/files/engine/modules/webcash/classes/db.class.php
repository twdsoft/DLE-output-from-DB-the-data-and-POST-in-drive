<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

class DB extends Application
{
	public function selectRow($sql) {
        return $this->dle->db->super_query($sql);
	}

	public function select($sql) {
        return $this->dle->db->super_query($sql, true);
	}

	public function selectCell($sql) {
        $rows = $this->dle->db->super_query($sql);
		if (!is_array($rows))
			return $rows;
        if (!count($rows))
			return null;
        reset($rows);
        $row = current($rows);
        if (!is_array($row))
			return $row;
        reset($row);
        return current($row);
	}
	
	public function query($sql) {
		if ($this->dle->db->query($sql)) {
			if ($result = $this->dle->db->get_affected_rows($this->dle->db->db_id)) {
				if (strpos($sql, 'INSERT') !== false)
					return $this->dle->db->insert_id();
			}
			
			return $result;
		}
	}
	
	public function prepareSqlPart($data, $html_special_chars = false, $ajax_to_win1251 = true) {
		$output = '';
		
		if ($ajax_to_win1251) {
			if (!$this->helper->isWin1251Charset() or !$this->helper->isAjax())
				$ajax_to_win1251 = false;
		}
		
		foreach ($data as $key => $value) {
			if (is_array($value))
				$value = implode(',', $value);
			
			if ($html_special_chars)
				$value = $this->helper->htmlspecialchars($value);
				
			if ($ajax_to_win1251)
				$value = to_win1251($value);
			
			$value = $this->escape($value);
			$output .= ($output ? ',' : '')."`{$key}` = '{$value}'\n";
		}
		return $output;
	}

	public function esc_html($value) {
		return $this->escape($this->helper->htmlspecialchars($value));
	}

	public function escape($value) {
		return $this->dle->db->safesql($value);
	}

	public function timeToStr($timestamp) {
		return date('Y-m-d H:i:s', $timestamp);
	}
}