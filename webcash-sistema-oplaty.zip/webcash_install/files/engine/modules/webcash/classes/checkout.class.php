<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

class Checkout extends Application
{
	const DATA_STORE_CURRENT_KEY = 'checkout_current_key';
	const DATA_STORE_NAME = 'checkout_store';
	
	public function getNextStep($step) {
		if ($step == 'amount_value' or $step == 'email' or $step == 'redirect') {
			return ($this->webcash->default_gateway and $this->webcash->default_item) ? 'to_gateway' : 'choose_payment_method';
		} elseif ($step == 'choose_payment_method') {
			return 'to_gateway';
		}
	}
	
	public function getGatewayForm($gw_alias, $gw_item_id, $cs_key) {
		if (safe_array_access($this->webcash->getGateways(), $gw_alias, 'items', $gw_item_id)) {
			if ($instance = $this->webcash->getAddonInstanceByAlias($gw_alias) and method_exists($instance, 'renderPaymentForm')) {
				if ($invoice_id = $this->createInvoice($gw_alias, $cs_key)) {
					$html = $instance->renderPaymentForm($invoice_id, $cs_key, $gw_item_id);
					
					if (WebCash::DEBUG_SETTINGS) {
						$html .= '<br><br>';
						$url = $this->successCheckoutUrl($invoice_id, $cs_key, '&gw_alias='.$gw_alias);
						$html .= '<div>Success Url: <a href="'.$url.'" target="_blank">'.$url.'</a></div>';
						$url = $this->failCheckoutUrl($invoice_id, $cs_key);
						$html .= '<div>Fail Url: <a href="'.$url.'" target="_blank">'.$url.'</a></div>';
					}
					
					return $html;
				}
			}
		} else {
			return __('Данный метод оплаты не существует');
		}
	}
	
	public function endSetCheckoutStoreAndRedirect($plugin_instance, $checkout_store) {
		$checkout_store['checkout_header'] = to_win1251($plugin_instance->frontend_header);
		$checkout_store['plg_alias'] = $plugin_instance->alias;
		isset($checkout_store['rel_item_type']) or $checkout_store['rel_item_type'] = AddonSettings::DEFAULT_PAYMENT;
		
		$cs_key = md5(implode($checkout_store));
		$_SESSION[self::DATA_STORE_CURRENT_KEY] = $cs_key;
		$this->setDataStore($cs_key, $checkout_store);
		
		$step = (($this->user->isLoggedIn() and $this->user->email) or !empty($checkout_store['email'])) ? 'choose_payment_method' : 'email';
		
		$arr = array(
			'action' => 'checkout',
			'step' => $step,
			'cs_key' => $cs_key,
		);
		
		$this->webcash->default_gateway and $arr['gw_alias'] = $this->webcash->default_gateway; 
		$this->webcash->default_item and $arr['default_item'] = $this->webcash->default_item;
		
		
		$this->showPopupCheckout($arr);
		
		$str = $this->webcash->site_url.'index.php?do=webcash&'.http_build_query($arr);
		$this->helper->showMsgOk('Перенаправление на страницу оплаты...', 'Информация', $str);
	}
	
	public function showPopupCheckout($arr) {
		if (!$this->config->checkout_some_steps_in_popup)
			return;
		
		$_GET = $arr;
		
		if ($html = $this->renderCheckoutHtml()) {
			$inline_scripts = '';
			
			if (strpos($html, '<script') !== false) {
				require_once $this->webcash->module_path.'site/lib/simple_html_dom/simple_html_dom.php';
				
				$dom = str_get_html($html, true, true, DEFAULT_TARGET_CHARSET, false);
				
				foreach ($dom->find('script') as $e) {
					$inline_scripts .= $e->outertext;
					$e->outertext = '';
				}
				
				$html = $dom->save();
				$dom->clear();
				unset($dom);
			}
			
			$html = '<div class="wc-checkout-popup wc-popup-step-'.$step.'">'.$html.'</div>';
			
			$html = '
			<script>
			var btns = {};
			
			WEBCASH.confirmDialog(
				"'.addslashes(str_replace(array("\r", "\n", "\t"), ' ', $html)).'",
				function() {
					$(this).dialog("close");
				},
				null,
				"'.lang('Подготовка к оплате').'",
				{buttons: btns}
			);
			</script>'.PHP_EOL.$inline_scripts;
			
			$this->helper->sendAjaxContent('body', $html, Helper::APPEND_AJAX_CONTENT);
		}
	}
	
	public function fillEmailStep() {
		if (!$email = POST('email')) {
			$this->helper->showMsgError('Необходимо указать Емайл');
		} elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
			$this->helper->showMsgError('Неправильный формат Емайл');
		} elseif ($cs_key = POST('cs_key')) {
			if ($checkout_store = $this->getDataStore($cs_key)) {
				$checkout_store['email'] = $email;
				$this->setDataStore($cs_key, $checkout_store);
				
				$arr = array(
					'action' => 'checkout',
					'step' => 'choose_payment_method',
					'cs_key' => $cs_key,
				);
				
				$this->webcash->default_gateway and $arr['gw_alias'] = $this->webcash->default_gateway; 
				$this->webcash->default_item and $arr['default_item'] = $this->webcash->default_item;
				
				
				$this->showPopupCheckout($arr);
				
				$str = $this->webcash->site_url.'index.php?do=webcash&'.http_build_query($arr);
				$this->helper->showMsgOk('Переход к следующему шагу...', 'Информация', $str);
			}
		}
	}
	
	public function createInvoice($gw_alias, $cs_key) {
		if ($checkout_store = $this->getDataStore($cs_key)) {
			$checkout_store['cs_key'] = $cs_key;
			
			$data = array(
				'gateway' => only_word($gw_alias),
				'amount' => $checkout_store['amount'],
				'area_alias' => safe_array_access($checkout_store, 'plg_alias'),
				'rel_item_type' => safe_array_access($checkout_store, 'rel_item_type'),
				'rel_item_id' => safe_array_access($checkout_store, 'rel_item_id'),
				'email' => $this->user->email ? $this->user->email : $checkout_store['email'],
				'checkout_store' => serialize($checkout_store),
				'user_id' => $this->user->id,
				'ip' => $this->user->long_ip,
			);
			
			$sql_part = $this->db->prepareSqlPart($data);
			
			if ($invoice_id = $this->db->query("INSERT IGNORE INTO {$this->webcash->gateway_invoices_table} SET {$sql_part}")) {
				$checkout_store['invoice_id'] = $invoice_id;
				$this->setDataStore($cs_key, $checkout_store);
				
				return $invoice_id;
			}
		}
	}
	
	public function setDataStore($cs_key, $checkout_store) {
		$_SESSION[self::DATA_STORE_NAME][$cs_key] = $checkout_store;
	}
	
	public function addPaymentToDb($invoice_id, $sender, $gateway_details_arr, $state = true) {
		if ($row = $this->webcash->getRowById($this->webcash->gateway_invoices_table, $invoice_id)) {
			$gateway_details = http_build_query($gateway_details_arr, null, '|');
			
			$id = $this->db->query(
				"INSERT INTO
				{$this->webcash->gateway_payments_table}
				SET
					invoice_id = '{$row['id']}',
					amount = '{$row['amount']}',
					sender = '".$this->db->esc_html($sender)."',
					gateway = '{$row['gateway']}',
					user_id = '{$row['user_id']}',
					email = '{$row['email']}',
					ip = '{$row['ip']}',
					gateway_details = '".$this->db->escape($gateway_details)."',
					area_alias = '{$row['area_alias']}',
					rel_item_type = '{$row['rel_item_type']}',
					rel_item_id = '{$row['rel_item_id']}',
					state = '{$state}'"
			);
			
			return $id;
		}
	}
	
	public function renderCheckoutHtml() {
		if (!$this->config->checkout_on)
			return $this->webcash->getMsgContent('Оплата через платежные шлюзы выключена');
		
		$plg_alias = '';
		$amount_value = 0;
		$checkout_store = array();
		
		$steps = array('email', 'redirect', 'choose_payment_method', 'to_gateway', 'result');
		$step = ($str = GET('step') and in_array($str, $steps)) ? $str: 'redirect';
		
		$tpl = $this->webcash->getTplInstance();
		$tpl->assign('step', $step);
		$tpl->assign('default_gateway', $this->webcash->default_gateway);
		$tpl->assign('default_item', $this->webcash->default_item);
		$tpl->assign('gateways', $this->webcash->getGateways());
		
		
		if ($step != 'redirect') {
			$cs_key = only_word(GET('cs_key'));
			
			if ($step == 'result') {
				if ($invoice_id = (int)GET('invoice_id')) {
					if ($invoice_row = $this->webcash->getRowById($this->webcash->gateway_invoices_table, $invoice_id)) {
						if ($invoice_row['checkout_store']) {
							$checkout_store = unserialize($invoice_row['checkout_store']);
							
							if (!$cs_key) {
								$cs_key = $checkout_store['cs_key'];
							}
						}
					}
				}
			}
			
			if (!$cs_key) {
				$cs_key = SESSION(self::DATA_STORE_CURRENT_KEY);
			}
			
			if ($cs_key) {
				if (!$checkout_store) {
					$checkout_store = $this->getDataStore($cs_key);
				}
				
				if ($checkout_store) {
					$amount_value = safe_array_access($checkout_store, 'amount');
					$plg_alias = safe_array_access($checkout_store, 'plg_alias');
					
					$tpl->assign('cs_key', $cs_key);
					$tpl->assign('checkout_header', safe_array_access($checkout_store, 'checkout_header'));
				}
			} elseif ($step != 'result') {
				trigger_error('Не указан ключ для таблицы шлюза', E_USER_ERROR);
			}
		}
		
		if ($plg_alias or $plg_alias = only_word(GET('plg_alias')))
			$tpl->assign('plg_alias', $plg_alias);
			
		if ($amount_value or $amount_value = only_float(GET('amount')))
			$tpl->assign('amount_value', $amount_value);
		
		$tpl->assign('user_hash', $this->user->nonce);
		$tpl->assign('MODULEURL', $this->webcash->module_url);
		$tpl->assign('SITEURL', $this->webcash->site_url_ws);
		
		
		if ($step == 'result') {
			if (GET('success') == 'yes') {
				if (!$str = $this->webcash->callPluginMethod($plg_alias, 'checkoutSuccessMessage', true, false))
					if (!$str = $this->webcash->getPluginProperty($plg_alias, 'both_paysource_success_message'))
						if (!$str = $this->webcash->getPluginProperty($plg_alias, 'checkout_success_message'))
							$str = __($this->config->checkout_success_message);
				
			} elseif (GET('success') == 'no') {
				if (!$str = $this->webcash->callPluginMethod($plg_alias, 'checkoutFailMessage', true, false))
					if (!$str = $this->webcash->getPluginProperty($plg_alias, 'both_paysource_fail_message'))
						if (!$str = $this->webcash->getPluginProperty($plg_alias, 'checkout_fail_message'))
							$str = __($this->config->checkout_fail_message);
			}
			
			
			$tpl->assign('message_raw', $str);
			
			$title = (GET('success') == 'yes') ? __('Информация') : __('Ошибка');
			$str = $this->webcash->getMsgContentNotTranslateNotConvert($str, $title);
			$tpl->assign('message', $str);
			
		} else {
			$gw_alias = only_word(GET('gw_alias'));
			$gw_item_id = (int)GET('item');

			
			if ($step == 'redirect') {
				$arr = GET();
				$arr = array_map(array($this->helper, 'htmlspecialchars'), $arr);
				$arr['user_hash'] = $this->user->nonce;
				$arr['action'] = 'checkout_set_store_and_redirect';
				
				$tpl->assign('source_array', json_encode($arr));
			} elseif ($step == 'choose_payment_method') {
				if ($this->webcash->default_gateway and $this->webcash->default_item) {//если метод оплаты только один - сразу редирект в платежную систему
					redirect_to($this->webcash->site_url.'index.php?do=webcash&action=checkout&step=to_gateway&cs_key='.$cs_key.'&gw_alias='.$this->webcash->default_gateway.'&item='.$this->webcash->default_item);
				}
			} elseif ($step == 'to_gateway') {
				$html = $this->getGatewayForm($gw_alias, $gw_item_id, $cs_key);
				
				$tpl->assign('gateway_form', $html);
			}
			
			
			$tpl->assign('next_step', $this->getNextStep($step));
		}

		
		$tpl->load_template('/modules/webcash/checkout_index.tpl');
	
		$tpl->compile('content');
		return $tpl->result['content'];
	}
	
	public function getDataStore($cs_key) {
		if ($checkout_store = safe_array_access($_SESSION, self::DATA_STORE_NAME, $cs_key)) {
			return $checkout_store;
		} else {
			return $this->webcash->exitMsg('Нет данных в таблице платежного шлюза. Попробуйте повторить процесс оплаты сначала.');
		}
	}
	
	public function getInvoiceRowInSuccessMessage($invoice_id, $plg_alias) {
		if (!$invoice_id) {
			if ($cs_key = SESSION(self::DATA_STORE_CURRENT_KEY)) {
				if ($checkout_store = $this->getDataStore($cs_key)) {
					$invoice_id = $checkout_store['invoice_id'];	
				}
			}
		}
		
		if (!$invoice_id) {
			$invoice_id = $this->db->selectCell("
				SELECT MAX(id)
				FROM {$this->webcash->gateway_invoices_table}
				WHERE ip = '{$this->user->long_ip}'"
			);
		}
		
		if ($invoice_id) {
			if ($invoice_row = $this->webcash->getRowById($this->webcash->gateway_invoices_table, $invoice_id)) {
				if ($invoice_row['user_id'] == $this->user->id and $invoice_row['area_alias'] == $plg_alias) {
					return $invoice_row;
				}
				
				trigger_error('Ошибочный(е) параметр(ы) инвойса', E_USER_ERROR);
			}
			
			trigger_error('Нет такого инвойса', E_USER_ERROR);
		}
		
		trigger_error('Не указан ID инвойса', E_USER_ERROR);
	}
	
	public function	updateInvoiceCheckoutstore($checkout_store, $invoice_id) {
		$str = serialize($checkout_store);
		$str = $this->db->escape($str);
		
		return $this->db->query("
			UPDATE {$this->webcash->gateway_invoices_table}
			SET checkout_store = '{$str}'
			WHERE id = '{$invoice_id}'
			LIMIT 1"
		);
	}
	
	public function	successCheckoutUrl($invoice_id = 0, $cs_key = '', $end_params = '') {
		$url = $this->webcash->site_url.$this->config->checkout_success_url;
		
		if ($invoice_id) {
			$url .= '&invoice_id='.$invoice_id;
			$url .= '&cs_key='.$cs_key;
		}
		
		$url .= $end_params;
		
		return $url;
	}
	
	public function	failCheckoutUrl($invoice_id = 0, $cs_key = '') {
		$url = $this->webcash->site_url.$this->config->checkout_fail_url;
		
		if ($invoice_id) {
			$url .= '&invoice_id='.$invoice_id;
			$url .= '&cs_key='.$cs_key;
		}
		
		return $url;
	}
	
	public function getGatewayProcessingUrl($gw_alias) {
		return $this->webcash->site_url.'index.php?do=webcash&action=gateway_processing&gw_alias='.$gw_alias;
	}
	
	public function execGatewayProcessing($gw_alias) {
		if ($instance = $this->webcash->getAddonInstanceByAlias($gw_alias) and method_exists($instance, 'processing')) {
			$instance->processing();
		}
	}
	
	public function gatewaySuccessPayment($invoice_row, $payment_row) {
		$this->db->query("UPDATE {$this->webcash->gateway_invoices_table} SET state = 1 WHERE id = '{$invoice_row['id']}' LIMIT 1");
		
		if ($plg_alias = safe_array_access($payment_row, 'area_alias')) {
			$this->webcash->callPluginMethod($plg_alias, 'checkoutSuccessPayment', false, true, $invoice_row, $payment_row);
		}
	}
	
	public function saveTwoTblsRelItemId($rel_item_id, $id) {
		$rel_item_id = (int)$rel_item_id;
		$id = (int)$id;
		if ($this->db->query("UPDATE {$this->webcash->gateway_payments_table} SET rel_item_id = '{$rel_item_id}' WHERE id = '{$id}' LIMIT 1")) {
			return $this->db->query("
				UPDATE {$this->webcash->gateway_invoices_table}
				SET rel_item_id = '{$rel_item_id}'
				WHERE id = 
				(
					SELECT invoice_id
					FROM {$this->webcash->gateway_payments_table}
					WHERE id = '{$id}'
					LIMIT 1
				)
				LIMIT 1"
			);
		}
	}
	
}