<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

class FileUpload extends Application
{
	protected $allowed_extensions = array('jpg', 'jpeg', 'gif', 'png');
	protected $max_file_size = 0;
	protected $error_messages = array(
		1 => 'Загруженный файл превышает директиву upload_max_filesize в php.ini',//The uploaded file exceeds the upload_max_filesize directive in php.ini
		2 => 'Загруженный файл превышает директиву MAX_FILE_SIZE, указанную в HTML-форме.',//The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form
		3 => 'Файл был загружен только частично',//The uploaded file was only partially uploaded
		4 => 'Файл не загружен',//No file was uploaded
		6 => 'Отсутствует временная папка',//Missing a temporary folder
		7 => 'Не удалось записать файл на диск',//Failed to write file to disk
		8 => 'Расширение PHP остановило загрузку файла',//A PHP extension stopped the file upload
	);
	
	public function exec($file, $dest_path, $max_file_size = 0) {
		if ($file) {
			if ($file['error'] === UPLOAD_ERR_OK) {
				$ext = pathinfo($file['name'], PATHINFO_EXTENSION);
				if (!in_array($ext, $this->allowed_extensions))
					$this->helper->showMsgErrorNotTranslate(__('Разрешены только следующие расширения файлов: ').implode(', ', $this->allowed_extensions));
				
				
				//LAST
				//$newFileName = md5(time() . $fileName) . '.' . $fileExtension;
				
				if ($max_file_size)
					$this->max_file_size = $max_file_size;
				
				if ($this->max_file_size and $file['size'] > $this->max_file_size)
					$this->helper->showMsgError('Максимально допустимый вес файла: '.formatsize($this->max_file_size));
				
				
				$filename = translit_filename($file['name']);
				
				if ($filename = $this->uploadFile($filename, $dest_path, $file['tmp_name'])) {
					
					return $filename;
				} else {
					$this->helper->showMsgError('Ошибка при загрузке файла');
				}
				
			} else {
				foreach ($this->error_messages as &$value) {
					$value = lang($value);
				}
				
				$this->helper->showMsgError($this->error_messages[ $file['error'] ]);
			}
		}
	}
	
	public function uploadFile($origin, $dest, $tmp_name) {
		$origin = strtolower(basename($origin));
		$fulldest = $dest.$origin;
		$filename = $origin;
		
		for ($i = 1; file_exists($fulldest); $i++) {
			$fileext = (strpos($origin, '.') === false ? '' : '.'.substr(strrchr($origin, '.'), 1));
			$filename = substr($origin, 0, strlen($origin) - strlen($fileext)).'['.$i.']'.$fileext;
			$fulldest = $dest.$filename;
		}
		
		if (move_uploaded_file($tmp_name, $fulldest)) {
			return $filename;
		}
		
		return false;
	}	
	
}