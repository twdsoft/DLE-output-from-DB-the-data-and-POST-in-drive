<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

class NewTemplates extends \dle_template
{
	protected $webcash = null;
	protected $variables = array();
	protected $template_loaded = false;
	
	public function __get($property) {
		if (is_null($this->webcash))
			$this->webcash = WebCash::instance();
		
		if (isset($this->{$property}) or property_exists($this, $property)) {
			return $this->{$property};
		} elseif ($this->webcash->{$property}) {
			return $this->webcash->{$property};
		}
	}
	
	public function set($name, $var) {
		parent::set($name, $var);
		
		if (!$this->template_loaded and preg_match('#^\{(\S+)\}$#', $name, $matches)) {
			$this->assign($matches[1], $var);
		}
	}
	
	public function load_template($tpl_name) {
		$this->template_loaded = true;
		
		$result = parent::load_template($tpl_name);
		
		$this->template = $this->langTpl($this->template);
		
		
		$template_data = array(
			'USER' => array(
				'id' => $this->user->id,
				'group' => $this->user->group,
				'is_logged' => $this->user->isLoggedIn(),
			),
		);
		
		$template_data = $this->webcash->helper->arrayMergeRecursiveEx($template_data, $this->variables);
		
		$this->template = $this->webcash->twig->render(
			$this->template,
			$template_data
		);
		
		
		$this->copy_template = $this->template;
		
		return $result;
	}
	
	public function assign($name, $value) {
		$this->variables[$name] = $value;
	}
	
	private function langTpl($content) {
		if (strpos($content, '__(\'') !== false) {
			$content = preg_replace_callback('#__\(\'(.+)\'\)#Us', function ($matches) {
				return __($matches[1]);
			}, $content);
		}
		
		return $content;
	}
}