<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

class Config extends Application
{
	private $filepath;
	private $cache_filepath;
	private $cfg_parsed_array = array();
	private static $instance;
	
    public static function instance() {
        if (!isset(self::$instance)) {
            self::$instance = new self();
        }
        return self::$instance;
    }
	
	public function __construct() {
		$this->filepath = ENGINE_DIR.'/data/config.webcash.php';
		$this->cache_filepath = ENGINE_DIR.'/data/config.webcash.cache.php';
		
		$this->readConfigFile();
	}
	
	public function __get($name) {
		if ($section = $this->exists($name)) {
			return $this->getValueBySectionAndKey($section, $name);
		}
		
		return parent::__get($name);
	}
	
	public function setSection($section, $array) {
		if (is_array($array)) {
			if ($this->cfg_parsed_array[$section] = $array) {
				return $this->writeConfigFile();
			}
		}
		
		return $result;
	}
	
	public function setValue($key, $value, $write = true) {
		foreach ($this->cfg_parsed_array as &$array) {
		
			if (isset($array[$key]) and $array[$key] != $value) {
				$array[$key] = $value;
				return $write ? $this->writeConfigFile() : true;
			}
		}
		
		return false;
	}
	
	public function wrapUpdateSection($section = '', $source_array = array()) {
		$source_array or $source_array = $_POST;
		
		if (!$section and $str = safe_array_access($source_array, 'action')) {
			$section = strtoupper(str_replace(array('ajax.', '_settings'), '', $str));
		}
		
		if (isset($this->cfg_parsed_array[$section])) {
			if ($data = safe_array_access($source_array, 'config_fields')) {
				return $this->updateSection($section, $data);
			}
		}
	}
	
	public function updateSection($section, $data = array()) {
		$result = false;
		
		if ($data) {
			foreach ($data as $key => $value) {
				
				if ($this->setValueBySectionAndKey($section, $key, $value)) {
					$result = true;
				}
			}
		}
		
		if ($result) {
			return $this->writeConfigFile();
		}

		return $result;
	}
	
	public function setSettings($source_array) {
		$result = false;
		
		if (isset($source_array['config_fields'])) {
			$data = $source_array['config_fields'];
		} else {
			$data = array();
		}
		
		if (!empty($data)) {
			foreach ($data as $key => $value) {
			
				if ($section = $this->exists($key) and $this->{$key} != $value) {
					if ($this->setValueBySectionAndKey($section, $key, $value, false)) {
						$result = true;
					}
				}
			}
		}
		
		if ($result) {
			return $this->writeConfigFile();
		}

		return $result;
	}
	
	public function writeConfigFile() {
		return $this->helper->writeArrayToFile($this->filepath, $this->cfg_parsed_array);
	}

	public function getValueBySectionAndKey($section, $key) {
		if (isset($this->cfg_parsed_array[$section][$key])) {
			return $this->cfg_parsed_array[$section][$key];
		}
	}

	public function getSection($section) {
		return $this->cfg_parsed_array[$section];
	}
	
	public function exists($name) {
		foreach ($this->cfg_parsed_array as $section => $array) {

			if ($section != 'GATEWAYS' and $section != 'CLASSES' and isset($array[$name])) {
				return $section;
			}
		}
		
		return false;
	}
	
	private function setValueBySectionAndKey($section, $key, $value) {
		if (isset($this->cfg_parsed_array[$section][$key]) and $this->cfg_parsed_array[$section][$key] != $value) {
			$this->cfg_parsed_array[$section][$key] = $value;
			
			return true;
		}
		
		return false;
	}

	private function readConfigFile() {
		if (file_exists($this->cache_filepath) and filemtime($this->filepath) < filemtime($this->cache_filepath)) {
			$this->cfg_parsed_array = unserialize(file_get_contents($this->cache_filepath));
		} else {
			require $this->filepath;
			
			$this->cfg_parsed_array = $webcash_config;
			
			if ($file = fopen($this->cache_filepath, 'w')) {
				fwrite($file, serialize($this->cfg_parsed_array));
				fclose($file);
			}
		}
	}
}