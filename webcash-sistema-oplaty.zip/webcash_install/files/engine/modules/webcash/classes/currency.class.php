<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

class Currency extends Application
{
	const MAIN_CURRENCY = 'RUB';
	
	private $xml = null;
	
	public function currCnvDeclension($arg, $convert_encoding = true) {
		$arg = $this->currCnv($arg);
		
		if ($str = safe_array_access($this->config->currencies, $this->user->currency, 'declension')) {
			if ($convert_encoding)
				$str = __($str);
			
			$arg .= ' '.$this->webcash->declension($arg, $str);
		}
		
		return $arg;
	}
	
	public function currCnvShort($arg) {
		$arg = $this->currCnv($arg);
		
		if ($str = safe_array_access($this->config->currencies, $this->user->currency, 'short')) {
			$arg .= ' '.__($str);
		}
		
		return $arg;
	}
	
	public function currCnv($arg) {
		if ($this->user->currency and $this->user->currency != $this->config->main_currency) {
			$arg = $this->currencyConverter($arg, $this->config->main_currency, $this->user->currency);
		}
		
		if (strpos($arg, '.') !== false) {
			$arg = rtrim(rtrim($arg, '0'), '.');
		} elseif (strpos($arg, ',') !== false) {
			$arg = rtrim(rtrim($arg, '0'), ',');
			$arg = str_replace(',', '.', $arg);
		}
		
		return $arg;
	}
	
	public function getCurrenciesList() {
		$arr = array();
		foreach ($this->config->currencies as $key => $value) {
			$arr[$key] = __($value['title']);
		}
		return $arr;
	}
	
	public function convertMainCurrencyToRub($value) {
		return $this->toRub($value, $this->config->main_currency);
	}
	
	public function convertMainCurrencyTo($value, $currency_to) {
		return $this->currencyConverter($value, $this->config->main_currency, $currency_to);
	}
	
	public function currencyConverter($value, $currency_from, $currency_to) {
		if ($currency_from != $currency_to) {
			$value = $this->toRub($value, $currency_from);
			
			$value = $this->fromRub($value, $currency_to);
		}
		
		return $value;
	}
	
	public function toRub($value, $currency) {
		if ($currency != self::MAIN_CURRENCY) {
			foreach ($this->getRatesXml()->Valute as $item) {
				if ($item->CharCode == $currency) {
					if ($item->Nominal == 1) {
						$value = $value * $item->Value;
					} else {
						$value = $value * $item->Value / $item->Nominal;
						$value = round($value, 3);
					}
					
					break;
				}
			}
		}
		
		return $value;
	}
	
	public function fromRub($value, $currency) {
		if ($currency != self::MAIN_CURRENCY) {
			foreach ($this->getRatesXml()->Valute as $item) {
				if ($item->CharCode == $currency) {
					if ($item->Nominal == 1) {
						$value = $value / $item->Value;
					} else {
						$value = $value * $item->Nominal / $item->Value;
					}
					
					$value = round($value, 3);
					break;
				}
			}
		}
		
		return $value;
	}
	
	public function getRatesXml() {
		if (!$this->xml) {
			$file = $this->webcash->cache_path.'cbr.xml';
			
			if (!file_exists($file) or time() - filemtime($file) > 120 * 60) {//120 минут
				$this->http->loadUrl($this->config->currencies_rates_source, array(), $file);
			}
			
			if (file_exists($file)) {
				$response = file_get_contents($file);
			}
			
			$this->xml = simplexml_load_string($response);
		}
		
		return $this->xml;
	}
	
	public function getRatesXmlSourceList() {
		$arr = array(
			'http://www.cbr.ru/scripts/XML_daily.asp',
			'http://www.cbr-xml-daily.ru/daily_utf8.xml',
		);
		return array_combine($arr, $arr);
	}

}