<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

(defined('DATALIFEENGINE') and defined('LOGGED_IN')) or exit('Access Denied');

@error_reporting(E_ALL ^ E_NOTICE);
@ini_set('display_errors', true);
@ini_set('html_errors', false);
@ini_set('error_reporting', E_ALL ^ E_NOTICE);

define('IS_AJAX', true);


if (!$webcash->user->isAdminGroup())
	$webcash->helper->showMsgError('Доступ вашей группе запрещен');

if (!$action = POST('action'))
	$webcash->helper->showMsgError('Не указан тип операции');

if (!$str = POST('user_hash') or $str != $webcash->user->nonce) 
	$webcash->helper->showMsgError('Доступ запрещен');


$subaction = POST('subaction');


if ($gw_alias = only_word(POST('gw_alias'))) {
	require_once $webcash->module_path.'gateways/'.$gw_alias.'/admin/'.$gw_alias.'.ajax.php';
} elseif ($plg_alias = only_word(POST('plg_alias'))) {
	require_once $webcash->module_path.'plugins/'.$plg_alias.'/admin/'.$plg_alias.'.ajax.php';
} 


if ($action == 'ajax.from_tab'.Admin_Panel::CONFIG_TAB and $subaction) {
	
	if ($subaction == 'config') {
		$post_fields = $webcash->helper->fixMissedElements(POST('fix_missed_integer'), $_POST, 0);
		$arr = $webcash->helper->arrayMergeRecursiveEx($webcash->config->getSection('MAIN'), $post_fields['config_fields']);
		$was_changed = $webcash->helper->arrayDiffRecursive($webcash->config->getSection('MAIN'), $arr);
		
		if (!empty($arr['balance_in_xfield'])) {//баланс будет храниться в дополнительном поле профиля
			$webcash->userxfields->addXfield($webcash->user->getBalanceXfieldLine());
			$webcash->user->deleteUserTableColumn();
		} else {//баланс будет храниться в отдельном поле таблицы
			$webcash->userxfields->deleteXfield($webcash->config->balance_field_name);
			$webcash->user->addUserTableColumn();
		}
		
		if ($was_changed) {
			$webcash->config->updateSection('MAIN', $arr);
			$webcash->helper->showMsgOk('Данные обновлены');
		} else {
			$webcash->helper->showMsgError('Нет изменений');
		}
		
	} elseif ($subaction == 'copy_template_folder') {
		$themepath = totranslit($config['skin'], false, false);
		$fname = ROOT_DIR.'/templates/'.$themepath.'/';
		clearstatcache();
		
		if (!is_writable($fname)) {
			$webcash->helper->showMsgErrorNotTranslate(
				sprintf(
					lang('Каталог &laquo;%s&raquo; недоступен для записи'), str_replace(ROOT_DIR, '', $fname)
				)
			);
		}
		
		require_once $webcash->module_path.'admin/lib/xcopy/xcopy.php';
		
		copy_folder(ROOT_DIR.'/templates/Default/modules/webcash/', ROOT_DIR.'/templates/'.$themepath.'/modules/webcash/');
		
		if (file_exists(ROOT_DIR.'/templates/'.$themepath.'/modules/webcash/main_index.tpl'))
			$webcash->helper->showMsgOk('Папка &laquo;webcash&raquo; с шаблонами модуля скопирована.');
		else
			$webcash->helper->showMsgError('Ошибка при копировании папки с шаблонами модуля.');
		
	} elseif ($subaction == 'restore_hints') {
		if ($webcash->db->query("DELETE FROM {$webcash->adminsettings->table_a} WHERE param LIKE 'i_hide_hint_%'")) {
			$webcash->helper->showMsgOk('Подсказки восстановлены. Перезагрузка...', 'Информация', 'self');
		} else {
			$webcash->helper->showMsgError('Нет скрытых подсказок');
		}
	} elseif ($subaction == 'clean_cache_all') {
		clearstatcache();
		$str = str_replace(ROOT_DIR, '', $webcash->cache_path);
		
		if (!file_exists($webcash->cache_path)) {
			$webcash->helper->showMsgErrorNotTranslate(sprintf(lang('Каталог не существует: &laquo;%s&raquo;'), $str));
		} elseif (!is_writable($webcash->cache_path)) {
			$webcash->helper->showMsgErrorNotTranslate(sprintf(lang('Нет прав для изменения в каталоге: &laquo;%s&raquo;'), $str));
		} else {
			if ($webcash->helper->rmdir($webcash->cache_path)) {
				$webcash->helper->showMsgOk('Кэш модуля полностью очищен');
			} else {
				$webcash->helper->showMsgError('Не удалось очистить кэш модуля');
			}
		}
	} elseif ($subaction == 'clean_cache_twig') {
		clearstatcache();
		$str = str_replace(ROOT_DIR, '', $webcash->cache_path.WebCash::TWIG_CACHE_FOLDER);
		
		if (!file_exists($webcash->cache_path.WebCash::TWIG_CACHE_FOLDER)) {
			$webcash->helper->showMsgErrorNotTranslate(sprintf(lang('Каталог не существует: &laquo;%s&raquo;'), $str));
		} elseif (!is_writable($webcash->cache_path.WebCash::TWIG_CACHE_FOLDER)) {
			$webcash->helper->showMsgErrorNotTranslate(sprintf(lang('Нет прав для изменения в каталоге: &laquo;%s&raquo;'), $str));
		} else {
			if ($webcash->helper->rmdir($webcash->cache_path.WebCash::TWIG_CACHE_FOLDER)) {
				$webcash->helper->showMsgOk('Кэш шаблонизатора очищен');
			} else {
				$webcash->helper->showMsgError('Не удалось очистить кэш шаблонизатора');
			}
		}
	} elseif ($subaction == 'reset_all_addons_settings') {
		if ($arr = $webcash->config->getSection('GATEWAYS')) {
			foreach ($arr as $gw_alias) {
				$path = $webcash->module_path.'gateways/'.$gw_alias.'/';
				$webcash->helper->unlink($path.'settings_adm.dat.php');
				$webcash->helper->unlink($path.'settings.dat.php');
			}
		}
		
		if ($arr = $webcash->config->getSection('PLUGINS')) {
			foreach ($arr as $plg_alias) {
				$path = $webcash->module_path.'plugins/'.$plg_alias.'/';
				$webcash->helper->unlink($path.'settings_adm.dat.php');
				$webcash->helper->unlink($path.'settings.dat.php');
			}
		}
		
		$webcash->helper->showMsgOk('Настройки всех дополнений сброшены');
	}
	
} elseif ($action == 'ajax.from_tab'.Admin_Panel::GATEWAYS_TAB and $subaction) {//update gateway settings
	$addon_alias = only_word(POST('addon_alias'));
	
	if ($subaction == 'toggle_off' and $addon_alias) {
		if ($webcash->{$addon_alias}->writeCfgValue('on', 0))
			$webcash->helper->showMsgOk('Шлюз выключен. Перезагрузка...', 'Информация', 'self');
		else
			$webcash->helper->showMsgError('Не удалось выключить шлюз');
		
	} elseif ($subaction == 'toggle_on' and $addon_alias) {
		if ($webcash->{$addon_alias}->writeCfgValue('on', 1))
			$webcash->helper->showMsgOk('Шлюз включен. Перезагрузка...', 'Информация', 'self');
		else
			$webcash->helper->showMsgError('Не удалось включить шлюз');
		
	} elseif ($subaction == 'delete' and $addon_alias) {
		if ($arr = $webcash->config->getSection('GATEWAYS')) {
			foreach ($arr as $key => $name) {
				if ($addon_alias == $name) {
					unset($arr[$key]);
				}
			}
			
			if ($arr and is_array($arr)) {
				$arr = array_values($arr);
				$was_changed = $webcash->config->setSection('GATEWAYS', $arr);
			}
		}
		
		$webcash->{$addon_alias}->writeCfgValue('on', 0);
		
		if ($was_changed)
			$webcash->helper->showMsgOk('Шлюз удален. Перезагрузка...', 'Информация', 'self');
		else
			$webcash->helper->showMsgError('Не удалось удалить шлюз');
		
	} elseif ($subaction == 'update_ordering' and $ids = POST('ids')) {
		$ids = json_decode($ids, true);
		$ids = array_map('only_word', $ids);
		$was_changed = false;
		
		if ($ids and is_array($ids)) {
			$was_changed = $webcash->config->updateSection('GATEWAYS', $ids);
		}
		
		if ($was_changed)
			$webcash->helper->showMsgOk('Порядок сортировки успешно сохранен');
		else
			$webcash->helper->showMsgError('Нет изменений');
	} elseif ($subaction == 'delete_records_by_gateway' and $addon_alias) {
		if ($webcash->adminpanel->deleteRecordsByGateway($addon_alias)) {
			$webcash->helper->showMsgOk('Удалены записи для данного шлюза в двух таблицах. Перезагрузка...', 'Информация', 'self');
		} else {
			$webcash->helper->showMsgError('Нет изменений');
		}
	}
	
} elseif ($action == 'ajax.from_tab'.Admin_Panel::PLUGINS_TAB and $subaction) {
	$addon_alias = only_word(POST('addon_alias'));
	
	if ($subaction == 'toggle_off' and $addon_alias) {
		if ($webcash->{$addon_alias}->writeCfgValue('on', 0))
			$webcash->helper->showMsgOk('Плагин выключен. Перезагрузка...', 'Информация', 'self');
		else
			$webcash->helper->showMsgError('Не удалось выключить плагин');
		
	} elseif ($subaction == 'toggle_on' and $addon_alias) {
		if ($webcash->{$addon_alias}->writeCfgValue('on', 1))
			$webcash->helper->showMsgOk('Плагин включен. Перезагрузка...', 'Информация', 'self');
		else
			$webcash->helper->showMsgError('Не удалось включить плагин');
		
	} elseif ($subaction == 'delete' and $addon_alias) {
		if ($arr = $webcash->config->getSection('PLUGINS')) {
			foreach ($arr as $key => $name) {
				if ($addon_alias == $name) {
					unset($arr[$key]);
				}
			}
			
			if ($arr and is_array($arr)) {
				$arr = array_values($arr);
				$was_changed = $webcash->config->setSection('PLUGINS', $arr);
			}
		}
		
		$webcash->{$addon_alias}->writeCfgValue('on', 0);
		
		if ($was_changed)
			$webcash->helper->showMsgOk('Плагин удален. Перезагрузка...', 'Информация', 'self');
		else
			$webcash->helper->showMsgError('Не удалось удалить плагин');
	
	} elseif ($subaction == 'update_ordering' and $ids = POST('ids')) {
		$ids = json_decode($ids, true);
		$ids = array_map('only_word', $ids);
		$was_changed = false;
		
		if ($ids and is_array($ids)) {
			$was_changed = $webcash->config->updateSection('PLUGINS', $ids);
		}
		
		if ($was_changed)
			$webcash->helper->showMsgOk('Порядок сортировки успешно сохранен');
		else
			$webcash->helper->showMsgError('Нет изменений');
	}
	
} elseif ($action == 'ajax.from_tab'.Admin_Panel::UPGRADE_TAB and $subaction) {
	if (in_array($subaction, array('install','ignore')) and !empty($_POST['version'])) {
		$version = preg_replace('#[^\w\.]#', '', $_POST['version']);
		$was_changed = false;

		if ($subaction == 'install') {
			$arr = array(
				'loadfile' => $version,
				'currentversion' => $webcash->config->version,
			);
			$url = WebCash::UPDATES_API_URL.'&'.http_build_query($arr);
			$temp_filepath = $webcash->helper->mkdir($webcash->cache_path.'archives/').'upgrade.zip';
			
			if ($response = $webcash->http->loadUrl($url, array('code' => $webcash->config->secret_buyer_code))) {
				if (strpos($response, 'error|') === 0) {
					$response = str_replace('error|', '', $response);
					$webcash->helper->showMsgErrorNotTranslate($response);
				} else {
					file_put_contents($temp_filepath, $response);
					if (file_exists($temp_filepath)) {
						$was_changed = $webcash->adminpanel->installUpgrade($temp_filepath, $version);
					}
				}
			}

			if ($was_changed) {
				$webcash->config->setValue('version', POST('version'));
				$webcash->helper->showMsgOk('Обновление установлено. Перезагрузка...', 'Информация', 'self');
			} else {
				$webcash->helper->showMsgError('Ошибка при установке обновления');
			}
			
		} elseif ($subaction == 'ignore') {
			$webcash->config->setValue('ignored_update_version', POST('version'));
			$webcash->helper->showMsgOk('Обновление добавлено в игнорируемые. Перезагрузка...', 'Информация', 'self');
		}
	} elseif ($subaction == 'config' and !empty($_POST['config_fields'])) {
		if ($webcash->config->setValue('secret_buyer_code', POST('config_fields', 'secret_buyer_code'))) {
			$webcash->helper->showMsgOk('Данные обновлены');
		} else {
			$webcash->helper->showMsgError('Нет изменений');
		}
	} elseif ($subaction == 'reset_cache') {
		$cache_key = $webcash->adminpanel->getUpgradeCacheKey();
		if ($webcash->helper->unlink($webcash->cache_path.$cache_key.'.php')) {
			$webcash->helper->showMsgOk('Кэш сброшен. Перезагрузка...', 'Информация', 'self');
		} else {
			$webcash->helper->showMsgError('Перезагрузка...', 'Информация', 'self');
		}
	}
	
} elseif ($action == 'ajax.get_upgrades_info') {
	$text = '';
	if ($response = $webcash->http->loadUrl(WebCash::UPDATES_API_URL.'&currentversion='.$webcash->config->version)) {
		$data = json_decode($response, true);
		
		$cache_key = $webcash->adminpanel->getUpgradeCacheKey();
		$webcash->helper->putCache($cache_key, $response);

		if ($webcash->adminpanel->isActualUpgrade($data['version'])) {
			$title = '<sup style="color:red">'.lang('Есть обновления').'</sup>';
			$text = nl2br($data['description']);
			$webcash->helper->showMsgOkNotTranslate($text, $title);
		} else {
			$title = '<sup>'.lang('Нет').'</sup>';
			$text = '<h6>'.lang('Нет актуальных обновлений').'</h6>';
		}
	} else {
		$title = '<sup>'.lang('Ошибка').'</sup>';
		$text = '<sup>'.lang('Возникла ошибка в процессе проверки обновлений').'</sup>';
	}

	$webcash->helper->showMsgErrorNotTranslate($text, $title);

} elseif ($action == 'ajax.addon_settings' and $addon_alias = only_alias(POST('addon_alias'))) {//обновление настроек платежного шлюза или плагина
	$path = $webcash->{$addon_alias}->getPath();
	
	if ($webcash->{$addon_alias}->setSettings($_POST))
		$webcash->helper->showMsgOk('Параметры дополнения обновлены');
	else
		$webcash->helper->showMsgError('Нет изменений');
	
} elseif ($action == 'ajax.reset_addon_settings' and $addon_alias = only_alias(POST('addon_alias'))) {
	$path = $webcash->{$addon_alias}->getPath();
	
	if ($webcash->helper->unlink($path.'settings_adm.dat.php') and $webcash->helper->unlink($path.'settings.dat.php'))
		$webcash->helper->showMsgOk('Параметры дополнения сброшены. Перезагрузка...', 'Информация', 'self');
	else
		$webcash->helper->showMsgError('Нет изменений');
	
} elseif ($action == 'ajax.user_settings_save_param') {
	if (isset($_POST['val'])) {
		if ($_POST['val'] === 'true' or $_POST['val'] === true) {
			$val = 1;
		} elseif ($_POST['val'] === 'false' or $_POST['val'] === false) {
			$val = 0;
		} else {
			$val = (int)$_POST['val'];
		}
	} else {//значение не указано
		$val = 1;
	}
	
	$param = POST('param') ? POST('param') : POST('id');
	
	if ($webcash->adminsettings->saveParam($param, $val))
		$webcash->helper->showMsgError('Успешно сохранен параметр пользовательских настроек');
	else
		$webcash->helper->showMsgError('Ошибка при сохранении');
}

$webcash->helper->showMsgError('Ошибка при выполнении запроса');