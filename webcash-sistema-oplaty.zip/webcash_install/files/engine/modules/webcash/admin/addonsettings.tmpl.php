<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');
?>

<form action="" method="post" name="formAdmin" id="formAdmin" class="webcash_ajax_form form-horizontal well accordion addonsettings_wrap" autocomplete="off">
	<input type="hidden" name="action" value="ajax.addon_settings" />
	<input type="hidden" name="addon_alias" value="<?php echo $addon_alias; ?>" />
	<input type="hidden" name="user_hash" value="<?php echo $this->user->nonce; ?>" />

	<fieldset class="accordion-group" style="border:none">
		<h3 class="heading"><?php echo __('Установки дополнения'); ?> &laquo;<?php echo __($addon_sett->display_name); ?>&raquo;


		<?php if ($addon_tmpl_exists) { ?>
			<a class="accordion-toggle <?php if ($admin_sett['i_'.$addon_alias.'_accordion_1']) { ?>acc-in<?php } ?>" data-toggle="collapse" onclick="writeParam($(this), 'i_<?php echo $addon_alias; ?>_accordion_1', !$('#collapseSection1').hasClass('in'))" data-parent="#accordion" href="#collapseSection1" title="<?php echo __('Свернуть/развернуть'); ?>">&nbsp;</a>
		<?php } ?>

		</h3>
		
		<div class="<?php if ($addon_tmpl_exists) { ?>accordion-body collapse <?php if ($admin_sett['i_'.$addon_alias.'_accordion_1']) { ?>in<?php } ?>" id="collapseSection1" <?php } else { ?>"<?php } ?>>
		
		
			<div class="table-responsive">
				<table class="table table-striped">
				
				<?php
				$this->adminpanel->showRow(
					__('Дополнение включено'),
					__($addon_sett->description),
					$this->adminpanel->makeCheckbox(
						'data[on]',
						$addon_sett->on
					),
					'',
					$this->col_values
				);
				
				
				foreach ($addon_sett->ff as $key => $value) {
				
					if (!isset($addon_sett->cfg[$key])) {
						$addon_sett->set("cfg|{$key}", null);
					}
					
					
					if (empty($value['name']))
						$value['name'] = 'data['.$key.']';
					if (!isset($value['tag_part']))
						$value['tag_part'] = '';
					if (!isset($value['tag_part2']))
						$value['tag_part2'] = '';
					if (!isset($value['label']))
						$value['label'] = '';
					if (empty($value['count']))
						$value['count'] = ($value['type'] == 'radio') ? 2 : 1;
					
					
					if ($value['type'] == 'html') {
		
						echo $value['content'];
					
					} elseif ($value['type'] == 'custompos_blocks') {
					
						$str = $this->getPath().'admin/'.$addon_alias.'.tmpl.blocks.custompos'.only_alias($value['content']).'.php';
						
						if (file_exists($str)) {
							ob_start();
							require $str;
							$result = ob_get_clean();
							echo str_replace(PHP_EOL, "
							", $result);
						}
					
					} elseif ($value['type'] == 'separator') {
						
						$this->adminpanel->showSeparator();
						
					} elseif ($value['type'] == 'hint') { ?>
					
						<tr><td colspan="2"><?php echo $this->adminpanel->hint($value['name'], $value['hint'], $value['translate']); ?></td></tr>
					
					<?php } else {
					
					
						$field = '';
						
						if ($value['type'] == 'checkbox') {
						
							$field = $this->adminpanel->makeCheckbox($value['name'], $addon_sett->cfg[$key], $value['tag_part']);
						
						} elseif ($value['type'] == 'radio') {
							
							for ($i = 0; $i < $value['count']; $i++) {
								$field .= '
								<label class="radio-inline">
									<input type="radio" name="'.$value['name'].'" value="'.$value['value'][$i].'" '.($addon_sett->cfg[$key] == $value['value'][$i] ? 'checked' : '').' '.$value['tag_part'].' /> '.$value['label'][$i].'
								</label>';
							}
							
							$field .= '<span class="clearfix"></span>';
							
							if (!empty($value['hint2']))
								$field .= '<span class="help-block">'.$value['hint2'].'</span>';
	
						} elseif ($value['type'] == 'select') {
						
							$field = '<select name="'.$value['name'].'" '.$value['tag_part'].' class="uniform">';
							
							if (!empty($value['step'])) {
								
								for ($i = $value['start']; $i <= $value['end']; $i += $value['step']) {
									$field .= '<option value="'.$i.'" '.($addon_sett->cfg[$key] == $i ? 'selected' : '').'>'.$i.'</option>';
								}
								
							} else {
							
								for ($i = 0; $i < count($value['value']); $i++) {
									$field .= '<option value="'.$value['value'][$i].'" '.safe_array_access($value, 'attribs', $i).' '.($addon_sett->cfg[$key] == $value['value'][$i] ? 'selected' : '').'>'.(isset($value['label'][$i]) ? $value['label'][$i] : $value['value'][$i]).'</option>';
								}
							}
							
							$field .= '
							</select>
							<span class="clearfix"></span>
							'.$value['tag_part2'];

						} elseif ($value['type'] == 'text') {
						
							$field = $this->adminpanel->makeInputText($value['name'], $addon_sett->cfg[$key], $value['tag_part']);
							
						} elseif ($value['type'] == 'textarea') {
						
							$field = '<textarea name="'.$value['name'].'" class="classic width-650" '.$value['tag_part'].'>'.$addon_sett->cfg[$key].'</textarea>';
							
							if (!empty($value['hint2']))
								$field .= '<span class="help-block">'.$value['hint2'].'</span>';
							
						} elseif ($value['type'] == 'ajax_button') {
						
							$field = '<a href="#" data-do="ajax-webcash" data-vars="action='.$this->checkPluginOrGateway('ajax.plugin.', 'ajax.gateway.').$key.'|'.$this->checkPluginOrGateway('plg_alias', 'gw_alias').'='.$addon_sett->alias.'" '.$value['tag_part'].' class="btn bg-brown-600 btn-sm btn-raised legitRipple">'.__($value['label']).'</a>';
							
						} elseif ($value['type'] == 'spinedit') {
						
							$field .= '
							<div '.$value['tag_part'].'>
								<input type="text" name="'.$value['name'].'" value="'.$addon_sett->cfg[$key].'" '.$value['tag_part2'].'>
								<button type="button" class="ui-spinner-up"></button>
								<button type="button" class="ui-spinner-down"></button>
							</div>';
							
							if (!empty($value['hint2']))
								$field .= '<span class="help-block">'.$value['hint2'].'</span>';
						}
						
						
						
						$this->adminpanel->showRow(
							__($value['title']),
							__($value['hint']),
							$field,
							safe_array_access($value, 'container_addon'),
							$this->col_values,
							(int)safe_array_access($value, 'required')
						);
						
						
					}
				}
				
				
				
				if ($addon_sett->access_can_managed) {
				
					$usergroups_rows = array(0 => __('Без ограничений'));
					
					foreach ($this->dle->user_group as $value) {
						if ($value['id'] != User::GUEST_USERGROUP_ID)
							$usergroups_rows[$value['id']] = $value['group_name'];
					}
					
					$this->adminpanel->showRow(
						__('Ограничение по группе'),
						__('Минимальный требуемый уровень группы, которым разрешен доступ к дополнению на сайте'),
						$this->webcash->adminpanel->makeDropdown(
							$usergroups_rows,
							'data[required_usergroup]',
							$addon_sett->required_usergroup
						),
						'',
						$this->col_values
					);
				
				}
				
				
				$str = $this->getPath().'admin/'.$addon_alias.'.tmpl.blocks.php';
				if (file_exists($str)) {
					require $str;
				}
				/** //LASTDELETE
				if (file_exists($str)) {
					ob_start();
					require $str;
					$result = ob_get_clean();
					echo str_replace(PHP_EOL, "
					", $result);
				}
				/**/
				?>
	
	

				</table>
			</div><!--END <div class="table-responsive">-->
			
			<div class="panel-footer">
			
				<div class="col-sm-12 col-md-3"></div>
				
				<div class="col-sm-12 col-md-6 text-center">
					<button class="btn bg-teal btn-raised btn-green" type="submit">
						<i class="fa fa-floppy-o position-left"></i><?php echo __('Сохранить'); ?>
					</button>
					
				</div>
					
				<div class="col-sm-12 col-md-3">
					<div class="pull-right sepV_b">
						<a href="#" data-do="ajax-webcash" data-vars="action=ajax.reset_addon_settings|addon_alias=<?php echo $addon_alias; ?>" data-confirm="1" class="btn btn-mini"><?php echo __('Сбросить настройки'); ?></a>
						<span class="label label-info hasTip" title="<?php echo __('Конфигурация дополнения будет сброшена к первоначальным настройкам.'); ?>">?</span>
					</div>
				</div>
				
			</div>
			
		
		</div><!--END <div class="accordion-body collapse ">-->


	</fieldset>

</form>


<?php
$str = $this->getPath().'admin/'.$addon_alias.'.tmpl.php';
if (file_exists($str))
	require $str;
?>