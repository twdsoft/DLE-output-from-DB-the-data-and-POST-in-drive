<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

$html = '';
if (GET('action') == 'addonsett' and $plg_alias = only_word(GET('plg_alias')) and safe_array_access($webcash->getPlugins(true), $plg_alias)) {
	if ($instance = $webcash->getAddonInstanceByAlias($plg_alias) and method_exists($instance, 'renderSettingsPanel')) {
		$html = $instance->renderSettingsPanel();
		echo $html;
	}
}

if (!$html or Admin_Panel::SHOW_LIST_FOR_ADDON_EDITING) {
?>

<form action="" class="webcash_ajax_form form-horizontal" method="post" autocomplete="off">
	<div class="panel panel-flat">
		<div class="panel-body">
		
			<?php echo $webcash->adminpanel->hint(__FILE__.'1', 'Плагин — дополнение, для добавления новых функций и возможностей к модулю.'); ?>
			
			
            <?php if ($rows = $webcash->getPlugins(true)) { ?>
			
			

			<div class="table-responsive">

				<table class="table table-xs table-hover">
					<thead>
						<tr>
							<th>&nbsp;</th>
							<th><?php echo __('Название'); ?></th>
							<th><?php echo __('Описание'); ?></th>
							<th><?php echo __('Алиас'); ?></th>
							<th class="text-center"><?php echo __('Статус'); ?></th>
							<th style="width: 80px"><?php echo __('Действие'); ?></th>
						</tr>
					</thead>
					<tbody class="go-sortable">

					<?php
					foreach ($rows as $row) {
					
						$instance = $webcash->{$row['alias']};
						
						$edit_start_tag = '<a href="'.$instance->getAddonSettingsUrl().'" title="'.__('Редактировать настройки плагина').'">';
						
						$description_html = __($row['description']);
						if (method_exists($instance, 'renderIndex')) {
							$description_html = '<a href="'.$instance->getPluginFrontendUrl().'" title="'.__('Перейти на страницу плагина на сайте').'">'.$description_html.'</a>';
						}
						
						$additional_items = method_exists($instance, 'getPluginsListDropdownItems') ? $instance->getPluginsListDropdownItems() : '';
						
						echo '
						<tr id="'.$row['alias'].'">
							<td class="go-sortable-handle" title="'.__('Нажмите и перетащите для изменения порядка').'"></td>
							<td>'.$edit_start_tag.__($row['display_name']).'</a></td>
							<td>'.$description_html.'</td>
							<td>'.$row['alias'].'</td>
							<td class="text-center">
								'.($row['on'] ? '<span title="'.__('Плагин включен').'" class="text-success tip"><b><i class="fa fa-check-circle"></i></b></span>' : '<span title="'.__('Плагин отключен').'" class="text-danger tip"><b><i class="fa fa-exclamation-circle"></i></b></span>').'
							</td>
							
							<td class="text-center">
								<div class="btn-group">
									<a href="#" class="dropdown-toggle nocolor" data-toggle="dropdown-webcash" aria-expanded="true"><i class="fa fa-bars"></i><span class="caret"></span></a>
									<ul class="dropdown-menu text-left pull-right">
										<li>'.$edit_start_tag.'<i class="fa fa-pencil-square-o position-left"></i>'.__('Конфигурация').'</a></li>
										<li><a href="#" data-do="ajax-webcash" data-vars="action=ajax.from_tab'.Admin_Panel::PLUGINS_TAB.'|subaction='.($row['on'] ? 'toggle_off' : 'toggle_on').'|addon_alias='.$row['alias'].'" title="'.($row['on'] ? __('Выключить плагин') : __('Включить плагин')).'"><i class="fa fa '.($row['on'] ? 'fa-check-circle text-success' : 'fa-exclamation-circle text-danger').' position-left"></i>'.($row['on'] ? __('Отключить') : __('Включить')).'</a></li>
										
										'.(method_exists($instance, 'renderIndex') ? '<li><a href="'.$instance->getPluginFrontendUrl().'" title="'.__('Перейти на страницу плагина на сайте').'"><i class="fa fa-eye position-left"></i>'.__('Страница на сайте').'</a></li>' : '').'
										
										'.$additional_items.'
										
										<li class="divider"></li>
										<li><a href="#" data-do="ajax-webcash" data-vars="action=ajax.from_tab'.Admin_Panel::PLUGINS_TAB.'|subaction=delete|addon_alias='.$row['alias'].'" data-confirm="1" title="'.__('Удалить плагин').'"><i class="fa fa-trash-o position-left text-danger"></i>'.__('Удалить').'</a></li>
									</ul>
								</div>
							</td>
						</tr>';
					}
					?>
					
					</tbody>
				</table>
				
			</div>
			
			
            
            
			<?php } else { ?>
				<?php echo __('Нет записей'); ?>
			<?php } ?>
		
		
		</div>
		
		
		
	</div>
	<div class="buttons_wrap">
		<input type="hidden" name="action" value="ajax.from_tab<?php echo Admin_Panel::PLUGINS_TAB; ?>" />
		<input type="hidden" name="user_hash" value="<?php echo $webcash->user->nonce; ?>" />
		
		<button type="button" class="btn bg-teal btn-raised position-left btn-green" onclick="return saveOrderingOnClick($(this))" data-vars="action=ajax.from_tab<?php echo Admin_Panel::PLUGINS_TAB; ?>|subaction=update_ordering">
			<i class="fa fa-floppy-o position-left"></i><?php echo __('Сохранить порядок сортировки плагинов'); ?>
		</button>		
		
	</div>
</form>

<script>
$(document).ready(function() {
	$("tbody.go-sortable").sortable();
});	
</script>
<?php } ?>