<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

class Admin_Filtration extends Application
{	
	protected $filter_data = array();
	
	public function makeFiltrationLinkByKey($key, $encore = '--//--') {
		if ($table_column = safe_array_access($this->filter_data, 'tbl_columns', $key) and $row = safe_array_access($this->filter_data, 'row')) {
			$fieldname = $this->getFieldname($key);
			
			$value = $filter_val = $row[$fieldname];
			$filter_val = urlencode($filter_val);
			
			if ($fieldtype = $this->getDatetimeFieldType($key)) {
				if ($value > 0) {
					if ($fieldtype == 'timestamp')
						$value = strtotime($value);
					
					$filter_val = date('d.m.Y', $value);
					
					if ($encore === '--//--')
						$encore = langdate('d.m.Y H:i', $value);
					
				} else {
					$filter_val = 0;
				}
			} else {
				$str = $this->adminpanel->removeAliasPrefix($key);
				
				if ($encore === '--//--') {
					if ($str == 'ip') {
						$encore = long2ip($value);
					}
				}
			}
			
			if ($value and $encore === '--//--')
				$encore = $value;
			
			return '<a '.$this->makeFiltrationUrl('&val['.$key.']='.$filter_val).' title="'.__('Фильтрация записей').' '.$table_column['title_part'].'">'.$encore.'</a>';
		}
	}
	
	public function makeFiltrationUrl($ending_part) {
		global $active_tab, $active_alias;
		
		if ($active_tab == Admin_Panel::PLUGINS_TAB and !empty($active_alias))
			$ending_part .= '&alias='.$active_alias;
		
		$beginning_part = '';
		if ($addon_alias = safe_array_access($this->filter_data, 'addon_alias')) {
			$beginning_part = '&action=addonsett&plg_alias='.$addon_alias.(($a = (int)GET('tab2')) ? '&tab2='.$a : '');
		}
		
		if ($arr = GET('val')) {
			foreach ($arr as $key => $value) {
				if (strpos($ending_part, $key) === false) {
					$ending_part .= '&val['.$key.']='.$value;
				}
			}
		}
		
		return $this->adminpanel->buildChangeTabTagPart($active_tab, $beginning_part.'&filter=field'.$ending_part);
	}
	
	public function makeFiltrationSQL($beginning_part = "WHERE", $vars = null) {
		
		$vars or $vars = GET();
		
		if (safe_array_access($vars, 'filter') == 'field' and $filters_array = safe_array_access($vars, 'val')) {
			$filter_params = array();
			
			foreach ($filters_array as $filter_key => $filter_val) {
				
				$filter_key = preg_replace('#[^\w,\.\|\-]#i', '', $filter_key);
				$filter_val = preg_replace('#[^0-9a-zA-Zа-яА-Я_,\.\|\-\/ @]#u', '', $filter_val);
				
				//например, b.ip
				$key_prefix = substr($filter_key, 0, 1);//"b"
				$cutted_key = substr($filter_key, 1);//".ip"
				$min = $max = '';
				
				if ($fieldtype = $this->getDatetimeFieldType($filter_key)) {//поле для даты
					if (strpos($filter_val, '|') !== false) {
						$arr = explode('|', $filter_val);
						$arr = array_map('strtotime', $arr);
						list($min, $max) = $arr;
					} else {
						$min = $max = strtotime($filter_val);
					}
					
					if ($min)
						$min = date('Y-m-d 00:00:01', $min);
					if ($max)
						$max = date('Y-m-d 23:59:59', $max);
					
					if ($fieldtype == 'unixtime') {
						if ($min)
							$min = strtotime($min);
						if ($max)
							$max = strtotime($max);
					}
					
					if ($min and $max) {
						if ($min < $max) {
							$filter_params[] = "{$filter_key} BETWEEN '{$min}' AND '{$max}'";
						} elseif ($min == $max) {
							$filter_params[] = "{$filter_key} = '{$min}'";
						}
					} elseif ($min) {
						$filter_params[] = "{$filter_key} >= '{$min}'";
					} elseif ($max) {
						$filter_params[] = "{$filter_key} <= '{$max}'";
					} else {
						$filter_params[] = "{$filter_key} = '0000-00-00 00:00:00'";
					}
				} else {
					if (strpos($filter_val, '|') !== false) {
						$arr = explode('|', $filter_val);
						$arr = array_map('only_alias', $arr);
						list($min, $max) = $arr;
						
						if ($min and $max) {
							if ($min < $max) {
								$filter_params[] = "{$filter_key} >= '{$min}'";
								$filter_params[] = "{$filter_key} <= '{$max}'";
							} elseif ($min == $max) {
								$filter_params[] = "{$filter_key} = '{$min}'";
							}
						} elseif ($min) {
							$filter_params[] = "{$filter_key} >= '{$min}'";
						} elseif ($max) {
							$filter_params[] = "{$filter_key} <= '{$max}'";
						}
					} elseif (strpos($filter_val, ',') !== false) {
						$arr = explode(',', $filter_val);
						$str = '';
						
						foreach ($arr as $v2) {
							$str .= ($str ? " OR " : '')."FIND_IN_SET(".$this->db->esc_html($v2).", {$filter_key}) > 0";
						}
						
						if ($str) {
							$filter_params[] = '('.$str.')';
						}
					} else {
						if ($cutted_key == '.user_group' and $filter_val == User::GUEST_USERGROUP_ID) {
							$filter_params[] = "{$filter_key} IS NULL";
						} else {
							$filter_val = $this->db->esc_html($filter_val);
							$filter_params[] = "{$filter_key} = '{$filter_val}'";
						}
					}
				}
				
				
			}
			
			
			if ($filter_params) {
				$sql_addon = " {$beginning_part} ".implode(" AND ", $filter_params);
				return $sql_addon;
			}
		}
		
		return '';
	}
	
	public function buildFiltrationStatusPanel($tbl_columns) {
		if (GET('filter') == 'field' and $filters_array = GET('val')) {
			$html = '<div>'.__('Фильтрация:').'</div>';
			$html .= '<div class="chosen-container chosen-container-multi chzn-container chzn-container-multi"><ul class="chosen-choices chzn-choices">';
			
			foreach ($filters_array as $key => $val) {
			
				if ($value = safe_array_access($tbl_columns, $key)) {
					$search = array('&val['.$key.']='.$val);
					if (count($filters_array) == 1)
						$search[] = '&filter=field';
					
					$url = str_replace($search, '', $this->helper->getCurrentUrl());
					
					$html .= '
					<li class="search-choice">
						<span>'.$value['title_part'].'</span>
						<a href="'.$url.'" class="search-choice-close" title="'.__('Отменить фильтрацию').' '.$value['title_part'].'"></a>
					</li>';
				}
			}
			
			$html .= '</ul></div>';
			return $html;
		}
	}
	
	private function getDatetimeFieldType($fieldname) {
		$without_prefix_fieldname = $this->adminpanel->removeAliasPrefix($fieldname);
		
		if (strpos($fieldname, 'created') !== false or in_array($without_prefix_fieldname, array('expired_date')))
			return 'timestamp';
		if (strpos($fieldname, 'date') !== false)
			return 'unixtime';
	}
	
	public function getFieldname($key) {
		if (!$fieldname = safe_array_access($this->filter_data, 'tbl_columns', $key, 'fieldname')) {
			if (strpos($key, 'a.') === 0) {
				$fieldname = str_replace('a.', '', $key);//a.created --> created
			} elseif ($row = safe_array_access($this->filter_data, 'row')) {
				$fieldname = preg_replace('#^([b-z])\.([\w\-]+)#', '$1_$2', $key);//b.created --> b_created
				if (!isset($row[$fieldname]))
					$fieldname = preg_replace('#^[b-z]\.([\w\-]+)#', '$1', $key);//b.created --> created
					
				if (!isset($row[$fieldname]) and !is_null($row[$fieldname]))
					trigger_error('Wrong fieldname: '.$fieldname, E_USER_ERROR);
			}
			
			$this->filter_data['tbl_columns'][$key]['fieldname'] = $fieldname;
		}
		
		return $fieldname;
	}
}