<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

class Admin_UpdateUser extends AddonSettings
{
	public function execWcFields($variables) {
		$result_array = array();
		
		switch ($variables['xfieldsaction']) {
			case 'list': $result_array = $this->printWcFields($variables); break;//вывод полей при добавлении/редактировании профиля
			case 'init': $this->updateWcFields($variables); break;//при сохранении полей
		}
		
		return $result_array;
	}
	
	public function printWcFields($variables) {//вывод полей в админпанели при добавлении/редактировании профиля
		$result_array = array();
		$auu_output = '';
		extract($variables);
		$user_id = (int)$id;
		
		if ($val = $this->user->getUserBalance($user_id)) {
			$name = $this->config->balance_field_name;
			$auu_output .= $this->renderWcFieldTextControl($name, __('Баланс пользователя'), $val);
		}
		
		$result_array = compact('auu_output');
		
		return $result_array;
	}
	
	private function renderWcFieldTextControl($fieldname, $title, $fieldvalue, $is_optional = true, $hint = '') {
		$output = '';
		$holderid = 'wcfields_holder_'.$fieldname;
		$optional_html = $is_optional ? '' : '<span style="color:red;">*</span>';
		
		$hint_html = $this->getHintHtml($hint);
		
		if ($this->helper->isVersionLess('10.6')) {
			$output .= <<<HTML
			<tr id="{$holderid}">
				<td class="addnews">{$title}: {$optional_html}</td>
				<td class="xfields" colspan="2">
					<input type="text" name="wcfields[{$fieldname}]" id="wcfields_{$fieldname}" value="{$fieldvalue}" />
					&nbsp;&nbsp;
					{$hint_html}
				</td>
			</tr>
HTML;

		} else {
			$output .= <<<HTML
			<div id="{$holderid}" class="form-group">
				<label class="control-label col-sm-3 col-md-3">{$title}: {$optional_html}</label>
				<div class="col-sm-9 col-md-9">
					<input type="text" class="form-control width-500" name="wcfields[{$fieldname}]" id="wcfields_{$fieldname}" value="{$fieldvalue}" /> {$hint_html}
				</div>
			</div>
HTML;

		}
		
		return $output;
	}
	
	public function getHintHtml($hint) {
		if ($hint) {
			$hint = $this->helper->htmlspecialchars($hint);
			return '<i class="help-button visible-lg-inline-block text-primary-600 fa fa-question-circle position-right position-left" data-rel="popover" data-trigger="hover" data-placement="right" data-content="'.$hint.'" ></i>';
		}
	}	
	
	public function updateWcFields($variables) {
		extract($variables);
		
		if (!empty($id)) {//второе подключение
			$user_id = (int)$id;
			$name = $this->config->balance_field_name;
			$data = array($name => (float)POST('wcfields', $name));
			$sql_part = $this->db->prepareSqlPart($data);
			$this->db->query("UPDATE ".USERPREFIX."_users SET {$sql_part} WHERE user_id = '{$user_id}' LIMIT 1");			
		}
	}

}