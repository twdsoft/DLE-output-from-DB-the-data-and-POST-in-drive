<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

class Admin_Plugins extends AddonSettings
{	
	public function getPath() {
		$this->path or $this->path = $this->webcash->module_path.'admin/plugins/'.$this->alias.'/';
		return $this->path;
	}
	
	public function getAbsDirUrl() {
		$this->dir_url or $this->dir_url = $this->webcash->module_url.'admin/plugins/'.$this->alias.'/';
		return $this->dir_url;
	}
	
	public function getDirUrl() {
		$this->rel_dir_url or $this->rel_dir_url = $this->webcash->rel_module_url.'admin/plugins/'.$this->alias.'/';
		return $this->rel_dir_url;
	}
	
}