<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

class Admin_Panel extends Application
{
	const CONFIG_TAB = 10;
	const GATEWAYS_TAB = 20;
	const PLUGINS_TAB = 30;
	const UPGRADE_TAB = 40;
	
	const SHOW_LIST_FOR_ADDON_EDITING = false;
	
	protected $admtopdropdownmenu_recent = array();
	protected $admtopdropdownmenu_favorites = array();
	protected $admtopdropdownmenu = array();
	
	public function showRow($title = '', $description = '', $field = '', $container_part = '', $col_values = array(), $is_required = false) {
		if ($is_required) {
			$container_part .= ' class="tr_f_req"';
			if (preg_match('#\s+name="([^"]+)"\s+#', $field, $matches))
				$name = $matches[1];
			else
				trigger_error('No matches', E_USER_ERROR);
			$field .= $this->helper->printRequiredHtml($title, $name);
		}
		
		$new_col_values = array();
		$default_col_values = array('xs' => array(12, 12), 'sm' => array(12, 12), 'md' => array(7, 5));
		
		if ($col_values) {
			$key = key($col_values);
			if (is_numeric($key)) {//$col_values = array(5, 7);
				$new_col_values['md'] = $col_values;
			} else {//$col_values = array('sm' => array(6, 6));
				$new_col_values = $col_values;
			}
		}
		
		$col_values = array_merge($default_col_values, $new_col_values);
		
		
		list($col_xs_1, $col_xs_2) = $col_values['xs'];
		list($col_sm_1, $col_sm_2) = $col_values['sm'];
		list($col_md_1, $col_md_2) = $col_values['md'];
		
		echo "<tr {$container_part}>
		   <td class=\"col-xs-{$col_xs_1} col-sm-{$col_sm_1} col-md-{$col_md_1}\"><div class=\"media-heading text-semibold\">".$title."</div><span class=\"text-muted text-size-small\">".$description."</span></td>
		   <td class=\"col-xs-{$col_xs_2} col-sm-{$col_sm_2} col-md-{$col_md_2}\">{$field}</td>
		   </tr>";
	}

	public function makeCheckbox($name, $checked, $tag_part = '') {
		return '<input type="checkbox" name="'.$name.'" value="1" class="switch '.($this->helper->isVersionLess('12') ? 'icheck' : '').'" '.($checked ? 'checked ' : ' ').$tag_part.' /><input type="hidden" name="fix_missed_integer[]" value="'.$name.'" />';
	}
	
	public function makeDropdown($options, $name, $selected, $tag_part = '') {
		$output = "<select class=\"uniform\" name=\"{$name}\" {$tag_part}>\r\n";
		foreach ($options as $value => $description) {
			$output .= "<option value=\"{$value}\"";
			if ($selected == $value) {
				$output .= " selected ";
			}
			$output .= ">{$description}</option>\n";
		}
		$output .= "</select>";
		return $output;
	}

	public function makeInputText($name, $value, $tag_part = '') {
		return '<input type="text" name="'.$name.'" value="'.$this->helper->htmlspecialchars($value).'" class="form-control" '.$tag_part.' />';
	}
	
	public function makeTextarea($name, $value, $tag_part = '') {
		return '<textarea class="classic width-500" name="'.$name.'" id="'.$name.'" '.$tag_part.' spellcheck="false">'.$value.'</textarea>';
	}
	
	public function makeLinkedPartArray($params) {
		$name = safe_array_access($params, 'name');
		
		$possible = isset($params['possible']) ? $params['possible'] : 1;
		
		if (isset($params['value'])) {
			$value = $params['value'];
		} elseif (isset($params['names'])) {
			$value = get_nested_var($this->config->getSection('MAIN'), $params['names']);
		}
		
		$key = isset($params['key']) ? $params['key'] : $name;
		
		return $this->makeLinkedPart($name, $possible, $value);
	}
	
	public function makeLinkedPart($name, $possible = 1, $value = null) {
		if (is_null($value))
			$value = $this->config->{$name};
		
		if (is_array($possible)) {
			$exists = in_array($value, $possible);
			$possible = implode(' ', $possible);
		} else {
			$exists = $value == $possible;
		}
		
		return 'data-linked_container_'.$name.'="'.$possible.'"'.($exists ? '' : ' style="display:none;"');
	}
	
	public function showIf($condition) {
		return $condition ? '' : ' style="display:none;"';
	}
	
	public function getUpgradeTabCaption() {
		$cache_key = $this->getUpgradeCacheKey();
		if ($cache = $this->helper->getCache($cache_key)) {
			$data = json_decode($cache, true);

			if ($this->isActualUpgrade($data['version'])) {
				return '<sup style="color:red">'.__('Есть обновления').'</sup>';
			} else {
				return '<sup>'.__('Нет').'</sup>';
			}
		}
		return '<span id="upgrade_tab_caption_container"><img src="'.$this->webcash->site_url.'engine/skins/images/loading.gif" alt="" /></span>';
	}

	public function getUpgradeCacheKey() {
		$str = 'webcash_check_updates_';
		return $str.$this->helper->getCacheKey($str);
	}

	public function isActualUpgrade($new_version) {
		return ($new_version and version_compare($new_version, $this->config->ignored_update_version, '>') and version_compare($new_version, $this->config->version, '>'));
	}

	public function installUpgrade($temp_filepath, $version) {
		require_once $this->webcash->module_path.'admin/lib/pclzip/pclzip.lib.php';
		require_once $this->webcash->module_path.'admin/lib/sql_parse.php';
		require_once $this->webcash->module_path.'admin/lib/xcopy/xcopy.php';

		if (file_exists($temp_filepath) and filesize($temp_filepath) > 100) {
			$dir = str_replace('.zip', '', $temp_filepath);

			if ($this->helper->mkdir($dir)) {
				$archive = new \PclZip($temp_filepath);

				if ($archive->extract(PCLZIP_OPT_PATH, $dir) != 0) {
					copy_folder($dir.'/files', ROOT_DIR, false, false);

					$str = $dir.'/upgrade.php';
					if (file_exists($str))
						include $str;

					$this->helper->rmdir($dir);

					return true;
				} else {
					$this->helper->showMsgErrorNotTranslate('Error : '.$archive->errorInfo(true));
				}
			}
		}
	}
	
	public function hint($hint_name, $hint_content, $translate = true) {
		$admin_sett = $this->adminsettings->getAllSettings();
		$str = totranslit(basename($hint_name), true, false);
		$id = 'hide_hint_'.$str;
		
		if ($translate)
			$hint_content = __($hint_content);
		
		if (empty($admin_sett['i_'.$id])) {
			return '
			<div class="alert alert-info">
				<a href="#" data-id="'.$id.'" class="close hasTip" data-dismiss="alert" title="'.__('Закрыть и больше не показывать эту подсказку.').'">&times;</a>
				'.nl2br($hint_content).'
			</div>';
		}
	}
	
	public function getHelpInfo($text) {
		return '<i class="help-button visible-lg-inline-block text-primary-600 fa fa-question-circle position-right" data-rel="popover" data-trigger="hover" data-placement="right" data-content="'.$text.'"></i>';
	}
	
	public function buildChangeTabTagPart($tab, $end_params = '') {
		return 'href="'.$this->webcash->module_admin_url.'&tab='.$tab.$end_params.'"';
	}
	
	public function renderCommonListPart($file, $tbl_columns) {

		echo $this->adminpanel->hint($file.__FUNCTION__.'1', 'Для более удобной работы, можно использовать фильтрацию по нескольким параметрам одновременно.');
		
		?>
		<div class="row sepH_b">
			<div class="col-xs-12 col-sm-12 col-md-8">
				<?php echo $this->adminfilter->buildFiltrationStatusPanel($tbl_columns); ?>
			</div>
			
			
			<div class="col-xs-12 col-sm-12 col-md-4 text-right">
				<div class="btn-group">
					<a href="#" class="dropdown-toggle nocolor" data-toggle="dropdown-webcash" aria-expanded="true" title="<?php echo __('Выбрать какие колонки таблицы будут отображаться'); ?>"> <i class="fa fa-cog"></i> <?php echo __('Настройки колонок'); ?> <span class="caret"></span></a>
					<div class="dropdown-menu text-left pull-right" style="padding:10px;">
						
						<?php echo $this->adminpanel->hint($file.__FUNCTION__.'2', 'Можно указать какие колонки таблицы будут отображаться.'); ?>
						
						<?php echo $this->getTblColumnsMultiSelect($tbl_columns); ?>
						
						<div style="padding-top:20px;">
							<button type="submit" class="btn bg-brown-600 btn-sm btn-raised" onclick="changeSubaction($(this), 'save_columns')">
								<i class="fa fa-floppy-o position-left"></i><?php echo __('Сохранить'); ?>
							</button>
							<a href="#" class="btn bg-slate-600 btn-sm btn-raised" onclick="return closeDropdownMenu($(this));"><?php echo __('Закрыть'); ?></a>
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php
	}
	
	public function getTblColumnsMultiSelect($tbl_columns) {
	
		$html = '<select data-placeholder="'.__('Выберите...').'" name="tbl_columns_list[]" class="tbl_columns_list_multiselect" multiple>';

		foreach ($tbl_columns as $key => $value) {
			$html .= '<option value="'.$key.'"'.($value['state'] ? ' selected' : '').'>'.$value['column'].'</option>';
		}
		
		$html .= '</select>';
		$html .= '<script>$("select.tbl_columns_list_multiselect").chosen({allow_single_deselect:true});</script>';
		
		return $html;
	}
	
	public function removeAliasPrefix($key) {
		return preg_match('#^[a-z]\.([\w\-]+)#', $key, $matches) ? $matches[1] : $key;
	}
	
	public function deleteRecordsByGateway($gw_alias) {
		$gw_alias = only_word($gw_alias);
		$this->db->query("DELETE FROM {$this->webcash->gateway_invoices_table} WHERE gateway = '{$gw_alias}'");
		return $this->db->query("DELETE FROM {$this->webcash->gateway_payments_table} WHERE gateway = '{$gw_alias}'");
	}
	
	public function deleteRecordById($id, $table) {
		$id = (int)$id;
		return $this->db->query("DELETE FROM {$table} WHERE id = '{$id}' LIMIT 1");
	}
	
	public function emptyTable($table) {
		return $this->db->query("TRUNCATE TABLE {$table}");
	}
	
	public function resetUsersPermissions($xfield_name) {
		if ($rows = $this->db->select("
			SELECT user_id
			FROM ".USERPREFIX."_users AS a
			WHERE xfields <> ''
		")) {
			$was_changed = false;
			
			foreach ($rows as $row) {
				if ($this->userxfields->setXfieldValue($xfield_name, 'no', $row['user_id']))
					$was_changed = true;
			}
			
			return $was_changed;
		}
	}
	
	public function makePaySourceLink($row) {
		if ($row['pay_source']) {
			$tab = $this->webcash->getConst('pay_sources|'.$row['pay_source'].'|tab');
			$id = $row['pay_source_entry_id'];
			return '<a href="'.$this->listtransactions->getAddonSettingsUrl('&tab2='.$tab.'&filter=field&val[a.id]='.$id).'" title="'.__('Перейти к соответствующей записи таблицы').'"> ID'.$id.' <sup>'.__($this->webcash->getConst('pay_sources|'.$row['pay_source'].'|short_title')).'</sup></a>';
		} else {
			return '--//--';
		}
	}
	
	public function getPaySourceTablename($pay_source) {
		switch ($pay_source) {
			case WebCash::PAY_SOURCE_GATEWAY: $tablename = $this->webcash->gateway_payments_table; break;
			case WebCash::PAY_SOURCE_BALANCE: $tablename = $this->webcash->balance_transactions_table; break;
			default: $tablename = '';
		}
		
		return $tablename;
	}
	
	public function showSeparator() {
		echo '<tr><td colspan="2"><div class="sepH_b"></div></td></tr>';
	}
	
}