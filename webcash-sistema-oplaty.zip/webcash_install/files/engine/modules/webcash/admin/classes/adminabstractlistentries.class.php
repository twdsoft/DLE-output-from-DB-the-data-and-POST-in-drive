<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

abstract class Admin_AbstractListEntries extends Plugins_Admin_ListTransactions
{
	public function filterUnusedColumns(array $tbl_columns, $keys_str = '') {
		$arr = $keys_str ? explode(',', $keys_str) : array();
		$arr[] = 'a.area_alias';
		
		foreach ($arr as $key) {
			unset($tbl_columns[$key]);
		}
		
		return $tbl_columns;
	}

}