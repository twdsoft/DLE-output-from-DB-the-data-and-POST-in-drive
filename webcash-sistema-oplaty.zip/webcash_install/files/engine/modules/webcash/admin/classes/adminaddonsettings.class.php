<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

class Admin_AddonSettings extends AddonSettings
{
	protected $base_instance = null;
	protected $base_alias = '';
	protected $th_count = 0;
	protected $sort_off_current_url = '';
	
	public function saveTblColumnsList($name, array $tbl_columns_list) {
		$tbl_columns_list = array_map('only_alias', $tbl_columns_list);
		$str = implode(',', $tbl_columns_list);
		
		if ($this->getBaseInstance()->writeCfgValue($name, $str)) {
			$this->helper->showMsgOk('Настройки сохранены. Перезагрузка...', 'Информация', 'self');
		} else {
			$this->helper->showMsgError('Нет изменений');
		}
	}
	
	public function endHandleTblColumns(array $tbl_columns, $name) {
		$arr = explode(',', $this->getBaseInstance()->{$name});
		foreach ($tbl_columns as $k => &$v) {
			$v['state'] = in_array($k, $arr) ? 1 : 0;
		}
		unset($v);
		
		return $tbl_columns;
	}
	
	public function commonInitList($total_count, $tbl_columns) {
		$this->pager->set('items_total', $total_count);
		$a = empty($this->getBaseInstance()->cfg['default_ipp']) ? $this->config->default_ipp : $this->getBaseInstance()->default_ipp;
		$this->pager->set('default_ipp', $a);
		$this->pager->paginate();
		
		$this->adminfilter->set('filter_data|tbl_columns', $tbl_columns);
		$this->adminfilter->set('filter_data|addon_alias', $this->base_alias);
		
		$sort = only_alias(GET('sort')) or $sort = 'a.id';
		$order = only_alias(GET('order')) or $order = 'a.desc';
		
		$search = array('&sort='.$sort, '&order='.$order);
		$this->set('sort_off_current_url', str_replace($search, '', $this->helper->getCurrentUrl()));
		
		$sql_order_by = "ORDER BY {$sort} ".($order == 'asc' ? "ASC" : "DESC");
		return $sql_order_by;
	}
	
	public function getSortOffCurrentUrl() {
		return $this->sort_off_current_url;
	}
	
	public function renderItemsTableThead($tbl_columns, $suffix = '') {
		$html = '
			<thead>
				<tr>';
		
		$this->th_count = 1;
		
		foreach ($tbl_columns as $key => $value) {
		
			if ($value['state']) {
				$str = $this->adminpanel->removeAliasPrefix($key);
				
				$class = '';
				if (in_array($str, array('created', 'state', 'nosort2'))) {
					$class = 'text-center';
				}
				
				if (empty($value['title_part'])) {
					$html .= '
					<th class="'.$class.'">'.$value['column'].'</th>';	
				} else {
					$asc_tip = $value['title_part'].', '.(empty($value['sort_alpha']) ? __('по возрастанию') : __('А→Я'));
					$desc_tip = $value['title_part'].', '.(empty($value['sort_alpha']) ? __('по убыванию') : __('Я→А'));
					
					if (GET('sort') == $key) {
						$html .= '
						<th class="sorting_'.only_word(GET('order')).' '.$class.'" onclick="WEBCASH.redirectTo(\''.$this->getSortOffCurrentUrl().'&sort='.$key.'&order='.((GET('order') == 'asc') ? 'desc' : 'asc').'\')" title="'.__('Сортировать').' '.((GET('order') == 'asc') ? $desc_tip : $asc_tip).'">'.$value['column'].'</th>';	
					} else {
						$html .= '
						<th class="sorting '.$class.'" onclick="WEBCASH.redirectTo(\''.$this->getSortOffCurrentUrl().'&sort='.$key.'&order=asc\')" title="'.__('Сортировать').' '.$asc_tip.'">'.$value['column'].'</th>';
					}
				}
				
				++$this->th_count;
			}
		}
		
		$html .= '
				</tr>
			</thead>';
			
		return $html;
	}
	
	public function filterAndSortCancelButton($tab2) {
		if (GET('filter') == 'field' or GET('sort')) {
			$str = 'href="'.$this->getBaseInstance()->getAddonSettingsUrl('&tab2='.$tab2).'"';
		?>
		<a <?php echo $str; ?> title="<?php echo __('Сбросить настройки фильтрации и сортировки'); ?>" class="btn bg-teal btn-raised position-left btn-green">
			<i class="fa fa-refresh position-left"></i><?php echo __('Отмена'); ?>
		</a>
		<?php
		}
	}
	
	public function getSelectElementList(array $values, $add_empty_val = false, $name = 'pay_types') {
		$base_instance = $this->getBaseInstance();
		$output_array = array();
		
		if ($add_empty_val)
			$output_array[0] = __('Выберите...');
		
		foreach ($values as $value) {
			if (!$str = $base_instance->getConst("{$name}|{$value}|title2"))
				$str = $base_instance->getConst("{$name}|{$value}|title");
				
			if ($str) {
				$output_array[$value] = __($str);
			}
		}
		
		return $output_array;
	}
	
	public function getBaseInstance() {
		if (is_null($this->base_instance)) {
			$this->base_instance = $this->webcash->getAddonInstanceByAlias($this->base_alias);
		}
		
		return $this->base_instance;
	}
	
	public function deleteOwnedAllEntries($rel_item_type = 0) {
		$sql_addon = $rel_item_type ? "AND rel_item_type = '{$rel_item_type}'" : "";
		$result = false;
		
		if ($this->db->query("
			DELETE FROM {$this->webcash->gateway_payments_table}
			WHERE area_alias = '{$this->base_alias}'
			{$sql_addon}"
		))
			$result = true;
		
		if ($this->db->query("
			DELETE FROM {$this->webcash->balance_transactions_table}
			WHERE area_alias = '{$this->base_alias}'
			{$sql_addon}"
		))
			$result = true;
		
		if ($result)
			$this->helper->showMsgOk('Соответствующие записи удалены. Перезагрузка...', 'Информация', 'self');
		else
			$this->helper->showMsgError('Нет записей');
	}
	
	public function deleteOwnedInvoicesEntries($rel_item_type = 0) {
		$sql_addon = $rel_item_type ? "AND rel_item_type = '{$rel_item_type}'" : "";
		
		if ($this->db->query("
			DELETE FROM {$this->webcash->gateway_invoices_table}
			WHERE area_alias = '{$this->base_alias}'
			{$sql_addon}"
		))
			$this->helper->showMsgOk('Соответствующие записи удалены. Перезагрузка...', 'Информация', 'self');
		else
			$this->helper->showMsgError('Нет записей');
	}
	
	public function deleteOwnedPaymentsEntries($rel_item_type = 0) {
		$sql_addon = $rel_item_type ? "AND rel_item_type = '{$rel_item_type}'" : "";
		
		if ($this->db->query("
			DELETE FROM {$this->webcash->gateway_payments_table}
			WHERE area_alias = '{$this->base_alias}'
			{$sql_addon}"
		))
			$this->helper->showMsgOk('Соответствующие записи удалены. Перезагрузка...', 'Информация', 'self');
		else
			$this->helper->showMsgError('Нет записей');
	}
	
	public function deleteOwnedBalanceTransactionsEntries($rel_item_type = 0) {
		$sql_addon = $rel_item_type ? "AND rel_item_type = '{$rel_item_type}'" : "";
		
		if ($this->db->query("
			DELETE FROM {$this->webcash->balance_transactions_table}
			WHERE area_alias = '{$this->base_alias}'
			{$sql_addon}"
		))
			$this->helper->showMsgOk('Соответствующие записи удалены. Перезагрузка...', 'Информация', 'self');
		else
			$this->helper->showMsgError('Нет записей');
	}
	
}