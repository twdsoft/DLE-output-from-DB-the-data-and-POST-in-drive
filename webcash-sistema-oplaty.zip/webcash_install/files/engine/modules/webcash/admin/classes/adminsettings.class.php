<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

class Admin_Settings extends Application
{
	protected $table_a = 'webcash_admin_settings';
	private $data = null;
	
	public function saveParam($param, $val) {
		$param = $this->db->esc_html($param);
		$val = $this->db->esc_html($val);
		
		if ($id = $this->db->selectCell("
			SELECT id
			FROM {$this->table_a}
			WHERE `user_id` = '{$this->user->id}'
			AND `param` = '{$param}'
			LIMIT 1"
		)) {
			return $this->db->query("
				UPDATE {$this->table_a}
				SET `{$param[0]}_value` = '{$val}'
				WHERE `id` = '{$id}'
				LIMIT 1"
			);
		} else {
			return $this->db->query("
				INSERT INTO {$this->table_a}
				SET
					`user_id` = '{$this->user->id}',
					`param` = '{$param}',
					`{$param[0]}_value` = '{$val}'"
			);
		}
	}
	
	public function getAllSettings() {
		if (is_null($this->data)) {
			if ($rows = $this->db->select("
				SELECT *
				FROM {$this->table_a}
				WHERE `user_id` = '{$this->user->id}'"
			)) {
			
				foreach ($rows as $row) {
					$this->data[$row['param']] = $row[$row['param'][0].'_value'];
				}
			} else {
				$this->data = array();
			}
		}
		
		return $this->data;
	}
	
	public function setDefaultValue(&$settings_array, $name, $value, $if_empty = false) {
		if ($if_empty) {
			if (empty($settings_array[$name])) {
				$settings_array[$name] = $value;
			}
		} else {
			if (!isset($settings_array[$name])) {
				$settings_array[$name] = $value;
			}
		}
	}
	
}