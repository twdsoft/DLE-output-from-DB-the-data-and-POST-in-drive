/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

function changeSubaction(sender, value) {
	sender.closest("form").find('input[name=subaction]').val(value);
}


function ndShowMessage(message, delay) {
	if (typeof delay === "undefined")
		delay = 2000;
	
	ShowLoading(message);
	$("#loading-layer").css({"z-index":"9999"});
	setTimeout(function() {
		$("#loading-layer").css({"z-index":"99"});
		HideLoading();
	}, delay);
}

function ndSetCookie(name, value, days) {
    var expires = "";
    if (days) {
        var date = new Date();
        date.setTime(date.getTime() + (days*24*60*60*1000));
        expires = "; expires=" + date.toUTCString();
    }
    document.cookie = name + "=" + (value || "")  + expires + "; path=/";
}

function writeParam(sender, param, val) {
	var url = sender.data("url");
	if (typeof url === "undefined")
		url = WEBCASH_OPTIONS.ADMIN_URL;
	
	$.post(url,	{action: "ajax.user_settings_save_param", param: param, val: val, user_hash: WEBCASH_OPTIONS.USER_HASH});
}



function submitCurrentForm() {
	var $form = $("form.webcash_ajax_form:visible")
		.has("button[type=submit]:visible, input[type=submit]:visible")
		.inWindow();
	$form.submit();
	return false;
}

//отправка формы по нажатию горячих клавиш
submit_hotkey = {
	init: function() {//назначаем обработчик нажатия на Ctrl + Enter
		var isCtrl = false;
		$(document).keyup(function (e) {
			if (e.which == 17)
				isCtrl = false;
		}).keydown(function (e) {
			if (e.which == 17)
				isCtrl = true;
			if (e.which == 13 && isCtrl == true) {//13 - Enter, 32 - Space
				return submitCurrentForm();
			}
		});
	}
};

//accordion icons
accordion_icons = {
	init: function() {
		var accordions = $(".accordion");
		
		accordions.find(".accordion-group").each(function() {
			var acc_active = $(this).find(".accordion-body").filter(".in");
			acc_active.prev(".accordion-heading, .heading").find(".accordion-toggle").addClass("acc-in");
		});
		accordions.on("shown.bs.collapse", function(option) {
			$(option.target).prev(".accordion-heading, .heading").find(".accordion-toggle").addClass("acc-in");
		});
		accordions.on("hidden.bs.collapse", function(option) {
			$(option.target).prev(".accordion-heading, .heading").find(".accordion-toggle").removeClass("acc-in");
		});	
	}
};


function saveOrderingOnClick(sender) {
	sender.data(
		"vars",
		sender.data("vars") + "|ids=" + JSON.stringify($("tbody.go-sortable").sortable("toArray"))
	);
	WEBCASH.doAjax(sender);
	return false;
}

function closeDropdownMenu(sender) {
	var $target = sender.closest(".dropdown-menu").prev(".dropdown-toggle");
	
	if ($target.data("toggle") == "dropdown-webcash")
		$target.parent().removeClass("open");
	else
		$target.dropdown("toggle");
	
	return false;
}


jQuery(document).ready(function($) {

	WEBCASH.inWindow();
	WEBCASH.dataStartsWith();
	WEBCASH.linked_select.init(true);
	WEBCASH.linked_checkbox.init(true);
	WEBCASH.disableHidden();
	
	
	$('a[data-dismiss="alert"]').on("click", function(e) {
		var id = $(this).data("id");
		writeParam($(this), "i_" + id, 1);
	});
	
	var $upgrade_tab_caption_container = $("#upgrade_tab_caption_container");
	if ($upgrade_tab_caption_container.length) {
		$.post(WEBCASH_OPTIONS.ADMIN_URL, {"action": "ajax.get_upgrades_info", "user_hash": WEBCASH_OPTIONS.USER_HASH}, function( data ) {
			if (data.msg) {
				$upgrade_tab_caption_container.html(data.msg.title);
				$("#upgrade_tab_body_container").html(data.msg.text);
			}
			
			if (data.status == "ok") {
				$("#upgrade_tab_buttons_container").fadeIn("slow");
			}
		}, "json");
	}

	submit_hotkey.init();
	accordion_icons.init();
	
	$("input.switch.icheck").on("ifChanged", function(event) {//для старых версий DLE
		$(this).trigger("change", event);
	});
	
	$("a[data-toggle=\"dropdown-webcash\"]").on("click", function (event) {
		$(this).parent().toggleClass("open");
		return false;
	});
	
});
