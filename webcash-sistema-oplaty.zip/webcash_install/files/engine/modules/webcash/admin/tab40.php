<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');
?>

<form action="" class="webcash_ajax_form form-horizontal" method="post" autocomplete="off">
	<div class="panel panel-flat">
		<div class="panel-body">
			<b><?php echo __('Статус проверки обновлений'); ?></b>
		</div>
		<div class="table-responsive" style="padding:0 20px 20px 20px">
		<?php
		$cache_key = $webcash->adminpanel->getUpgradeCacheKey();
		$updates_exists = false;
		if ($cache = $webcash->helper->getCache($cache_key, 345600)) {
			$data = json_decode($cache, true);
			
			if ($webcash->adminpanel->isActualUpgrade($data['version'])) {
				echo nl2br(__($data['description']));
				$updates_exists = true;
			} else {
				echo '<h6>'.__('Нет актуальных обновлений').'</h6>';
			}
		}
		
		if (!$updates_exists) {
			echo '<div id="upgrade_tab_body_container"></div>';
		}
		?>
		</div>
	</div>
	<div style="padding:5px 0 20px 20px;<?php echo $updates_exists ? '' : ' display:none;' ?>" id="upgrade_tab_buttons_container">
		<input type="hidden" name="action" value="ajax.from_tab<?php echo Admin_Panel::UPGRADE_TAB; ?>" />
		<input type="hidden" name="subaction" value="install" />
		<input type="hidden" name="user_hash" value="<?php echo $webcash->user->nonce; ?>" />
		<button type="submit" class="btn bg-teal btn-raised position-left btn-green" onclick="changeSubaction($(this), 'install')">
			<i class="fa fa-upload position-left"></i><?php echo __('Установить'); ?>
		</button>
		<button type="submit" class="btn bg-danger btn-raised position-left btn-red" onclick="changeSubaction($(this), 'ignore')">
			<i class="fa fa-close position-left"></i><?php echo __('Игнорировать это обновление'); ?>
		</button>
	</div>
</form>


<form action="" class="webcash_ajax_form form-horizontal" method="post" autocomplete="off">
	<div class="panel panel-flat">
		<div class="panel-body">
			<b><?php echo __('Настройки обновлений'); ?></b>
		</div>
		<div class="table-responsive">
			<table class="table table-striped">
				<?php
				$webcash->adminpanel->showRow(
					__('Секретный ключ покупателя'),
					__('Данный ключ необходимо хранить в секрете. Используется для получения обновлений для платных плагинов в течении определенного периода (обычно - год) с момента покупки, а также для доступа в клиентские разделы оффициального сайта'),
					$webcash->adminpanel->makeInputText(
						'config_fields[secret_buyer_code]',
						$webcash->config->secret_buyer_code
					)
				);
				?>
			</table>
		</div>
	</div>
	<div class="buttons_wrap">
		<input type="hidden" name="action" value="ajax.from_tab<?php echo Admin_Panel::UPGRADE_TAB; ?>" />
		<input type="hidden" name="subaction" value="config" />
		<input type="hidden" name="user_hash" value="<?php echo $webcash->user->nonce; ?>" />
		<button type="submit" class="btn bg-teal btn-raised position-left btn-green">
			<i class="fa fa-floppy-o position-left"></i><?php echo __('Сохранить'); ?>
		</button>
		<button type="submit" class="btn bg-danger btn-raised position-left btn-red" onclick="changeSubaction($(this), 'reset_cache')">
			<i class="fa fa-close position-left"></i><?php echo __('Запросить обновление немедленно'); ?>
		</button>
	</div>
</form>