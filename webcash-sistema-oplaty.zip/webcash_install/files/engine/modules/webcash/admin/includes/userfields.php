<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

defined('DATALIFEENGINE') or exit('Access Denied');

require ENGINE_DIR.'/modules/webcash/init.php';

if (!$webcash->config->balance_in_xfield) {
	$variables = compact('xfieldsaction', 'xfieldsid', 'xfieldsadd', 'output', 'id');

	$result_array = $webcash->adminupdateuser->execWcFields($variables);

	extract($result_array);

	$output .= $auu_output;
}