<?php
function remove_comments($output)
{
	$lines = explode("\n", $output);
	$output = '';

	// try to keep mem. use down
	$linecount = count($lines);

	$in_comment = false;
	for	($i = 0; $i < $linecount; $i++)
	{
		if (preg_match('@^\/\*@', preg_quote($lines[$i])))
		{
			$in_comment = true;
		}

		if (!$in_comment)
		{
			$output .= $lines[$i]."\n";
		}

		if (preg_match('@\*\/$@', preg_quote($lines[$i])))
		{
			$in_comment = false;
		}
	}

	unset($lines);
	return $output;
}

function remove_remarks($sql)
{
   $lines = explode("\n", $sql);

	// try to keep mem. use down
	$sql = '';

	$linecount = count($lines);
	$output = '';

	for ($i = 0; $i < $linecount; $i++)
	{
		if (($i != ($linecount - 1)) || (mb_strlen($lines[$i]) > 0))
		{
			if (isset($lines[$i][0]) and $lines[$i][0] != '#')
			{
				$output .= $lines[$i]."\n";
			}
			else
			{
				$output .= "\n";
			}
			// Trading a bit of speed for lower mem. use here.
			$lines[$i] = '';
		}
	}

	return $output;
}

function split_sql_file($sql, $delimiter)
{
	$sql = str_replace("\r" , '', $sql);
	$data = preg_split('/'.preg_quote($delimiter, '/').'$/m', $sql);

	$data = array_map('trim', $data);

	// The empty case
	$end_data = end($data);

	if (empty($end_data))
	{
		unset($data[key($data)]);
	}

	return $data;
}