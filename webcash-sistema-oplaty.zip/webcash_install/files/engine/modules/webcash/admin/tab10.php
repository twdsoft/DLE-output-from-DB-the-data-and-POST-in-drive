<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

$usergroups_rows = array(0 => __('По умолчанию'));
foreach ($user_group as $row) {
	if ($row['id'] != 5)
		$usergroups_rows[$row['id']] = $row['group_name'];
}
?>

<form action="" class="webcash_ajax_form form-horizontal" method="post" autocomplete="off">
	<div class="panel panel-flat">
		<div class="panel-body">
			<?php echo $webcash->adminpanel->hint(__FILE__.'1', 'Модуль предназначен для осуществления платежей с помощью платежных шлюзов или с баланса пользователя. С помощью плагинов можно добавлять новые функции, например, зачисление денег на баланс пользователя за публикацию новостей, пополнение баланса с помощью промокода и через платежные шлюзы и т.д. Страница личного кабинета для пользователя на сайте - &laquo;<a href="'.$webcash->site_url.'index.php?do=webcash">'.$webcash->site_url.'index.php?do=webcash</a>&raquo;.'); ?>
			
			<?php $str = file_exists(ROOT_DIR.'/templates/'.$config['skin'].'/modules/webcash/main_index.tpl') ? '' : ' (<a href="#" data-do="ajax-webcash" data-vars="action=ajax.from_tab'.Admin_Panel::CONFIG_TAB.'|subaction=copy_template_folder" title="Скопировать папку с шаблонами модуля в папку текущей темы">скопировать в текущую тему</a>)' ?>
			<?php echo $webcash->adminpanel->hint(__FILE__.'2', 'Папка с шаблонами модуля - &laquo;/webcash/&raquo;. При установке данная папка была скопирована в папку &laquo;/templates/Default/&raquo;'.$str.'.'); ?>
		</div>
		<div class="table-responsive">
			<table class="table table-striped">
				<?php
				$webcash->adminpanel->showRow(
					__('Включить модуль'),
					'',
					$webcash->adminpanel->makeCheckbox(
						'config_fields[state]',
						$webcash->config->state
					)
				);
				
				$webcash->adminpanel->showRow(
					__('Имя поля в таблице'),
					__('Имя поля в таблице базы данных или дополнительного поля, которое используется для хранения баланса пользователя'),
					$webcash->adminpanel->makeInputText(
						'config_fields[balance_field_name]',
						$webcash->config->balance_field_name
					)
				);
				
				$webcash->adminpanel->showRow(
					__('Баланс в дополнительном поле'),
					__('Использовать для хранения баланса дополнительное поле профиля или создать отдельную колонку в таблице'),
					$webcash->adminpanel->makeCheckbox(
						'config_fields[balance_in_xfield]',
						$webcash->config->balance_in_xfield,
						'data-linked_checkbox="balance_in_xfield"'
					)
				);
				
				$webcash->adminpanel->showRow(
					__('Название дополнительного поля в таблице'),
					__('Название дополнительного поля для хранения баланса пользователя (используется в админпанели)'),
					$webcash->adminpanel->makeInputText(
						'config_fields[balance_xfield_title]',
						__($webcash->config->balance_xfield_title)
					),
					$webcash->adminpanel->makeLinkedPart('balance_in_xfield')
				);
				
				
				$webcash->adminpanel->showRow(
					__('Оплата через платежные шлюзы включена'),
					__('Разрешить/запретить пользователям процесс оплаты с помощью платежных шлюзов'),
					$webcash->adminpanel->makeCheckbox(
						'config_fields[checkout_on]',
						$webcash->config->checkout_on,
						'data-linked_checkbox="checkout_on"'
					)
				);
				?>
				
				<tr <?php echo $webcash->adminpanel->makeLinkedPart('checkout_on'); ?>>
					<td colspan="2" style="background: url(<?php echo $webcash->module_url; ?>admin/images/stripe_bg.png) repeat;">
						<div class="table-responsive">
							<table class="table table-striped">

								<?php
								
								$webcash->adminpanel->showRow(
									__('URL-адрес страницы после успешной оплаты'),
									__('URL-адрес для редиректа после совершения успешного перевода'),
									$webcash->adminpanel->makeInputText(
										'config_fields[checkout_success_url]',
										$webcash->config->checkout_success_url
									)
								);
								
								$webcash->adminpanel->showRow(
									__('URL-адрес страницы после ошибки при оплате'),
									__('URL-адрес для редиректа, если оплата не было завершена'),
									$webcash->adminpanel->makeInputText(
										'config_fields[checkout_fail_url]',
										$webcash->config->checkout_fail_url
									)
								);
								
								$webcash->adminpanel->showRow(
									__('Сообщение после успешной оплаты'),
									__('Пользователь увидит это сообщение после успешной оплаты'),
									$webcash->adminpanel->makeTextarea(
										'config_fields[checkout_success_message]',
										__($webcash->config->checkout_success_message)
									)
								);
								
								$webcash->adminpanel->showRow(
									__('Сообщение о ошибке при оплате'),
									__('Покупатель увидит это сообщение, если возникла какая-то проблема при оплате'),
									$webcash->adminpanel->makeTextarea(
										'config_fields[checkout_fail_message]',
										__($webcash->config->checkout_fail_message)
									)
								);
								
								$webcash->adminpanel->showRow(
									__('Всплывающее окно для предварительных шагов'),
									__('Если включено, то предварительные шаги: введение Емайл (если это требуется) и выбор платежного шлюза будут отображаться в всплывающем окне, иначе - на отдельной странице'),
									$webcash->adminpanel->makeCheckbox(
										'config_fields[checkout_some_steps_in_popup]',
										__($webcash->config->checkout_some_steps_in_popup)
									)
								);
								
								?>

							</table>
						</div>
					</td>
				</tr>
				
				<?php
				$webcash->adminpanel->showRow(
					__('Восстановить все подсказки'),
					__('Восстановить все скрытые подсказки'),
					'<a href="#" data-do="ajax-webcash" data-vars="action=ajax.from_tab'.Admin_Panel::CONFIG_TAB.'|subaction=restore_hints" title="'.__('Восстановить все скрытые подсказки').'" class="btn bg-brown-600 btn-sm btn-raised legitRipple">'.__('Восстановить').'</a>'
				);
				
				$webcash->adminpanel->showRow(
					__('&laquo;Быстрые ссылки&raquo; на настройки дополнений для администратора'),
					__('Если включено - для администратора на сайте выводятся ссылки на настройки плагинов или платежных шлюзов'),
					$webcash->adminpanel->makeCheckbox(
						'config_fields[adm_fastlink_on]',
						$webcash->config->adm_fastlink_on
					)
				);
				
				$webcash->adminpanel->showRow(
					__('Кэширование'),
					__('Включить/отключить кэширование в модуле для снижения нагрузки'),
					$webcash->adminpanel->makeCheckbox(
						'config_fields[cache_on]',
						$webcash->config->cache_on,
						'data-linked_checkbox="cache_on"'
					)
				);
				
				$webcash->adminpanel->showRow(
					__('Удаление кэша модуля'),
					__('Удаление кэшированных данных модуля для PHP скриптов'),
					'<a href="#" data-do="ajax-webcash" data-vars="action=ajax.from_tab'.Admin_Panel::CONFIG_TAB.'|subaction=clean_cache_all" title="'.__('Удаление кэша модуля').'" class="btn bg-brown-600 btn-sm btn-raised legitRipple">'.__('Удалить').'</a>',
					$webcash->adminpanel->makeLinkedPart('cache_on')
				);
				
				$webcash->adminpanel->showRow(
					__('Кэширование в шаблонизаторе Twig'),
					__('Включить/отключить кэширование в шаблонизаторе Twig для снижения нагрузки'),
					$webcash->adminpanel->makeCheckbox(
						'config_fields[cache_twig_on]',
						$webcash->config->cache_twig_on,
						'data-linked_checkbox="cache_twig_on"'
					)
				);
				
				$webcash->adminpanel->showRow(
					__('Удаление кэша шаблонизатора'),
					__('Удаление кэшированных данных в шаблонизаторе Twig. Операция удаления может потребоваться, например, после редактирования шаблонов &laquo;*.tpl&raquo;.'),
					'<a href="#" data-do="ajax-webcash" data-vars="action=ajax.from_tab'.Admin_Panel::CONFIG_TAB.'|subaction=clean_cache_twig" title="'.__('Удалить').'" class="btn bg-brown-600 btn-sm btn-raised legitRipple">'.__('Удалить').'</a>',
					$webcash->adminpanel->makeLinkedPart('cache_twig_on')
				);
				
				$webcash->adminpanel->showRow(
					__('Отображать для всех'),
					__('Если выключено - то модуль на сайте будет виден только администраторской группе'),
					$webcash->adminpanel->makeCheckbox(
						'config_fields[enable_for_all]',
						$webcash->config->enable_for_all
					)
				);
				
				$webcash->adminpanel->showRow(
					__('IP-адрес для тестирования'),
					__('Если указать IP-адрес для тестирования - все функции модуля на сайте будут отображаться только для него'),
					$webcash->adminpanel->makeInputText(
						'config_fields[test_ip]',
						$webcash->config->test_ip
					)
				);
				
				$webcash->adminpanel->showRow(
					__('Число записей на страницу'),
					__('Количество записей для постраничной навигации в списке'),
					$webcash->adminpanel->makeInputText(
						'config_fields[default_ipp]',
						$webcash->config->default_ipp
					)
				);
				
				$webcash->adminpanel->showRow(
					__('Сбросить конфигурацию дополнений'),
					__('Сбросить настройки всех дополнений (платежных шлюзов и плагинов) до исходного состояния'),
					'<a href="#" data-do="ajax-webcash" data-vars="action=ajax.from_tab'.Admin_Panel::CONFIG_TAB.'|subaction=reset_all_addons_settings" data-confirm="1" class="btn bg-brown-600 btn-sm btn-raised legitRipple">'.__('Сбросить').'</a>'
				);
				
				?>
				<tr><td colspan="2">
				<?php echo $webcash->adminpanel->hint(__FILE__.'3', 'Для склонений единиц валют используются слово и варианты окончаний для 1|2|5 (например: 1 рубль, 2 рубля, 5 рублей).'); ?>
				</td></tr>
				<?php
				
				foreach ($webcash->config->currencies as $key => $value) {
					$webcash->adminpanel->showRow(
						__('Параметры валюты &laquo;'.$key.'&raquo;'),
						__('Склонения и короткое обозначение валюты.'),
						$webcash->adminpanel->makeInputText(
							'config_fields[currencies]['.$key.'][declension]',
							__($value['declension']),
							' style="width:50%"'
						).
						$webcash->adminpanel->makeInputText(
							'config_fields[currencies]['.$key.'][short]',
							auto_convert($value['short']),
							' style="width:45%; margin-left:5%;"'
						)
					);
				}
				
				$webcash->adminpanel->showRow(
					__('Главная валюта модуля'),
					__('Главная валюта модуля'),
					$webcash->adminpanel->makeDropdown(
						$webcash->wc_currency->getCurrenciesList(),
						'config_fields[main_currency]',
						$webcash->config->main_currency
					),
					'',
					array(),
					true
				);
				
				$webcash->adminpanel->showRow(
					__('Источник курса валют'),
					__('Адрес сайта-источника для автоматического рассчета курса валют'),
					$webcash->adminpanel->makeDropdown(
						$webcash->wc_currency->getRatesXmlSourceList(),
						'config_fields[currencies_rates_source]',
						$webcash->config->currencies_rates_source
					),
					'',
					array(),
					true
				);
				?>

			</table>
		</div>
	</div>
	<div class="buttons_wrap">
		<input type="hidden" name="action" value="ajax.from_tab<?php echo Admin_Panel::CONFIG_TAB; ?>" />
		<input type="hidden" name="subaction" value="config" />
		<input type="hidden" name="user_hash" value="<?php echo $webcash->user->nonce; ?>" />
		<button type="submit" class="btn bg-teal btn-raised position-left btn-green">
			<i class="fa fa-floppy-o position-left"></i><?php echo __('Сохранить'); ?>
		</button>
	</div>
</form>