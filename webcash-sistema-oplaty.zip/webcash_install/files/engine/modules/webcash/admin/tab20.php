<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

$html = '';
if (GET('action') == 'addonsett' and $gw_alias = only_word(GET('gw_alias')) and safe_array_access($webcash->getGateways(true), $gw_alias)) {
	if ($instance = $webcash->getAddonInstanceByAlias($gw_alias) and method_exists($instance, 'renderSettingsPanel')) {
		$html = $instance->renderSettingsPanel();
		echo $html;
	}
}

if (!$html or Admin_Panel::SHOW_LIST_FOR_ADDON_EDITING) {
?>

<form action="" class="webcash_ajax_form form-horizontal" method="post" autocomplete="off">
	<div class="panel panel-flat">
		<div class="panel-body">
		
			<?php echo $webcash->adminpanel->hint(__FILE__.'1', 'Платежный шлюз — сервис, который позволяет принимать на сайте платежи от пользователей. Для работы шлюз должен быть включен и настроен.'); ?>
			
			
            <?php if ($rows = $webcash->getGateways(true)) { ?>
			
			

			<div class="table-responsive">

				<table class="table table-xs table-hover">
					<thead>
						<tr>
							<th>&nbsp;</th>
							<th><?php echo __('Название'); ?></th>
							<th><?php echo __('Алиас'); ?></th>
							<th class="text-center"><?php echo __('Методы оплат'); ?></th>
							<th class="text-center"><?php echo __('Число платежей'); ?></th>
							<th class="text-center"><?php echo __('Статус'); ?></th>
							<th style="width: 80px"><?php echo __('Действие'); ?></th>
						</tr>
					</thead>
					<tbody class="go-sortable">

					<?php
					foreach ($rows as $row) {
					
						$instance = $webcash->{$row['alias']};
						
						$edit_start_tag = '<a href="'.$instance->getAddonSettingsUrl().'" title="'.__('Редактировать настройки платежного шлюза').'">';
						$payments_start_tag = '<a href="'.$instance->listtransactions->getAddonSettingsUrl('&tab2='.Plugins_ListTransactions::PAYMENTS_TAB.'&filter=field&val[a.gateway]='.$row['alias']).'" title="'.__('Посмотреть платежи для данного шлюза').'">';
				
						$additional_items = method_exists($instance, 'getGatewaysListDropdownItems') ? $instance->getGatewaysListDropdownItems() : '';
						
						echo '
						<tr id="'.$row['alias'].'">
							<td class="go-sortable-handle" title="'.__('Нажмите и перетащите для изменения порядка').'"></td>
							<td>'.$edit_start_tag.$row['name'].'</a></td>
							<td>'.$row['alias'].'</td>
							<td class="text-center">'.count($row['items']).'</td>
							<td class="text-center">'.$payments_start_tag.$webcash->db->selectCell("SELECT COUNT(*) FROM {$webcash->gateway_payments_table} WHERE gateway = '{$row['alias']}' AND state = 1").'</a></td>
							<td class="text-center">
								'.($row['on'] ? '<span title="'.__('Платежный шлюз включен').'" class="text-success tip"><b><i class="fa fa-check-circle"></i></b></span>' : '<span title="'.__('Платежный шлюз отключен').'" class="text-danger tip"><b><i class="fa fa-exclamation-circle"></i></b></span>').'
							</td>
							
							<td class="text-center">
								<div class="btn-group">
									<a href="#" class="dropdown-toggle nocolor" data-toggle="dropdown-webcash" aria-expanded="true"><i class="fa fa-bars"></i><span class="caret"></span></a>
									<ul class="dropdown-menu text-left pull-right">
										<li>'.$payments_start_tag.'<i class="fa fa-eye position-left"></i>'.__('Посмотреть платежи').'</a></li>
										<li>'.$edit_start_tag.'<i class="fa fa-pencil-square-o position-left"></i>'.__('Конфигурация').'</a></li>
										<li><a href="#" data-do="ajax-webcash" data-vars="action=ajax.from_tab'.Admin_Panel::GATEWAYS_TAB.'|subaction='.($row['on'] ? 'toggle_off' : 'toggle_on').'|addon_alias='.$row['alias'].'" title="'.($row['on'] ? __('Выключить платежный шлюз') : __('Включить платежный шлюз')).'"><i class="fa fa '.($row['on'] ? 'fa-check-circle text-success' : 'fa-exclamation-circle text-danger').' position-left"></i>'.($row['on'] ? __('Отключить') : __('Включить')).'</a></li>
										<li><a href="#" data-do="ajax-webcash" data-vars="action=ajax.from_tab'.Admin_Panel::GATEWAYS_TAB.'|subaction=delete_records_by_gateway|addon_alias='.$row['alias'].'" data-confirm="1" title="'.__('Удалить записи в таблицах инвойсов и платежей, относящиеся к данному шлюзу').'"><i class="fa fa-retweet position-left"></i>'.__('Очистить данные').'</a></li>
										'.($row['site_url'] ? '
										<li><a href="'.$row['site_url'].'" title="'.__('Перейти на сайт платежного шлюз').'" target="_blank"><i class="fa fa-link position-left"></i>'.__('Перейти на сайт').'</a></li>' : '').'
										
										'.$additional_items.'
										
										<li class="divider"></li>
										<li><a href="#" data-do="ajax-webcash" data-vars="action=ajax.from_tab'.Admin_Panel::GATEWAYS_TAB.'|subaction=delete|addon_alias='.$row['alias'].'" data-confirm="1" title="'.__('Удалить платежный шлюз').'"><i class="fa fa-trash-o position-left text-danger"></i>'.__('Удалить').'</a></li>
									</ul>
								</div>
							</td>
						</tr>';
					}
					?>
					
					</tbody>
				</table>
				
			</div>
			
			
            
            
			<?php } else { ?>
				<?php echo __('Нет записей'); ?>
			<?php } ?>
		
		
		</div>
		
		
		
	</div>
	<div class="buttons_wrap">
		<input type="hidden" name="action" value="ajax.from_tab<?php echo Admin_Panel::GATEWAYS_TAB; ?>" />
		<input type="hidden" name="user_hash" value="<?php echo $webcash->user->nonce; ?>" />
		
		<button type="button" class="btn bg-teal btn-raised position-left btn-green" onclick="return saveOrderingOnClick($(this))" data-vars="action=ajax.from_tab<?php echo Admin_Panel::GATEWAYS_TAB; ?>|subaction=update_ordering">
			<i class="fa fa-floppy-o position-left"></i><?php echo __('Сохранить порядок сортировки шлюзов'); ?>
		</button>		
		
	</div>
</form>

<script>
$(document).ready(function() {
	$("tbody.go-sortable").sortable();
});	
</script>
<?php } ?>