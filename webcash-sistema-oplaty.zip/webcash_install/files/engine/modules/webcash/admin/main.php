<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

(defined('DATALIFEENGINE') and defined('LOGGED_IN')) or exit('Access Denied');

if (!$webcash->user->isAdminGroup())
	exit('Access Denied');

$webcash->js_css->addCSSFile($webcash->rel_module_url.'admin/admin.css', true);

$webcash->js_css->addJsFile($webcash->rel_module_url.'kernel.js', true);
$webcash->js_css->addJsFile($webcash->rel_module_url.'admin/admin.js', true);

if ($webcash->helper->isVersionLess('12')) {
	$webcash->js_css->addCSSFile($webcash->rel_module_url.'admin/lib/bootstrap/css/bootstrap.css', true);
	$webcash->js_css->addCSSFile($webcash->rel_module_url.'admin/lib/bootstrap/css/bootstrap-theme.css', true);
	$webcash->js_css->addCSSFile($webcash->rel_module_url.'lib/jGrowl/jquery.jgrowl.min.css', true);
	$webcash->js_css->addCSSFile($webcash->rel_module_url.'admin/lib/fontawesome/styles.min.css', true);
	
	if ($webcash->helper->isVersionLess('10.2')) {
		$webcash->js_css->addJsFile($webcash->rel_module_url.'admin/lib/bootstrap/js/bootstrap.js', true);
	}
	$webcash->js_css->addJsFile($webcash->rel_module_url.'lib/jGrowl/jquery.jgrowl.min.js', true);
}


$tabs = array(
	array('id' => Admin_Panel::CONFIG_TAB, 'caption' => __('Настройки'), 'hint' => __('Настройки модуля')),
	array('id' => Admin_Panel::GATEWAYS_TAB, 'caption' => __('Шлюзы'), 'hint' => __('Список платежных шлюзов')),
	array('id' => Admin_Panel::PLUGINS_TAB, 'caption' => __('Плагины'), 'hint' => __('Список плагинов')),
	array('id' => Admin_Panel::UPGRADE_TAB, 'caption' => __('Обновления'), 'hint' => __('Обновления модуля'), 'header_html' => $webcash->adminpanel->getUpgradeTabCaption()),
);

if (!$active_tab = (int)GET('tab') or !in_array($active_tab, array_column($tabs, 'id')))
	$active_tab = Admin_Panel::CONFIG_TAB;

if ($active_tab == Admin_Panel::GATEWAYS_TAB or $active_tab == Admin_Panel::PLUGINS_TAB) {
	if ($webcash->helper->isVersionLess('10.2'))
		$webcash->js_css->addJsFile('/engine/skins/uisortable.js', true);
	else
		$webcash->js_css->addJsFile($webcash->rel_module_url.'admin/lib/jquery-ui-1.12.1.custom/jquery-ui.min.js', true);
}

echoheader(__('WebCash - система оплаты'), '<a href="'.$webcash->module_admin_url.'">'.__('WebCash - система оплаты').'</a>');


echo $webcash->js_css->renderCSSLinks();//Set stylesheet links
echo $webcash->js_css->renderCSSCode();//Set stylesheet declarations
echo $webcash->js_css->renderJsLinks();//Set script file links
echo $webcash->js_css->renderJsCode();//Set script declarations


echo $webcash->adminpanel->hint(__FILE__.'0', 'Для удобства работы можно использовать отправку форм по сочетанию клавиш <code>Ctrl + Enter</code>. Чтобы после окончания настроек отправить данные, кроме кнопки в нижней части формы, можно использовать сочетание данных клавиш.');
?>

<div class="panel">

	<div class="panel-header">
	
		<nav class="navbar navbar-default navbar-static-top">
			<?php $webcash->admin_admtopdropdownmenu->buildMenu(); ?>
		</nav>
		
		<ul class="nav nav-tabs nav-tabs-left">
			<?php foreach ($tabs as $tab) { ?>
			<li class="<?php echo ($active_tab == $tab['id']) ? 'active' : ''; ?>">
				<a <?php echo $webcash->adminpanel->buildChangeTabTagPart($tab['id']); ?> title="<?php echo $tab['hint']; ?>">
					<?php echo $tab['caption'].safe_array_access($tab, 'header_html'); ?>
				</a>
			</li>
			<?php } ?>
		</ul>
	</div>

	<div class="panel-content">
		<div class="tab-content">

			<div class="tab-pane active">
				<?php require_once $webcash->module_path.'admin/tab'.$active_tab.'.php'; ?>
			</div>
			
		</div>
	</div>

</div>


<div class="panel">
	<div class="panel-content">
		<div class="panel-body">
			&copy; <?php echo (date('Y') == 2019 ? '' : '2019 - ').date('Y').' '.__('Модуль <b>WebCash - система оплаты</b>. Версия ').'<b>'.$webcash->config->version.'</b>. '.__('Разработано в'); ?> <a href="http://new-dev.ru" target="_blank">New-Dev.ru</a>
		</div>
	</div>
</div>


<script>
var WEBCASH_OPTIONS = JSON.parse('<?php echo $webcash->helper->getJsOptions(); ?>');
</script>


<?php echo $webcash->js_css->renderHtmlCode(true);//Set HTML code ?>
<?php echo $webcash->js_css->renderCSSLinks(true);//Set stylesheet links ?>
<?php echo $webcash->js_css->renderJsLinks(true);//Set script file links ?>
<?php echo $webcash->js_css->renderJsCode(true);//Set script declarations ?>


<?php echofooter(); ?>