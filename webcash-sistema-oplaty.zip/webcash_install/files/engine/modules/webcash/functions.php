<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

use WebCash\WebCash;

defined('DATALIFEENGINE') or exit('Access Denied');

function wc_price($value) {
	return $value > 0 ? $value * 100 / 100 : 0;
}

function is_addon_class($class) {
	if (strpos($class, 'WebCash\\Plugins_') === 0 or strpos($class, 'WebCash\\Gateways_') === 0) {
		if (strpos($class, 'WebCash\\Plugins_Admin_') === false and strpos($class, 'WebCash\\Gateways_Admin_') === false) {
			return true;
		}
	}
	
	return false;
}

if (!function_exists('get_domain')) {
	function get_domain($url) {
		if ($host = @parse_url($url, PHP_URL_HOST)) {
			if (preg_match('/(?P<domain>[a-z0-9][a-z0-9\-]{1,63}\.[a-z\.]{2,6})$/i', $host, $matches)) {
				return strtolower($matches['domain']);
			}
		}
		
		return false;
	}
}

if (!function_exists('array_column')) {
    function array_column(array $input, $column_key, $index_key = null) {
        $array = array();
        foreach ($input as $value) {
		
            if (!array_key_exists($column_key, $value)) {
                trigger_error("Key \"{$column_key}\" does not exist in array");
                return false;
            }
			
            if (is_null($index_key)) {
                $array[] = $value[$column_key];
            } else {
                if (!array_key_exists($index_key, $value)) {
                    trigger_error("Key \"{$index_key}\" does not exist in array");
                    return false;
                }
				
                if (!is_scalar($value[$index_key])) {
                    trigger_error("Key \"{$index_key}\" does not contain scalar value");
                    return false;
                }
				
                $array[$value[$index_key]] = $value[$column_key];
            }
        }
		
        return $array;
    }
}

if (!function_exists('wc_handle_error')) {
	function wc_handle_error($type, $message, $file, $line, $context = null) {
		if (!(error_reporting() & $type)) {
			return;//этот код ошибки не включен в error_reporting
		}
		
		switch ($type) {
			case E_ERROR:
			case E_USER_ERROR:
				$type_title = 'Fatal Error';
				break;
			case E_PARSE:
				$type_title = 'Parse Error';
				break;
			case E_USER_WARNING:
			case E_WARNING:
				$type_title = 'Warning';
				break;
			case E_USER_NOTICE:
			case E_NOTICE:
				$type_title = 'Notice';
				break;
			case E_STRICT:
				$type_title = 'Strict Standart';
				break;
			case @E_DEPRECATED:
				$type_title = 'Deprecated';
				break;
			case @E_RECOVERABLE_ERROR:
				$type_title = 'Catchable';
				break;
			default:
				$type_title = 'Unknown Error';
		}
		
		$webcash = WebCash::instance();
		
		if ($webcash->helper->isAjax()) {
			if ($webcash->user->isAdminGroup())
				$webcash->helper->showMsgError($message, $type_title);
			else
				$webcash->helper->showMsgError($message);
		} else {
			if ($webcash->user->isAdminGroup())
				show_error_message($type_title, $message, $file, $line);
			else
				show_error_message($type_title, $message);
		}
	}
}

if (!function_exists('errno_to_title')) {
	function errno_to_title($type) {
		if ($type == 'Exception')
			return $type;
			
		$arr = array(
			E_ERROR => 'E_ERROR', E_WARNING => 'E_WARNING', E_PARSE => 'E_PARSE', E_NOTICE => 'E_NOTICE', E_STRICT => 'E_STRICT',
			E_CORE_ERROR => 'E_CORE_ERROR', E_CORE_WARNING => 'E_CORE_WARNING',
			E_COMPILE_ERROR => 'E_COMPILE_ERROR', E_COMPILE_WARNING => 'E_COMPILE_WARNING',
			E_USER_ERROR => 'E_USER_ERROR', E_USER_WARNING => 'E_USER_WARNING', E_USER_NOTICE => 'E_USER_NOTICE'
		);

		if (defined('E_DEPRECATED'))
			$arr[E_DEPRECATED] = 'E_DEPRECATED';

		return isset($arr[$type]) ? $arr[$type] : '';
	}
}

if (!function_exists('redirect_to')) {
	function redirect_to($location, $status_code = null) {
		$location = strip_tags($location);
		
		if (headers_sent()) {
			echo '<script type="text/javascript">';
			echo 'window.location.href="'.$location.'";';
			echo '</script>';
			echo '<noscript>';
			echo '<meta http-equiv="refresh" content="0;url='.$location.'" />';
			echo '</noscript>';
		} else {
			if ($status_code)
				header('Location: '.$location, true, $status_code);
			else
				header('Location: '.$location);

			exit;
		}
	}
}

if (!function_exists('only_alias')) {
	function only_alias($value) {
		return preg_replace('#[^0-9a-zA-Z\-\_\.]#', '', $value);
	}
}

if (!function_exists('only_float')) {
	function only_float($value) {
		return preg_replace('#[^0-9\.]#', '', $value);
	}
}

if (!function_exists('only_word')) {
	function only_word($str) {
		return preg_replace('#\W#', '', $str);
	}
}

if (!function_exists('COOKIE')) {
	function COOKIE($name) {
		return isset($_COOKIE[$name]) ? $_COOKIE[$name] : '';
	}
}

if (!function_exists('SESSION')) {
	function SESSION($name) {
		return isset($_SESSION[$name]) ? $_SESSION[$name] : '';
	}
}

if (!function_exists('POST')) {
	function POST() {
		$arg_list = func_get_args();
		$level = $_POST;
		
		foreach ($arg_list as $key) {

			if (!array_key_exists($key, $level)) {
				return '';
			}
			
			$level =& $level[$key];
		}
		
		return $level;
	}
}

if (!function_exists('GET')) {
	function GET() {
		if ($arr = $_GET) {
			$level =& $arr;
			$numargs = func_num_args();
			
			if ($numargs) {
				$arg_list = func_get_args();
				foreach ($arg_list as $key) {
				
					if (!array_key_exists($key, $level)) {
						return '';
					}
					
					$level =& $level[$key];
				}
			}

			return $level;
		}

		return '';
	}
}

if (!function_exists('filter_allowed_keys')) {
	function filter_allowed_keys($data, $allowed) {
		if ($data) {
			if (!is_array($allowed)) {
				$allowed = explode(',', $allowed);
				$allowed = array_map('trim', $allowed);
			}
			
			return array_intersect_key($data, array_flip($allowed));
		}
	}
}

if (!function_exists('array_rebuild')) {
	function array_rebuild($rows, $new_key) {
		$arr = array();
		
		if (!$rows)
			trigger_error('Пустой массив', E_USER_ERROR);
		if (!is_array($rows))
			trigger_error('Это не массив', E_USER_ERROR);
		
		foreach ($rows as $k => $row) {
			if (isset($row[$new_key])) {
				$arr[$row[$new_key]] = $row;
			}
		}
		
		return $arr ? $arr : array();
	}
}

if (!function_exists('safe_array_access')) {
	function safe_array_access($array) {
		if ($array and is_array($array)) {
			$numargs = func_num_args();
			$arg_list = func_get_args();

			for ($i = 1; $i < $numargs; $i++) {
				if ($array and (isset($array[$arg_list[$i]]) or array_key_exists($arg_list[$i], $array)))
					$array = $array[$arg_list[$i]];
				else
					return false;
			}
		}

		return $array;
	}
}

if (!function_exists('get_nested_var')) {
	function get_nested_var($array, $names) {
		if ($array and strpos($names, '|') !== false) {
			$args = explode('|', $names);
			array_unshift($args, $array);
			return call_user_func_array('safe_array_access', $args);
		}
	}
}

if (!function_exists('auto_convert')) {
	function auto_convert($text) {
		return is_utf8($text) ? __($text) : $text;
	}
}

if (!function_exists('is_russian')) {
	function is_russian($text) {
		return preg_match('#[А-Яа-яЁё]#u', $text);
	}
}

if (!function_exists('is_utf8')) {
	function is_utf8($string) {
		return preg_match('%(?:'
		  . '[\xC2-\xDF][\x80-\xBF]'                // non-overlong 2-byte
		  . '|\xE0[\xA0-\xBF][\x80-\xBF]'           // excluding overlongs
		  . '|[\xE1-\xEC\xEE\xEF][\x80-\xBF]{2}'    // straight 3-byte
		  . '|\xED[\x80-\x9F][\x80-\xBF]'           // excluding surrogates
		  . '|\xF0[\x90-\xBF][\x80-\xBF]{2}'        // planes 1-3
		  . '|[\xF1-\xF3][\x80-\xBF]{3}'            // planes 4-15
		  . '|\xF4[\x80-\x8F][\x80-\xBF]{2}'        // plane 16
		  . ')+%xs', $string);
	}
}

if (!function_exists('__')) {
	function __($text, $convert_encoding = true, $translate = true) {
		if (!$text)
			return '';
		
		if ($translate and $buffer = lang($text) and $buffer != $text) {
			$text = $buffer;
		} elseif ($convert_encoding) {
			$text = to_win1251($text);
		}
		
		return $text;
	}
}

if (!function_exists('lang')) {
	function lang($text) {
		if ($text) {
			if ($buffer = WebCash::instance()->helper->lang($text)) {
				$text = $buffer;
			}
		
			return $text;
		}
	}
}

if (!function_exists('to_win1251')) {
	function to_win1251($text) {
		if ($text) {
			if (WebCash::instance()->helper->isWin1251Charset()) {
				$text = mb_convert_encoding($text, 'WINDOWS-1251', 'UTF-8');
			}
			
			return $text;
		}
	}
}

if (!function_exists('to_utf8')) {
	function to_utf8($text) {
		if ($text and WebCash::instance()->helper->isWin1251Charset())
			$text = mb_convert_encoding($text, 'UTF-8', 'WINDOWS-1251');

		return $text;
	}
}

if (!function_exists('translit')) {
	function translit($text, $lower = true, $dash = true) {
		if ($lower) {
			$buff = mb_strtolower($text);
		} else {
			$buff = $text;
		}
		
		$buff = encodestring($buff);
		
		require_once ENGINE_DIR.'/modules/webcash/lib/Transliterator/Transliterator.php';
		
		$buff = \WebCash\Transliterator::convert($buff);
		
		$length = mb_strlen($buff);

		$replace = $dash ? '-' : '_';
		$result = '';
		for ($i = 0; $i < $length; $i++) {
			$ch = mb_substr($buff, $i, 1);
			$val = ord($ch);
			
			if ($ch == $replace or (47 < $val and $val < 58) or (64 < $val and $val < 91) or (96 < $val and $val < 123)) {
				$result .= $ch;
			} else {
				$result .= $replace;
			}
		}

		while (strpos($result, $replace.$replace) !== false)
			$result = str_replace($replace.$replace, $replace, $result);
			
		$result = trim($result, $replace);
		
		return $result;
	}
}

if (!function_exists('translit_filename')) {
	function translit_filename($filename, $lower = true) {
		$ext = pathinfo($filename, PATHINFO_EXTENSION);
		$str = basename($filename, $ext);
		$str = translit($str, $lower);
		return $str.'.'.$ext;
	}
}

if (!function_exists('encodestring')) {
	function encodestring($string) {
		$replace_pairs = array(
			'А' => 'A',
			'Б' => 'B',
			'В' => 'V',
			'Г' => 'G',
			'Д' => 'D',
			'Е' => 'E',
			'Ё' => 'YO',
			'Ж' => 'ZH',
			'З' => 'Z',
			'И' => 'I',
			'Й' => 'J',
			'К' => 'K',
			'Л' => 'L',
			'М' => 'M',
			'Н' => 'N',
			'О' => 'O',
			'П' => 'P',
			'Р' => 'R',
			'С' => 'S',
			'Т' => 'T',
			'У' => 'U',
			'Ф' => 'F',
			'Х' => 'H',
			'Ц' => 'C',
			'Ч' => 'CH',
			'Ш' => 'SH',
			'Щ' => 'CSH',
			'Ь' => '',
			'Ы' => 'Y',
			'Ъ' => '',
			'Э' => 'EH',
			'Ю' => 'YU',
			'Я' => 'YA',

			'а' => 'a',
			'б' => 'b',
			'в' => 'v',
			'г' => 'g',
			'д' => 'd',
			'е' => 'e',
			'ё' => 'yo',
			'ж' => 'zh',
			'з' => 'z',
			'и' => 'i',
			'й' => 'j',
			'к' => 'k',
			'л' => 'l',
			'м' => 'm',
			'н' => 'n',
			'о' => 'o',
			'п' => 'p',
			'р' => 'r',
			'с' => 's',
			'т' => 't',
			'у' => 'u',
			'ф' => 'f',
			'х' => 'h',
			'ц' => 'c',
			'ч' => 'ch',
			'ш' => 'sh',
			'щ' => 'csh',
			'ь' => '',
			'ы' => 'y',
			'ъ' => '',
			'э' => 'eh',
			'ю' => 'yu',
			'я' => 'ya',
		);
		
		$output = str_replace(array_keys($replace_pairs), array_values($replace_pairs), $string);
		
		return $output;
	}
}

if (!function_exists('fs_log')) {
	function fs_log($value, $showtime = false) {
		$filename = defined('ROOT_DIR') ? ROOT_DIR.'/+fs_log.txt' : './+fs_log.txt';

		if (is_array($value)) {
			ob_start();
			var_dump($value);
			$data = ob_get_clean();
			$log = fopen($filename, 'a');
			fwrite($log, $data);
			fwrite($log, "**********\n");
			fclose($log);

		} else {
			$log = fopen($filename, 'a');

			if ($showtime) {
				$time = date('Y-m-d H:i:s');
				fwrite($log, "{$value} ({$time})\n");
			} else {
				fwrite($log, "{$value}\n");
			}

			fclose($log);
		}
	}
}

if (!function_exists('print2')) {
	function print2($expression, $noexit = false) {
		if ($expression)
			echo '<pre>',print_r($expression, 1),'</pre>';
		else
			echo 'Empty expression';
		
		if (!$noexit)
			exit;
	}
}

if (!function_exists('print3')) {
	function print3($expression, $noexit = false) {
		if (empty($_COOKIE['mydebug']))
			return;
		
		print2($expression, $noexit);
	}
}

if (!function_exists('nd_decpoint')) {
	function nd_decpoint($value) {
		if ($value > 0 and is_float($value)) {
			$value = str_replace(',', '.', $value);
		}
		return $value;
	}
}

if (!function_exists('generate_call_trace')) {
	function generate_call_trace() {
		$e = new \Exception();
		
		$trace = explode("\n", get_exception_trace_as_string($e));
		$trace = array_reverse($trace);
		$trace = array_slice($trace, 1, -3);
		$length = count($trace);
		$result = array();

		for ($i = 0; $i < $length; $i++) {
			$str = $trace[$i];
			$str = str_replace(ROOT_DIR, '', $str);
			$result[] = ($i + 1).')'.substr($str, mb_strpos($str, ' '));
		}

		return "\t".implode("<br>\r\n\t", $result).'<br>';
	}
}

function show_error_message($title, $text, $file = '', $line = 0) {

	if ($file) {
		$trace = generate_call_trace();
	}
	
	$html  = '
	<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
	<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru" lang="ru">	
	<head>
		<title>'.to_win1251($title).'</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<style type="text/css">
		<!--
		body {
			font-family: Verdana, Arial, Helvetica, sans-serif;
			font-size: 11px;
			font-style: normal;
			color: #000000;
		}
		.top {
			color: #ffffff;
			font-size: 15px;
			font-weight: bold;
			padding-left: 20px;
			padding-top: 10px;
			padding-bottom: 10px;
			text-shadow: 0 1px 1px rgba(0, 0, 0, 0.75);
			background-color: #AB2B2D;
			background-image: -moz-linear-gradient(top, #CC3C3F, #982628);
			background-image: -ms-linear-gradient(top, #CC3C3F, #982628);
			background-image: -webkit-gradient(linear, 0 0, 0 100%, from(#CC3C3F), to(#982628));
			background-image: -webkit-linear-gradient(top, #CC3C3F, #982628);
			background-image: -o-linear-gradient(top, #CC3C3F, #982628);
			background-image: linear-gradient(top, #CC3C3F, #982628);
			filter: progid:DXImageTransform.Microsoft.gradient( startColorstr="#CC3C3F", endColorstr="#982628",GradientType=0 ); 
			background-repeat: repeat-x;
			border-bottom: 1px solid #ffffff;
		}
		.box {
			margin: 10px;
			padding: 4px;
			background-color: #EFEDED;
			border: 1px solid #DEDCDC;
		}
		-->
		</style>
	</head>
	<body>
		<div style="width: 90%;margin: 20px; border: 1px solid #D9D9D9; background-color: #F1EFEF; -moz-border-radius: 5px; -webkit-border-radius: 5px; border-radius: 5px; -moz-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3); -webkit-box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3); box-shadow: 0px 0px 8px rgba(0, 0, 0, 0.3);" >
			<div class="top">'.to_win1251($title).'</div>
			'.($file ? '<div class="box"><b>'.to_win1251($title).'</b> in file: <b>'.str_replace(ROOT_DIR, '', $file).'</b> at line <b>'.$line.'</b></div>' : '').'
			<div class="box"><b style="white-space:pre-wrap;">'.to_win1251(str_replace(ROOT_DIR, '', $text)).'</b></div>
			'.($trace ? '<div class="box"><b>Call trace:</b><br />'.$trace.'</div>' : '').'
		</div>
	</body>
	</html>';

	echo $html;
	exit;
}

function get_exception_trace_as_string($exception) {
    $rtn = '';
    $count = 0;
	
    foreach ($exception->getTrace() as $frame) {
        $args = '';
        if (isset($frame['args'])) {
            $args = array();
            foreach ($frame['args'] as $arg) {
                if (is_string($arg)) {
					if (mb_strlen($arg, 'UTF-8') > 255)
						$args[] = "'String too large...'";
					else
						$args[] = "'" . $arg . "'";
                } elseif (is_array($arg)) {
                    $args[] = "Array";
                } elseif (is_null($arg)) {
                    $args[] = 'NULL';
                } elseif (is_bool($arg)) {
                    $args[] = ($arg) ? "true" : "false";
                } elseif (is_object($arg)) {
                    $args[] = get_class($arg);
                } elseif (is_resource($arg)) {
                    $args[] = get_resource_type($arg);
                } else {
                    $args[] = $arg;
                }   
            }   
            $args = join(', ', $args);
        }
		
        $rtn .= sprintf("#%s %s(%s): %s(%s)\n",
			$count,
			$frame['file'],
			$frame['line'],
			$frame['function'],
			$args
		);
		
        $count++;
    }
	
    return $rtn;
}