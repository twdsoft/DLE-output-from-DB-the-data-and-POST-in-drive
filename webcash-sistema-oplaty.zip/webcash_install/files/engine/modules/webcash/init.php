<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

if (!class_exists('WebCash\WebCash', false)) {
	defined('DATALIFEENGINE') or exit('Access Denied');

	defined('WC_ERROR_REPORTING') or define('WC_ERROR_REPORTING', 1);//1 or 2 or 3 or 4
	//1 - without E_STRICT and E_DEPRECATED and E_NOTICE and E_WARNING
	//or 2 - without E_STRICT and E_DEPRECATED and E_NOTICE
	//or 3 - without E_STRICT and E_DEPRECATED
	//or 4 - ALL
	
	switch (WC_ERROR_REPORTING) {
		case 1: $a = -1 ^ E_STRICT ^ E_DEPRECATED ^ E_NOTICE ^ E_WARNING; break;
		case 2: $a = -1 ^ E_STRICT ^ E_DEPRECATED ^ E_NOTICE; break;
		case 3: $a = -1 ^ E_STRICT ^ E_DEPRECATED; break;
		default: $a = -1;
	}
	error_reporting($a);//����� ������

	require ENGINE_DIR.'/modules/webcash/functions.php';
	set_error_handler('wc_handle_error');
	
	require ENGINE_DIR.'/modules/webcash/classes/autoloader.class.php';
	
	$autoloader = new Autoloader();
}

if (empty($webcash) or !is_object($webcash)) {
	$webcash = WebCash::instance();
}
