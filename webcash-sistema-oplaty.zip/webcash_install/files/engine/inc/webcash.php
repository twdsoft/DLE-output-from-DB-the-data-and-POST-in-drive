<?php
/**
 * http://new-dev.ru/
 * author GoldSoft <newdevexpert@gmail.com>
 * Copyright (c) New-Dev.ru
 */

namespace WebCash;

(defined('DATALIFEENGINE') and defined('LOGGED_IN')) or exit('Access Denied');

define('IN_ADMINPANEL', true);

require ENGINE_DIR.'/modules/webcash/init.php';


if (strpos(POST('action'), 'ajax.') !== false) {
	require_once $webcash->module_path.'admin/ajax.php';
} else {
	require_once $webcash->module_path.'admin/main.php';
}