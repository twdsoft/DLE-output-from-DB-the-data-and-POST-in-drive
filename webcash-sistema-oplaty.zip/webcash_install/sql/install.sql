DELETE FROM `dle_admin_sections` WHERE name = 'WebCash';
INSERT INTO `dle_admin_sections` (`name`, `title`, `descr`, `icon`, `allow_groups`) VALUES ('WebCash', 'WebCash - система оплаты', 'Система оплаты', 'webcash.png', '1');



DROP TABLE IF EXISTS `dle_webcash_admtopdropdownmenu_base`;
CREATE TABLE IF NOT EXISTS `dle_webcash_admtopdropdownmenu_base` (
`id` SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
`caption` CHAR(150) NOT NULL DEFAULT '',
`hint` CHAR(255) NOT NULL DEFAULT '',
`url` CHAR(255) NOT NULL DEFAULT '',
`parent_id` SMALLINT UNSIGNED NOT NULL DEFAULT 0,
`content` TEXT NOT NULL,
`ordering` SMALLINT UNSIGNED NOT NULL DEFAULT 0,
`attribs` TEXT NOT NULL,
`is_favorite` TINYINT(1) UNSIGNED NOT NULL DEFAULT 0,
`is_homepage` TINYINT(1) UNSIGNED NOT NULL DEFAULT 0,
`created` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
`state` TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=MyISAM CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE INDEX dle_webcash_admtopdropdownmenu_base_Index1 ON dle_webcash_admtopdropdownmenu_base(`ordering`);
CREATE INDEX dle_webcash_admtopdropdownmenu_base_Index2 ON dle_webcash_admtopdropdownmenu_base(`state`);



DROP TABLE IF EXISTS `dle_webcash_webmoney_gw_items`;
CREATE TABLE IF NOT EXISTS `dle_webcash_webmoney_gw_items` (
`id` MEDIUMINT(8) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
`title` CHAR(255) NOT NULL DEFAULT '',
`image` CHAR(25) NOT NULL DEFAULT '',
`LMI_ALLOW_SDP` TINYINT(1) NOT NULL DEFAULT 0,
`LMI_SDP_TYPE` TINYINT(1) NOT NULL DEFAULT 0,
`at` CHAR(15) NOT NULL DEFAULT '',
`description` CHAR(255) NOT NULL DEFAULT '',
`ordering` SMALLINT NOT NULL DEFAULT 0,
`created` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
`state` TINYINT(1) UNSIGNED NOT NULL DEFAULT 1
) ENGINE=MyISAM CHARACTER SET utf8 COLLATE utf8_general_ci AUTO_INCREMENT=1;

CREATE INDEX `webcash_webmoney_gw_items_Index1` ON `dle_webcash_webmoney_gw_items` (`state`);
CREATE INDEX `webcash_webmoney_gw_items_Index2` ON `dle_webcash_webmoney_gw_items` (`ordering`);

INSERT INTO `dle_webcash_webmoney_gw_items` (`title`, `image`, `LMI_ALLOW_SDP`, `LMI_SDP_TYPE`, `at`) VALUES
('Webmoney WMZ', 'wmlogo2.png', -1, -1, ''),
('Webmoney WMR', 'wmlogo2.png', -1, -1, ''),
('Банковская карта', 'visa_mastercard_logo.png', 4, 4, ''),
('Сбербанк Онлайн', 'sbo.png', 14, 14, ''),
('МТС', 'mts.png', 11, 11, ''),
('Билайн', 'beeline.png', 12, 12, ''),
('Мобильная коммерция', 'mobile.png', -1, -1, 'authtype_19'),
('Платеж с мобильного', 'mbc.png', -1, -1, 'authtype_17'),
('Bitcoin', 'bitc.png', 19, 19, ''),
('Терминалы оплаты', 'pm.png', 8, 8, ''),
('Денежный перевод', 'bnk.png', 0, 0, ''),
('Интернет банк', 'bnk.png', -1, -1, 'authtype_18'),
('Почта РФ', 'prr.png', -1, -1, 'authtype_11'),
('WM-карта или Paymer', 'ppr.png', -1, -1, 'authtype_3'),
('Альфа-клик', 'ab.png', 3, 3, ''),
('Русский Стандарт', 'rstand.png', 5, 5, '');



DROP TABLE IF EXISTS `dle_webcash_sheduledtasks`;
CREATE TABLE IF NOT EXISTS `dle_webcash_sheduledtasks` (
`id` MEDIUMINT(8) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
`command` CHAR(255) NOT NULL DEFAULT '',
`interval` INT(11) UNSIGNED NOT NULL DEFAULT 0,
`description` CHAR(255) NOT NULL DEFAULT '',
`created` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
`state` TINYINT(1) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=MyISAM CHARACTER SET utf8 COLLATE utf8_general_ci AUTO_INCREMENT=1;

CREATE INDEX `webcash_sheduledtasks_Index1` ON `dle_webcash_sheduledtasks` (`state`);



DROP TABLE IF EXISTS `dle_webcash_balance_transactions`;
CREATE TABLE IF NOT EXISTS `dle_webcash_balance_transactions` (
`id` MEDIUMINT(8) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
`amount` DECIMAL(10,2) UNSIGNED NOT NULL DEFAULT 0,
`user_id` INT(11) UNSIGNED NOT NULL DEFAULT 0,
`is_plus` TINYINT(1) UNSIGNED NOT NULL DEFAULT 0,
`area_alias` CHAR(30) NOT NULL DEFAULT '',
`rel_item_type` TINYINT(1) UNSIGNED NOT NULL DEFAULT 1,
`rel_item_id` MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT 0,
`created` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
`state` TINYINT(1) UNSIGNED NOT NULL DEFAULT 1
) ENGINE=MyISAM CHARACTER SET utf8 COLLATE utf8_general_ci AUTO_INCREMENT=1;

CREATE INDEX `webcash_balance_transactions_Index1` ON `dle_webcash_balance_transactions` (`amount`);
CREATE INDEX `webcash_balance_transactions_Index2` ON `dle_webcash_balance_transactions` (`user_id`);
CREATE INDEX `webcash_balance_transactions_Index3` ON `dle_webcash_balance_transactions` (`is_plus`);
CREATE INDEX `webcash_balance_transactions_Index4` ON `dle_webcash_balance_transactions` (`area_alias`);
CREATE INDEX `webcash_balance_transactions_Index5` ON `dle_webcash_balance_transactions` (`rel_item_type`);
CREATE INDEX `webcash_balance_transactions_Index6` ON `dle_webcash_balance_transactions` (`rel_item_id`);
CREATE INDEX `webcash_balance_transactions_Index7` ON `dle_webcash_balance_transactions` (`created`);



DROP TABLE IF EXISTS `dle_webcash_gateway_invoices`;
CREATE TABLE IF NOT EXISTS `dle_webcash_gateway_invoices` (
`id` MEDIUMINT(8) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
`amount` DECIMAL(10,2) UNSIGNED NOT NULL DEFAULT 0,
`gateway` CHAR(25) NOT NULL DEFAULT '',
`user_id` INT(11) UNSIGNED NOT NULL DEFAULT 0,
`email` CHAR(50) NOT NULL DEFAULT '',
`ip` INT(11) UNSIGNED NOT NULL DEFAULT 0,
`area_alias` CHAR(30) NOT NULL DEFAULT '',
`rel_item_type` TINYINT(1) UNSIGNED NOT NULL DEFAULT 1,
`rel_item_id` MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT 0,
`checkout_store` TEXT NOT NULL,
`created` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
`state` TINYINT(1) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=MyISAM CHARACTER SET utf8 COLLATE utf8_general_ci AUTO_INCREMENT=1;

CREATE INDEX `webcash_gateway_invoices_Index1` ON `dle_webcash_gateway_invoices` (`amount`);
CREATE INDEX `webcash_gateway_invoices_Index2` ON `dle_webcash_gateway_invoices` (`gateway`);
CREATE INDEX `webcash_gateway_invoices_Index3` ON `dle_webcash_gateway_invoices` (`user_id`);
CREATE INDEX `webcash_gateway_invoices_Index4` ON `dle_webcash_gateway_invoices` (`email`);
CREATE INDEX `webcash_gateway_invoices_Index5` ON `dle_webcash_gateway_invoices` (`ip`);
CREATE INDEX `webcash_gateway_invoices_Index6` ON `dle_webcash_gateway_invoices` (`area_alias`);
CREATE INDEX `webcash_gateway_invoices_Index7` ON `dle_webcash_gateway_invoices` (`rel_item_type`);
CREATE INDEX `webcash_gateway_invoices_Index8` ON `dle_webcash_gateway_invoices` (`rel_item_id`);
CREATE INDEX `webcash_gateway_invoices_Index9` ON `dle_webcash_gateway_invoices` (`created`);
CREATE INDEX `webcash_gateway_invoices_Index10` ON `dle_webcash_gateway_invoices` (`state`);



DROP TABLE IF EXISTS `dle_webcash_gateway_payments`;
CREATE TABLE IF NOT EXISTS `dle_webcash_gateway_payments` (
`id` MEDIUMINT(8) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
`invoice_id` MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT 0,
`amount` DECIMAL(10,2) UNSIGNED NOT NULL DEFAULT 0,
`sender` CHAR(50) NOT NULL DEFAULT '',
`gateway` CHAR(25) NOT NULL DEFAULT '',
`user_id` INT(11) UNSIGNED NOT NULL DEFAULT 0,
`email` CHAR(60) NOT NULL DEFAULT '',
`ip` INT(11) UNSIGNED NOT NULL DEFAULT 0,
`gateway_details` TEXT NOT NULL,
`area_alias` CHAR(30) NOT NULL DEFAULT '',
`rel_item_type` TINYINT(1) UNSIGNED NOT NULL DEFAULT 1,
`rel_item_id` MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT 0,
`created` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
`state` TINYINT(1) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=MyISAM CHARACTER SET utf8 COLLATE utf8_general_ci AUTO_INCREMENT=1;

CREATE UNIQUE INDEX `webcash_gateway_payments_Index1` ON `dle_webcash_gateway_payments` (`invoice_id`);
CREATE INDEX `webcash_gateway_payments_Index2` ON `dle_webcash_gateway_payments` (`sender`);
CREATE INDEX `webcash_gateway_payments_Index3` ON `dle_webcash_gateway_payments` (`gateway`);
CREATE INDEX `webcash_gateway_payments_Index4` ON `dle_webcash_gateway_payments` (`user_id`);
CREATE INDEX `webcash_gateway_payments_Index5` ON `dle_webcash_gateway_payments` (`email`);
CREATE INDEX `webcash_gateway_payments_Index6` ON `dle_webcash_gateway_payments` (`ip`);
CREATE INDEX `webcash_gateway_payments_Index7` ON `dle_webcash_gateway_payments` (`area_alias`);
CREATE INDEX `webcash_gateway_payments_Index8` ON `dle_webcash_gateway_payments` (`rel_item_type`);
CREATE INDEX `webcash_gateway_payments_Index9` ON `dle_webcash_gateway_payments` (`rel_item_id`);
CREATE INDEX `webcash_gateway_payments_Index10` ON `dle_webcash_gateway_payments` (`created`);



DROP TABLE IF EXISTS `dle_webcash_admin_settings`;
CREATE TABLE IF NOT EXISTS `dle_webcash_admin_settings` (
`id` MEDIUMINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
`user_id` MEDIUMINT UNSIGNED NOT NULL DEFAULT 0,
`param` CHAR(60) NOT NULL DEFAULT '',
`i_value` MEDIUMINT UNSIGNED NOT NULL DEFAULT 0,
`c_value` CHAR(255) NOT NULL DEFAULT '',
`t_value` TEXT NOT NULL
) ENGINE=MyISAM CHARACTER SET utf8 COLLATE utf8_general_ci;

CREATE UNIQUE INDEX `webcash_admin_settings_Index1` ON `dle_webcash_admin_settings` (`user_id`, `param`);



DROP TABLE IF EXISTS `dle_webcash_megakassa_gw_items`;
CREATE TABLE IF NOT EXISTS `dle_webcash_megakassa_gw_items` (
`id` MEDIUMINT(8) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
`title` CHAR(255) NOT NULL DEFAULT '',
`image` CHAR(50) NOT NULL DEFAULT '',
`method_id` SMALLINT NOT NULL DEFAULT 0,
`optional` TINYINT(1) NOT NULL DEFAULT 0,
`description` CHAR(255) NOT NULL DEFAULT '',
`ordering` SMALLINT NOT NULL DEFAULT 0,
`created` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
`state` TINYINT(1) UNSIGNED NOT NULL DEFAULT 1
) ENGINE=MyISAM CHARACTER SET utf8 COLLATE utf8_general_ci AUTO_INCREMENT=1;

CREATE INDEX `webcash_megakassa_gw_items_Index1` ON `dle_webcash_megakassa_gw_items` (`state`);
CREATE INDEX `webcash_megakassa_gw_items_Index2` ON `dle_webcash_megakassa_gw_items` (`ordering`);

INSERT INTO `dle_webcash_megakassa_gw_items` (`title`, `image`, `method_id`, `optional`) VALUES
('Банковская карта', 'visa_mastercard_logo.png', 8, 0),
('Visa, MasterCard, Maestro, МИР RUB', 'visa_mastercard_maestro_mir_rub.png', 69, 1),
('Сбербанк Онлайн RUB', 'sberbank_onlajn_rub.png', 42, 1),
('Perfect Money USD', 'perfect_money_usd.png', 2, 0),
('Perfect Money EUR', 'perfect_money_eur.png', 3, 0),
('Qiwi Wallet RUB', 'qiwi_wallet_rub.png', 22, 0),
('Яндекс.Деньги RUB', 'yandeks_dengi_rub.png', 1, 0),
('Альфа-Клик RUB', 'alfa_klik_rub.png', 39, 0),
('Bitcoin', 'bitc.png', 53, 0),
('WebMoney RUB', 'webmoney_rub.png', 16, 0),
('WebMoney USD', 'webmoney_usd.png', 17, 0),
('WebMoney EUR', 'webmoney_eur.png', 18, 0),
('Тинькофф Банк RUB', 'tinkoff_bank_rub.png', 94, 1),
('Евросеть RUB', 'tinkoff_bank_rub.png', 32, 0),
('Билайн RUB', 'beeline.png', 64, 0),
('Связной RUB', 'svyaznoj_rub.png', 33, 0),
('Платежные терминалы России RUB', 'platezhnye_terminaly_rossii_rub.png', 37, 0),
('Банковский перевод RUB', 'bankovskij_perevod_rub.png', 57, 0),
('Payeer RUB', 'payeer_rub.png', 62, 0),
('Payeer USD', 'payeer_usd.png', 91, 0),
('Tele2 RUB', 'tele2_rub.png', 63, 0),
('Мегафон RUB', 'megafon_rub.png', 82, 0),
('МТС RUB', 'mts_rub.png', 83, 0),
('Litecoin USD', 'litecoin_usd.png', 86, 0),
('Bitcoin Cash USD', 'bitcoin_cash_usd.png', 87, 0),
('Dash USD', 'dash_usd.png', 88, 0),
('Dogecoin USD', 'dogecoin_usd.png', 89, 0),
('Платежные терминалы СНГ RUB', 'platezhnye_terminaly_sng_rub.png', 95, 1),
('ЕРИП (Беларусь) RUB', 'erip_belarus_rub.png', 96, 1);