DELETE FROM `dle_admin_sections` WHERE name = 'WebCash';

DROP TABLE IF EXISTS `dle_webcash_admtopdropdownmenu_base`;

DROP TABLE IF EXISTS `dle_webcash_webmoney_gw_items`;

DROP TABLE IF EXISTS `dle_webcash_sheduledtasks`;

DROP TABLE IF EXISTS `dle_webcash_payfixednews_check_expired`;

DROP TABLE IF EXISTS `dle_webcash_balance_transactions`;
DROP TABLE IF EXISTS `dle_webcash_invoices`;
DROP TABLE IF EXISTS `dle_webcash_payments`;
DROP TABLE IF EXISTS `dle_webcash_admin_settings`;


DROP TABLE IF EXISTS `dle_webcash_upbalancepromocode_codes`;
DROP TABLE IF EXISTS `dle_webcash_upbalancepromocode_attempts`;


DROP TABLE IF EXISTS `dle_webcash_payhidecontent_tags`;
DROP TABLE IF EXISTS `dle_webcash_payhidecontent_tags_payments`;


DROP TABLE IF EXISTS `dle_webcash_megakassa_gw_items`;