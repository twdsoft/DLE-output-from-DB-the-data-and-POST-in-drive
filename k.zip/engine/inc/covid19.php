<?php

/*
=====================================================
File: covid19.php
-----------------------------------------------------
Made: Dmitry Dark5ider                     
-----------------------------------------------------
Contacts: t.me/dmitry_tsum
-----------------------------------------------------
Use: COVID INFORMER INC.           v.1.2  30.04.2020
=====================================================
*/


// Время на Москву
date_default_timezone_set('Etc/GMT-3');

if( !defined( 'DATALIFEENGINE' ) OR !defined( 'LOGGED_IN' ) ) {
	header( "HTTP/1.1 403 Forbidden" );
	header ( 'Location: ../../' );
	die( "Hacking attempt!" );
}

if( !$user_group[$member_id['user_group']]['admin_banners'] ) {
	msg( "error", $lang['index_denied'], $lang['index_denied'] );
}

$mod = 'covid19';

function showMenu ($active) {
	global $mod;
	
	$menArr = Array(
			'main' => Array('title' => 'Главная','icon' => '<i class="fa fa-home"></i>&nbsp;', 'tip' => 'Информация о использовании модуля'),
			'settings' => Array('title' => 'Настройки','icon' => '<i class="fa fa-cog"></i>&nbsp; ', 'tip' => 'Общие настройки скрипта'),
			'infoweb' => Array('title' => 'Информация','icon' => '<i class="fa font-primary fa-info-circle"></i>&nbsp;', 'tip' => 'Информация о тегах в шаблонах'),
	);
	
	
	$menu = '<div class="navbar navbar-default navbar-component navbar-xs systemsettings">
	<ul class="nav navbar-nav visible-xs-block">
		<li class="full-width text-center"><a data-toggle="collapse" data-target="#navbar-filter"><i class="fa fa-bars"></i></a></li>
	</ul>
	<div class="navbar-collapse collapse" id="navbar-filter">
		<ul class="nav navbar-nav">
	';
	
	foreach ($menArr as $action => $val) $menu .= '<li class="'.(($action == $active) ? ' active' : '').''.(($val[disabled] == 'yes') ? ' disabled' : '').'"><a class="tip" title="'.$val[tip].'" href="'.(($val[exlink]) ? $val[exlink] : '?mod='.$mod.'&action='.$action).'" '.(($val[exlink]) ? 'target="_blanck"' : '').'>'.$val[icon].''.$val[title].'</a></li>';
	
	$menu .='</ul></div></div>';
		
		echo $menu;
		
}

function showRow($title = "", $description = "", $field = "", $class = "") {
		
		$html = "<tr>
        <td class=\"col-xs-6 col-sm-6 col-md-7\"><h6 class=\"media-heading text-semibold\">{$title}</h6><span class=\"text-muted text-size-small hidden-xs\">{$description}</span></td>
        <td class=\"col-xs-6 col-sm-6 col-md-5\">{$field}</td>
        </tr>";
		
		echo $html;
	}

function makeCheckBox($name, $selected) {

		$selected = $selected ? "checked" : "";
	
		return "<input class=\"switch\" type=\"checkbox\" name=\"{$name}\" value=\"1\" {$selected}>";

}

include_once (DLEPlugins::Check(ENGINE_DIR . '/plugins/covid19/data/config.php'));

if ( !$action ) $action = "main";

// Вывод списоком всех игр
if ($action == 'main') { // Информация

	echoheader( "<i class=\"fa fa-home position-left\"></i><span class=\"text-semibold\">Корона.Инфо</span>", array('?mod='.$mod => 'Корона.Инфо', '' => 'Общая информация о плагине' ) );

	showMenu($action);  
	
	$file_date = @filemtime( ENGINE_DIR . "/plugins/covid19/data/cache/data.tmp" );
	$lastCacheDate = langdate("H:i, d.m.Y", $file_date  );
	
echo '<div class="panel panel-default">
		<div class="panel-heading">
			Плагин вывода информации о коронавирусе (Covid-19) в России и Мире.
		</div>
		<div class="panel-body">
			<table class="table">
				<tr>
					<td>Автор:</td>
					<td><a href="https://t.me/dmitry_tsum" target="_blanck">Dmitry Dark5ider</a></td>
				</tr>
				<tr>
					<td>Сайт:</td>
					<td><a href="https://dle-store.ru" target="_blanck">DLE.Store</a></td>
				</tr>
				<tr>
					<td>Статистика обновлена:</td>
					<td>'.$lastCacheDate.'</td>
				</tr>
			</table>
		</div>
	</div>
	';

} elseif ($action == 'infoweb') { // Информация для разработчиков
	
	echoheader( "<i class=\"fa fa-info position-left\"></i><span class=\"text-semibold\">Информация о шаблонах вывода</span>", array('?mod='.$mod => 'Корона.Инфо', '' => 'Информация о тегах' ) );

		showMenu($action);  

	  
echo <<<HTML

<div class="alert alert-info alert-styled-left alert-arrow-left alert-component">

Для правильной (и красивой) работы плагина не забудьте вставить это между тегами <strong>&lt;head>...&lt;/head></strong> в <strong>main.tpl</strong><br>
<br>

<code>&lt;link href="/engine/plugins/covid19/assets/css/style.css" rel="stylesheet">
&lt;link href="/engine/plugins/covid19/assets/css/datatables.min.css" rel="stylesheet">
&lt;script type="text/javascript" src="/engine/plugins/covid19/assets/js/datatables.min.js">&lt;/script>
</code>
<br>
<br>
<p>Если используете вывод графиков заражений на сайте, то дополнительно подключите:</p>
<code>&lt;script type="text/javascript" src="/engine/plugins/covid19/assets/js/chart.js">&lt;/script>
&lt;script type="text/javascript" src="/engine/plugins/covid19/assets/js/frontend.js">&lt;/script></code>

</div>


<div class="alert alert-info alert-styled-left alert-arrow-left alert-component">Всего существует 5 (пять) вариантов вывода информации. Таблица регионов и стран в конце данной страницы.</div>

<div class="panel panel-default">
	<div class="panel-heading">
		<strong>Вариант 1. Таблица [table]</strong>
	</div>
	
	<div class="panel-body">
	
	В данном случае выводится таблица (или несколько, вообщем сколько хотите) с информацией по столбам: "Заражено, Сегодня заражено, Погибло, Сегодня погибло, Вылечено"
	<br/><br/>
	Два типа вывода таблицы: По странам и По городам России.<br/><br/>
	
	<strong><code>{covid19 type="table"}</code></strong><em>Выводит таблицу по Миру</em><br/><br/>
	<strong><code>{covid19 type="table" country="Russia"}</code></strong><em>Выводит таблицу по России</em><br/><br/>
	
	Параметр <strong>per_page</strong> контролирует сколько выводить на одной странице (там если что постраничная навигация на JS сделана), по умолчанию по 10 на страницу.<br/><br/>
	
	<strong><code>{covid19 type="table" per_page="30"}</code></strong><em>Выводит таблицу по Миру, 30 строк на страницу</em><br/>
	
	</div>

</div>

<div class="panel panel-default">
	<div class="panel-heading">
		<strong>Вариант 2. Список [list]</strong>
	</div>
	
	<div class="panel-body">
	
	Выводит списком таблицу статистики по всем Странам с флагами или регионам России, фиксированной высоты со скроллингом. Поля: "Заражено, Погибло, Вылечено"<br/><br/>
	
	<strong><code>{covid19 type="list"}</code></strong><em>Выводит список заболеваний по Миру</em><br/><br/>
	<strong><code>{covid19 type="list" country="Russia"}</code></strong><em>Выводит список заболеваний по России</em><br/><br/>
	
	Параметр <strong>dark_mode</strong> может принимать единственное значение "<strong>yes</strong>" и тем самым применят темную тему для вывода списка.<br/><br/>

	<strong><code>{covid19 type="list" dark_mode="yes"}</code></strong><em>Выводит список заболеваний по Миру, в "темной теме" списка</em><br/>

	</div>

</div>

<div class="panel panel-default">
	<div class="panel-heading">
		<strong>Вариант 3. Бегущая строка  [line]</strong>
	</div>
	
	<div class="panel-body">
	
	Выводит бегущей строкой <em>(стили редактируются в <strong>style.css</strong>)</em> статистику По всему миру, по конкретной стране, по Российскому региону. Поля: "Заражено (+Сколько за сегодня), Погибло (+Сколько за сегодня), Вылечено, Зараженных".<br/><br/>
	
	<strong><code>{covid19 type="line"}</code></strong><em>Выводит строку заболеваний по Миру</em><br/><br/>
	<strong><code>{covid19 type="line" country="Russia"}</code></strong><em>Выводит строку заболеваний по России</em><br/><br/>
	<strong><code>{covid19 type="line" country="Ukraine" region="Zhytomyrskа"}</code></strong><em>Выводит строку заболеваний в Житомирской области.</em><br/><br/>
	
	</div>

</div>

<div class="panel panel-default">
	<div class="panel-heading">
		<strong>Вариант 4. Блок [box]</strong>
	</div>
	
	<div class="panel-body">
		Выводит информацию по Всему миру, Стране, региону России, области Украины, в виде блока с разными стилями (всего 5). Взаимоисключающие параметры <strong>country</strong> и <strong>region</strong>, если пишете один, то второй работать не будет.<br/><br/>
		
		<strong><code>{covid19 type="box"}</code></strong><em>Выводит блок со статистикой заболеваний по Миру</em><br/><br/>
		
		<strong><code>{covid19 type="box" country="USA"}</code></strong><em>Выводит блок со статистикой заболеваний в США</em><br/><br/>
		
		<strong><code>{covid19 type="box" country="Russia" region="permskij-kraj"}</code></strong><em>Выводит блок со статистикой заболеваний в Пермском Крае</em><br/><br/>
		
		Для смены стиля вывода блока существует параметр <strong>style</strong> который по умолчанию равен 1, и может принимать значения от 2-5, попробуйте все 5 стилей, чтобы найти тот, который подходит именно вам.<br/><br/>
		
		<strong><code>{covid19 type="box" style="5" country="Russia" region="sankt-peterburg"}</code></strong><em>Выводит блок со статистикой заболеваний в Санкт-Петербурге в пятом стиле.</em><br/><br/>

		Также как и в выводе списком доступен "темный режим" блока с параметром <strong>dark_mode="yes"</strong>.<br/><br/>
		
		<strong><code>{covid19 type="box" style="5" country="Russia" region="sankt-peterburg" dark_mode="yes"}</code></strong><em>Выводит блок со статистикой заболеваний в Санкт-Петербурге в пятом стиле, в темном режиме.</em><br/><br/>
		
	</div>

</div>

<div class="panel panel-default">
	<div class="panel-heading">
		<strong>Вариант 5. Диаграмма  [chart]</strong>
	</div>
	
	<div class="panel-body">
	
	Выводит диаграммой статистику по заражениям, погибшим, вылеченным. Доступно два варианта вывода: По всему миру, по конкретной стране.<br/><br/>
	
	<strong><code>{covid19 type="chart"}</code></strong><em>Выводит диаграмму заболеваний по Миру</em><br/><br/>
	<strong><code>{covid19 type="chart" country="Russia"}</code></strong><em>Выводит диаграмму заболеваний по России</em><br/><br/>
	<br/><br/>
	
	</div>

</div>


<div class="panel panel-default">
	<div class="panel-heading">
		Список Регионов России и их коды для вывода <strong>(region="...")</strong>.
	</div>
	
	<div class="panel-body">
	
		<table class="table table-hover">
			<thead>
				<tr>
					<th>Название региона</th>
					<th>Код для вставки</th>
				</tr>
			</thead>
			<tbody>
				<tr><td>Алтайский край</td><td>altajskij-kraj</td></tr><tr><td>Амурская область</td><td>amurskaya-oblast</td></tr><tr><td>Архангельская область</td><td>arhangelskaya-oblast</td></tr><tr><td>Астраханская область</td><td>astrahanskaya-oblast</td></tr><tr><td>Белгородская область</td><td>belgorodskaya-oblast</td></tr><tr><td>Брянская область</td><td>bryanskaya-oblast</td></tr><tr><td>Владимирская область</td><td>vladimirskaya-oblast</td></tr><tr><td>Волгоградская область</td><td>volgogradskaya-oblast</td></tr><tr><td>Вологодская область</td><td>vologodskaya-oblast</td></tr><tr><td>Воронежская область</td><td>voronezhskaya-oblast</td></tr><tr><td>Еврейская автономная область</td><td>evrejskaya-avtonomnaya-oblast</td></tr><tr><td>Забайкальский край</td><td>zabajkalskij-kraj</td></tr><tr><td>Ивановская область</td><td>ivanovskaya-oblast</td></tr><tr><td>Иркутская область</td><td>irkutskaya-oblast</td></tr><tr><td>Кабардино-Балкарская Республика</td><td>kabardino-balkarskaya-respublika</td></tr><tr><td>Калининградская область</td><td>kaliningradskaya-oblast</td></tr><tr><td>Калужская область</td><td>kaluzhskaya-oblast</td></tr><tr><td>Камчатский край</td><td>kamchatskij-kraj</td></tr><tr><td>Карачаево-Черкесская Республика</td><td>karachaevo-cherkesskaya-respublika</td></tr><tr><td>Кемеровская область</td><td>kemerovskaya-oblast</td></tr><tr><td>Кировская область</td><td>kirovskaya-oblast</td></tr><tr><td>Костромская область</td><td>kostromskaya-oblast</td></tr><tr><td>Краснодарский край</td><td>krasnodarskij-kraj</td></tr><tr><td>Красноярский край</td><td>krasnoyarskij-kraj</td></tr><tr><td>Курганская область</td><td>kurganskaya-oblast</td></tr><tr><td>Курская область</td><td>kurskaya-oblast</td></tr><tr><td>Ленинградская область</td><td>leningradskaya-oblast</td></tr><tr><td>Липецкая область</td><td>lipetskaya-oblast</td></tr><tr><td>Магаданская область</td><td>magadanskaya-oblast</td></tr><tr><td>Москва</td><td>moskva</td></tr><tr><td>Московская область</td><td>moskovskaya-oblast</td></tr><tr><td>Мурманская область</td><td>murmanskaya-oblast</td></tr><tr><td>Нижегородская область</td><td>nizhegorodskaya-oblast</td></tr><tr><td>Новгородская область</td><td>novgorodskaya-oblast</td></tr><tr><td>Новосибирская область</td><td>novosibirskaya-oblast</td></tr><tr><td>Омская область</td><td>omskaya-oblast</td></tr><tr><td>Оренбургская область</td><td>orenburgskaya-oblast</td></tr><tr><td>Орловская область</td><td>orlovskaya-oblast</td></tr><tr><td>Пензенская область</td><td>penzenskaya-oblast</td></tr><tr><td>Пермский край</td><td>permskij-kraj</td></tr><tr><td>Приморский край</td><td>primorskij-kraj</td></tr><tr><td>Псковская область</td><td>pskovskaya-oblast</td></tr><tr><td>Республика Адыгея</td><td>respublika-adygeya</td></tr><tr><td>Республика Башкортостан</td><td>respublika-bashkortostan</td></tr><tr><td>Республика Бурятия</td><td>respublika-buryatiya</td></tr><tr><td>Республика Дагестан</td><td>respublika-dagestan</td></tr><tr><td>Республика Ингушетия</td><td>respublika-ingushetiya</td></tr><tr><td>Республика Калмыкия</td><td>respublika-kalmykiya</td></tr><tr><td>Республика Карелия</td><td>respublika-kareliya</td></tr><tr><td>Республика Коми</td><td>respublika-komi</td></tr><tr><td>Республика Крым</td><td>respublika-krym</td></tr><tr><td>Республика Марий Эл</td><td>respublika-marij-el</td></tr><tr><td>Республика Мордовия</td><td>respublika-mordoviya</td></tr><tr><td>Республика Саха (Якутия)</td><td>respublika-saha-yakutiya</td></tr><tr><td>Республика Северная Осетия — Алания</td><td>respublika-severnaya-osetiya-—-alaniya</td></tr><tr><td>Республика Татарстан</td><td>respublika-tatarstan</td></tr><tr><td>Республика Хакасия</td><td>respublika-hakasiya</td></tr><tr><td>Республика Чувашия</td><td>respublika-chuvashiya</td></tr><tr><td>Ростовская область</td><td>rostovskaya-oblast</td></tr><tr><td>Рязанская область</td><td>ryazanskaya-oblast</td></tr><tr><td>Самарская область</td><td>samarskaya-oblast</td></tr><tr><td>Санкт-Петербург</td><td>sankt-peterburg</td></tr><tr><td>Саратовская область</td><td>saratovskaya-oblast</td></tr><tr><td>Сахалинская область</td><td>sahalinskaya-oblast</td></tr><tr><td>Свердловская область</td><td>sverdlovskaya-oblast</td></tr><tr><td>Севастополь</td><td>sevastopol</td></tr><tr><td>Смоленская область</td><td>smolenskaya-oblast</td></tr><tr><td>Ставропольский край</td><td>stavropolskij-kraj</td></tr><tr><td>Тамбовская область</td><td>tambovskaya-oblast</td></tr><tr><td>Тверская область</td><td>tverskaya-oblast</td></tr><tr><td>Томская область</td><td>tomskaya-oblast</td></tr><tr><td>Тульская область</td><td>tulskaya-oblast</td></tr><tr><td>Тюменская область</td><td>tyumenskaya-oblast</td></tr><tr><td>Удмуртская Республика</td><td>udmurtskaya-respublika</td></tr><tr><td>Ульяновская область</td><td>ulyanovskaya-oblast</td></tr><tr><td>Хабаровский край</td><td>habarovskij-kraj</td></tr><tr><td>Ханты-Мансийский АО</td><td>hanty-mansijskij-ao</td></tr><tr><td>Челябинская область</td><td>chelyabinskaya-oblast</td></tr><tr><td>Чеченская Республика</td><td>chechenskaya-respublika</td></tr><tr><td>Ямало-Ненецкий автономный округ</td><td>yamalo-nenetskij-avtonomnyj-okrug</td></tr><tr><td>Ярославская область</td><td>yaroslavskaya-oblast</td></tr>	
			</tbody>
		</table>
		
		
	</div>

</div>

<div class="panel panel-default">
	<div class="panel-heading">
		Список областей Украины и их коды для вывода <strong>(region="...")</strong>.
	</div>
	
	<div class="panel-body">
	
		<table class="table table-hover">
			<thead>
				<tr>
					<th>Название региона</th>
					<th>Код для вставки</th>
				</tr>
			</thead>
			<tbody>
<tr><td>Вінницька область</td><td>Vinnytsia</td></tr><tr><td>Волинська область</td><td>Volynska</td></tr><tr><td>Дніпропетровська область</td><td>Dnipropetrovska</td></tr><tr><td>Донецька область</td><td>Donetska</td></tr><tr><td>Житомирська область</td><td>Zhytomyrskа</td></tr><tr><td>Закарпатська область</td><td>Zakarpatska</td></tr><tr><td>Запорізька область</td><td>Zaporizka</td></tr><tr><td>Івано-Франківська область</td><td>Ivano-Frankivska</td></tr><tr><td>Київська область</td><td>Kyivska</td></tr><tr><td>Кіровоградська область</td><td>Kirovohradska</td></tr><tr><td>Луганська область</td><td>Luhanska</td></tr><tr><td>Львівська область</td><td>Lvivska</td></tr><tr><td>Миколаївська область</td><td>Mykolaivska</td></tr><tr><td>м. Київ</td><td>Kyiv</td></tr><tr><td>Одеська область</td><td>Odeska</td></tr><tr><td>Полтавська область</td><td>Poltavska</td></tr><tr><td>Рівненська область</td><td>Rivnenska</td></tr><tr><td>Сумська область</td><td>Sumska</td></tr><tr><td>Тернопільська область</td><td>Ternopilska</td></tr><tr><td>Харківська область</td><td>Kharkivska</td></tr><tr><td>Херсонська область</td><td>Khersonska</td></tr><tr><td>Хмельницька область</td><td>Khmelnytska</td></tr><tr><td>Черкаська область</td><td>Cherkaska</td></tr><tr><td>Чернівецька область</td><td>Chernivetska</td></tr><tr><td>Чернігівська область</td><td>Chernihivska</td></tr>

			</tbody>
		</table>
		
		
	</div>

</div>


<div class="panel panel-default">
	<div class="panel-heading">
		Список областей Казахстана и их коды для вывода <strong>(region="...")</strong>.
	</div>
	
	<div class="panel-body">
	
		<table class="table table-hover">
			<thead>
				<tr>
					<th>Название региона</th>
					<th>Код для вставки</th>
				</tr>
			</thead>
			<tbody>
<tr><td>Алматы</td><td>almaty</td></tr><tr><td>Нур-Султан</td><td>nur-sultan</td></tr><tr><td>Кызылординская область</td><td>kyzylordinskaja-oblast</td></tr><tr><td>Шымкент</td><td>shymkent</td></tr><tr><td>Западно-Казахстанская область</td><td>zapadno-kazahstanskaja-oblast</td></tr><tr><td>Атырауская область</td><td>atyrauskaja-oblast</td></tr><tr><td>Актюбинская область</td><td>aktjubinskaja-oblast</td></tr><tr><td>Карагандинская область</td><td>karagandinskaja-oblast</td></tr><tr><td>Жамбылская область</td><td>zhambylskaja-oblast</td></tr><tr><td>Алматинская область</td><td>almatinskaja-oblast</td></tr><tr><td>Павлодарская область</td><td>pavlodarskaja-oblast</td></tr><tr><td>Туркестанская область</td><td>turkestanskaja-oblast</td></tr><tr><td>Акмолинская область</td><td>akmolinskaja-oblast</td></tr><tr><td>Мангыстауская область</td><td>mangystauskaja-oblast</td></tr><tr><td>Костанайская область</td><td>kostanajskaja-oblast</td></tr><tr><td>Восточно-Казахстанская область</td><td>vostochno-kazahstanskaja-oblast</td></tr><tr><td>Северо-Казахстанская область</td><td>severo-kazahstanskaja-oblast</td></tr>

			</tbody>
		</table>
		
		
	</div>

</div>











<div class="panel panel-default">
	<div class="panel-heading">
		Список стран и их коды для вывода <strong>(country="...")</strong>.
	</div>
	
	<div class="panel-body">
	
		<table class="table table-hover">
			<thead>
				<tr>
					<th>Название страны</th>
					<th>Код для вставки</th>
				</tr>
			</thead>
			<tbody>
				<tr><td>Афганистан</td><td>Afghanistan</td></tr><tr><td>Албания</td><td>Albania</td></tr><tr><td>Алжир</td><td>Algeria</td></tr><tr><td>Андорра</td><td>Andorra</td></tr><tr><td>Ангола</td><td>Angola</td></tr><tr><td>Ангилья</td><td>Anguilla</td></tr><tr><td>Антигуа и Барбуда</td><td>Antigua and Barbuda</td></tr><tr><td>Аргентина</td><td>Argentina</td></tr><tr><td>Армения</td><td>Armenia</td></tr><tr><td>Аруба</td><td>Aruba</td></tr><tr><td>Австралия</td><td>Australia</td></tr><tr><td>Австрия</td><td>Austria</td></tr><tr><td>Азербайджан</td><td>Azerbaijan</td></tr><tr><td>Багамские острова</td><td>Bahamas</td></tr><tr><td>Бахрейн</td><td>Bahrain</td></tr><tr><td>Бангладеш</td><td>Bangladesh</td></tr><tr><td>Барбадос</td><td>Barbados</td></tr><tr><td>Беларусь</td><td>Belarus</td></tr><tr><td>Бельгия</td><td>Belgium</td></tr><tr><td>Белиз</td><td>Belize</td></tr><tr><td>Бенин</td><td>Benin</td></tr><tr><td>Бермудские острова</td><td>Bermuda</td></tr><tr><td>Бутан</td><td>Bhutan</td></tr><tr><td>Боливия</td><td>Bolivia</td></tr><tr><td>Босния</td><td>Bosnia</td></tr><tr><td>Ботсвана</td><td>Botswana</td></tr><tr><td>Бразилия</td><td>Brazil</td></tr><tr><td>Британские Виргинские острова</td><td>British Virgin Islands</td></tr><tr><td>Бруней</td><td>Brunei</td></tr><tr><td>Болгария</td><td>Bulgaria</td></tr><tr><td>Буркина-Фасо</td><td>Burkina Faso</td></tr><tr><td>Бурунди</td><td>Burundi</td></tr><tr><td>Кабо-Верде</td><td>Cabo Verde</td></tr><tr><td>Камбоджа</td><td>Cambodia</td></tr><tr><td>Камерун</td><td>Cameroon</td></tr><tr><td>Канада</td><td>Canada</td></tr><tr><td>Карибские острова Нидерланды</td><td>Caribbean Netherlands</td></tr><tr><td>Каймановы острова</td><td>Cayman Islands</td></tr><tr><td>Центрально-Африканская Республика Республика</td><td>Central African Republic</td></tr><tr><td>Чад</td><td>Chad</td></tr><tr><td>Нормандские острова</td><td>Channel Islands</td></tr><tr><td>Чили</td><td>Chile</td></tr><tr><td>Китай</td><td>China</td></tr><tr><td>Колумбия</td><td>Colombia</td></tr><tr><td>Конго</td><td>Congo</td></tr><tr><td>Коста-Рика</td><td>Costa Rica</td></tr><tr><td>Хорватия</td><td>Croatia</td></tr><tr><td>Куба</td><td>Cuba</td></tr><tr><td>Кюрасао</td><td>Curaçao</td></tr><tr><td>Кипр</td><td>Cyprus</td></tr><tr><td>Чехия</td><td>Czechia</td></tr><tr><td>Кот-д'Ивуар</td><td>Côte d'Ivoire</td></tr><tr><td>ДРК</td><td>DRC</td></tr><tr><td>Дания</td><td>Denmark</td></tr><tr><td>Алмазная принцесса</td><td>Diamond Princess</td></tr><tr><td>Джибути</td><td>Djibouti</td></tr><tr><td>Доминика</td><td>Dominica</td></tr><tr><td>Доминиканская Республика</td><td>Dominican Republic</td></tr><tr><td>Эквадор</td><td>Ecuador</td></tr><tr><td>Египет</td><td>Egypt</td></tr><tr><td>Сальвадор</td><td>El Salvador</td></tr><tr><td>Экваториальная Гвинея</td><td>Equatorial Guinea</td></tr><tr><td>Эритрея</td><td>Eritrea</td></tr><tr><td>Эстония</td><td>Estonia</td></tr><tr><td>Эфиопия</td><td>Ethiopia</td></tr><tr><td>Фолклендские (Мальвинские) острова</td><td>Falkland Islands (Malvinas)</td></tr><tr><td>Фарерские острова</td><td>Faroe Islands</td></tr><tr><td>Фиджи</td><td>Fiji</td></tr><tr><td>Финляндия</td><td>Finland</td></tr><tr><td>Франция</td><td>France</td></tr><tr><td>Французская Гвиана</td><td>French Guiana</td></tr><tr><td>Французская Полинезия</td><td>French Polynesia</td></tr><tr><td>Габон</td><td>Gabon</td></tr><tr><td>Гамбия</td><td>Gambia</td></tr><tr><td>Грузия</td><td>Georgia</td></tr><tr><td>Германия</td><td>Germany</td></tr><tr><td>Гана</td><td>Ghana</td></tr><tr><td>Гибралтар</td><td>Gibraltar</td></tr><tr><td>Греция</td><td>Greece</td></tr><tr><td>Гренландия</td><td>Greenland</td></tr><tr><td>Гренада</td><td>Grenada</td></tr><tr><td>Гваделупа</td><td>Guadeloupe</td></tr><tr><td>Гватемала</td><td>Guatemala</td></tr><tr><td>Гвинея</td><td>Guinea</td></tr><tr><td>Гвинея-Бисау</td><td>Guinea-Bissau</td></tr><tr><td>Гайана</td><td>Guyana</td></tr><tr><td>Гаити</td><td>Haiti</td></tr><tr><td>Святой Престол</td><td>Holy See (Vatican City State)</td></tr><tr><td>Гондурас</td><td>Honduras</td></tr><tr><td>Гонконг</td><td>Hong Kong</td></tr><tr><td>Венгрия</td><td>Hungary</td></tr><tr><td>Исландия</td><td>Iceland</td></tr><tr><td>Индия</td><td>India</td></tr><tr><td>Индонезия</td><td>Indonesia</td></tr><tr><td>Иран</td><td>Iran</td></tr><tr><td>Ирак</td><td>Iraq</td></tr><tr><td>Ирландия</td><td>Ireland</td></tr><tr><td>Остров Мэн</td><td>Isle of Man</td></tr><tr><td>Израиль</td><td>Israel</td></tr><tr><td>Италия</td><td>Italy</td></tr><tr><td>Ямайка</td><td>Jamaica</td></tr><tr><td>Япония</td><td>Japan</td></tr><tr><td>Иордания</td><td>Jordan</td></tr><tr><td>Казахстан</td><td>Kazakhstan</td></tr><tr><td>Кения</td><td>Kenya</td></tr><tr><td>Кувейт</td><td>Kuwait</td></tr><tr><td>Кыргызстан</td><td>Kyrgyzstan</td></tr><tr><td>Лаосская Народно-Демократическая Республика</td><td>Lao People's Democratic Republic</td></tr><tr><td>Латвия</td><td>Latvia</td></tr><tr><td>Ливан</td><td>Lebanon</td></tr><tr><td>Либерия</td><td>Liberia</td></tr><tr><td>Ливийская Арабская Джамахирия</td><td>Libyan Arab Jamahiriya</td></tr><tr><td>Лихтенштейн</td><td>Liechtenstein</td></tr><tr><td>Литва</td><td>Lithuania</td></tr><tr><td>Люксембург</td><td>Luxembourg</td></tr><tr><td>MS Zaandam</td><td>MS Zaandam</td></tr><tr><td>Макао</td><td>Macao</td></tr><tr><td>Македония</td><td>Macedonia</td></tr><tr><td>Мадагаскар</td><td>Madagascar</td></tr><tr><td>Малави</td><td>Malawi</td></tr><tr><td>Малайзия</td><td>Malaysia</td></tr><tr><td>Мальдивы</td><td>Maldives</td></tr><tr><td>Мали</td><td>Mali</td></tr><tr><td>Мальта</td><td>Malta</td></tr><tr><td>Мартиника</td><td>Martinique</td></tr><tr><td>Мавритания</td><td>Mauritania</td></tr><tr><td>Маврикий</td><td>Mauritius</td></tr><tr><td>Майотта</td><td>Mayotte</td></tr><tr><td>Мексика</td><td>Mexico</td></tr><tr><td>Молдова, Республика</td><td>Moldova, Republic of</td></tr><tr><td>Монако</td><td>Monaco</td></tr><tr><td>Монголия</td><td>Mongolia</td></tr><tr><td>Черногория</td><td>Montenegro</td></tr><tr><td>Монтсеррат</td><td>Montserrat</td></tr><tr><td>Марокко</td><td>Morocco</td></tr><tr><td>Мозамбик</td><td>Mozambique</td></tr><tr><td>Мьянма</td><td>Myanmar</td></tr><tr><td>Намибия</td><td>Namibia</td></tr><tr><td>Непал</td><td>Nepal</td></tr><tr><td>Нидерланды</td><td>Netherlands</td></tr><tr><td>Новая Каледония</td><td>New Caledonia</td></tr><tr><td>Новая Зеландия</td><td>New Zealand</td></tr><tr><td>Никарагуа</td><td>Nicaragua</td></tr><tr><td>Нигер</td><td>Niger</td></tr><tr><td>Нигерия</td><td>Nigeria</td></tr><tr><td>Норвегия</td><td>Norway</td></tr><tr><td>Оман</td><td>Oman</td></tr><tr><td>Пакистан</td><td>Pakistan</td></tr><tr><td>Палестинская территория</td><td>Palestinian Territory, Occupied</td></tr><tr><td>Панама</td><td>Panama</td></tr><tr><td>Папуа-Новая Гвинея</td><td>Papua New Guinea</td></tr><tr><td>Парагвай</td><td>Paraguay</td></tr><tr><td>Перу</td><td>Peru</td></tr><tr><td>Филиппины</td><td>Philippines</td></tr><tr><td>Польша</td><td>Poland</td></tr><tr><td>Португалия</td><td>Portugal</td></tr><tr><td>Катар</td><td>Qatar</td></tr><tr><td>Румыния</td><td>Romania</td></tr><tr><td>Россия</td><td>Russia</td></tr><tr><td>Руанда</td><td>Rwanda</td></tr><tr><td>Реюньон</td><td>Réunion</td></tr><tr><td>Ю.Корея</td><td>S. Korea</td></tr><tr><td>Сент-Китс и Невис</td><td>Saint Kitts and Nevis</td></tr><tr><td>Сент-Люсия</td><td>Saint Lucia</td></tr><tr><td>Сен-Мартен</td><td>Saint Martin</td></tr><tr><td>Сен-Пьер Микелон</td><td>Saint Pierre Miquelon</td></tr><tr><td>Сент-Винсент и Гренадины</td><td>Saint Vincent and the Grenadines</td></tr><tr><td>Сан-Марино</td><td>San Marino</td></tr><tr><td>Сан-Томе и Принсипи</td><td>Sao Tome and Principe</td></tr><tr><td>Саудовская Аравия</td><td>Saudi Arabia</td></tr><tr><td>Сенегал</td><td>Senegal</td></tr><tr><td>Сербия</td><td>Serbia</td></tr><tr><td>Сейшельские острова</td><td>Seychelles</td></tr><tr><td>Сьерра-Леоне</td><td>Sierra Leone</td></tr><tr><td>Сингапур</td><td>Singapore</td></tr><tr><td>Синт</td><td>Sint Maarten</td></tr><tr><td>Словакия</td><td>Slovakia</td></tr><tr><td>Словения</td><td>Slovenia</td></tr><tr><td>Сомали</td><td>Somalia</td></tr><tr><td>Южная Африка</td><td>South Africa</td></tr><tr><td>Юг Судан</td><td>South Sudan</td></tr><tr><td>Испания</td><td>Spain</td></tr><tr><td>Шри-Ланка</td><td>Sri Lanka</td></tr><tr><td>Св. Барт</td><td>St. Barth</td></tr><tr><td>Судан</td><td>Sudan</td></tr><tr><td>Суринам</td><td>Suriname</td></tr><tr><td>Свазиленд</td><td>Swaziland</td></tr><tr><td>Швеция</td><td>Sweden</td></tr><tr><td>Швейцария</td><td>Switzerland</td></tr><tr><td>Сирийская Арабская Республика</td><td>Syrian Arab Republic</td></tr><tr><td>Тайвань</td><td>Taiwan</td></tr><tr><td>Танзания, Объединенная Республика</td><td>Tanzania, United Republic of</td></tr><tr><td>Таиланд</td><td>Thailand</td></tr><tr><td>Восточный Тимор</td><td>Timor-Leste</td></tr><tr><td>Того</td><td>Togo</td></tr><tr><td>Тринидад и Тобаго</td><td>Trinidad and Tobago</td></tr><tr><td>Тунис</td><td>Tunisia</td></tr><tr><td>Турция</td><td>Turkey</td></tr><tr><td>Острова Теркс и Кайкос</td><td>Turks and Caicos Islands</td></tr><tr><td>ОАЭ</td><td>UAE</td></tr><tr><td>Великобритания</td><td>UK</td></tr><tr><td>США</td><td>USA</td></tr><tr><td>Уганда</td><td>Uganda</td></tr><tr><td>Украина</td><td>Ukraine</td></tr><tr><td>Уругвай</td><td>Uruguay</td></tr><tr><td>Узбекистан</td><td>Uzbekistan</td></tr><tr><td>Венесуэла</td><td>Venezuela</td></tr><tr><td>Вьетнам</td><td>Vietnam</td></tr><tr><td>Западная Сахара</td><td>Western Sahara</td></tr><tr><td>Замбия</td><td>Zambia</td></tr><tr><td>Зимбабве</td><td>Zimbabwe</td></tr>
			</tbody>
		</table>
		
		
	</div>

</div>


HTML;

} elseif ($action == 'settings') { // Показываем конкурс
	
	$_SESSION['admin_referrer'] = "?mod=".$mod."&action=settings";
	
	echoheader( "<i class=\"fa fa-cog position-left\"></i><span class=\"text-semibold\">Настройки</span>", array('?mod='.$mod => 'Корона.Инфо', '' => 'Настройки модуля' ) );
	
  showMenu($action);

	echo <<<HTML
<form action="" method="post" class="systemsettings">
<div id="general" class="panel panel-flat">
  <div class="panel-body">
    {$lang['opt_sys_all']}
  </div>
  <div class="table-responsive">
  <table class="table table-striped">
HTML;

	showRow( $lang['c19_cache_time'], $lang['c19_cache_timed'], "<input type=\"text\" class=\"form-control\" name=\"save_con[cache_time]\" value=\"{$c19_config['cache_time']}\">");
	
	showRow( $lang['c19_allow_world'], $lang['c19_allow_worldd'], makeCheckBox( "save_con[get_world_data]", "{$c19_config['get_world_data']}" ) );

	showRow( $lang['c19_allow_ru'], $lang['c19_allow_rud'], makeCheckBox( "save_con[get_ru_data]", "{$c19_config['get_ru_data']}" ) );

	showRow( $lang['c19_allow_ua'], $lang['c19_allow_uad'], makeCheckBox( "save_con[get_ua_data]", "{$c19_config['get_ua_data']}" ) );
	
	showRow( $lang['c19_allow_kz'], $lang['c19_allow_kzd'], makeCheckBox( "save_con[get_kz_data]", "{$c19_config['get_kz_data']}" ) );
	
	showRow( $lang['c19_allow_history'], $lang['c19_allow_historyd'], makeCheckBox( "save_con[get_history_data]", "{$c19_config['get_history_data']}" ) );
	
	
	echo "</table></div></div>";
	
	echo <<<HTML
<div style="margin-bottom:30px;">
<input type="hidden" name="mod" value="{$mod}">
<input type="hidden" name="action" value="dosavesyscon">
<input type="hidden" name="user_hash" value="{$dle_login_hash}">
<button type="submit" class="btn bg-teal btn-raised position-left"><i class="fa fa-floppy-o position-left"></i>{$lang['user_save']}</button>
</div>
</form>
HTML;

} elseif( $action == "dosavesyscon" ) { // Сохранить настройки

	if( $_REQUEST['user_hash'] == "" OR $_REQUEST['user_hash'] != $dle_login_hash ) {
		
		die( "Hacking attempt! User not found" );
	
	}

	if( $member_id['user_group'] != 1 ) {
		msg( "error", $lang['opt_denied'], $lang['opt_denied'] );
	}

	$save_con = $_POST['save_con'];
	
	$save_con['cache_time'] = intval($save_con['cache_time']);
	$save_con['get_ru_data'] = (int)$save_con['get_ru_data'];
	$save_con['get_ua_data'] = (int)$save_con['get_ua_data'];
	$save_con['get_world_data'] = (int)$save_con['get_world_data'];
	
	$save_con['get_history_data'] = (int)$save_con['get_history_data'];
	
	@unlink( ENGINE_DIR . "/plugins/covid19/data/cache/data.tmp" );

	$find = array();
	$replace = array();
	
	$find[] = "'\r'";
	$replace[] = "";
	$find[] = "'\n'";
	$replace[] = "";

	$save_con = $save_con + $c19_config;

	$handler = fopen( ENGINE_DIR . '/plugins/covid19/data/config.php', "w" );
	
	fwrite( $handler, "<?PHP \n\n//Corona.Info Configurations\n\n\$c19_config = array (\n\n" );
	foreach ( $save_con as $name => $value ) {
		
		$value = preg_replace( $find, $replace, $value );
		$value = str_replace( "$", "&#036;", $value );
		$value = str_replace( "{", "&#123;", $value );
		$value = str_replace( "}", "&#125;", $value );
		$value = str_replace( chr(0), "", $value );
		$value = str_replace( chr(92), "", $value );
		$value = str_ireplace( "decode", "dec&#111;de", $value );
		
		$name = preg_replace( $find, $replace, $name );
		$name = str_replace( "$", "&#036;", $name );
		$name = str_replace( "{", "&#123;", $name );
		$name = str_replace( "}", "&#125;", $name );
		$name = str_replace( chr(0), "", $name );
		$name = str_replace( chr(92), "", $name );
		$name = str_replace( '(', "", $name );
		$name = str_replace( ')', "", $name );
		$name = str_ireplace( "decode", "dec&#111;de", $name );
		
		fwrite( $handler, "'{$name}' => '{$value}',\n\n" );
	
	}
	
	fwrite( $handler, ");\n\n?>" );
	fclose( $handler );
	
	clear_cache();
	
	msg( "success", $lang['opt_sysok'], $lang['opt_sysok_1'], "?mod=".$mod );



} 




	echofooter();


?>