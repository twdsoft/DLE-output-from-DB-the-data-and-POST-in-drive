<?php

/*
=====================================================
File: init.php
-----------------------------------------------------
Made: Dmitry Dark5ider                     
-----------------------------------------------------
Contacts: t.me/dmitry_tsum
-----------------------------------------------------
Use: COVID INFORMER CLASS          v.1.1  27.04.2020
=====================================================
*/


if ( ! class_exists( 'Covid19' ) ) {
	class Covid19 {
		
	private  $cdata 		 = array();
	private  $params 		 = array();	
	private  $plugDir		 = ENGINE_DIR . "/plugins/covid19/";
	private  $cache_main	 = "data/cache/data.tmp";

	function __construct() {

		$cdata = $this->r_sdata($this->cache_main);

		if( $cdata ) {

			$this->cdata = json_decode($cdata);

		} else {

			$this->getAllData();

			if($this->cdata) $this->w_sdata($this->cache_main, json_encode($this->cdata));

		}

	}
		
		private function r_sdata($cache_file){
			global $c19_config, $lang;
			
			$buffer = @file_get_contents( $this->plugDir . $cache_file );
			
			if ( $buffer !== false AND $c19_config['cache_time'] ) {
				
				$file_date = @filemtime( $this->plugDir . $cache_file );
				$file_date = time()-$file_date;
				
				if ( $file_date > ( $c19_config['cache_time'] * 60 ) ) {
					$buffer = false;
					@unlink( $this->plugDir . $cache_file );
				}

				return $buffer;

			} else return $buffer;

			
		}
		
		private function w_sdata($cache_file, $text){
			
			if($text === false) $text = '';
			
			if (!is_dir($this->plugDir . "data/cache/")) mkdir($this->plugDir . "data/cache/");
			
			file_put_contents ( $this->plugDir . $cache_file, $text, LOCK_EX);
			@chmod( $this->plugDir . $cache_file, 0666 );

			return true;
		}
		
		private function d_data($cache_file){
			
			@unlink( $this->plugDir . $cache_file );

			return true;
		} 
		
		private function getAllData(){
			global $c19_config;
			
			if ($c19_config['get_world_data']) $this->getWorldData();
			if ($c19_config['get_ru_data']) $this->getRussiaData();
			if ($c19_config['get_ua_data']) $this->getUkraineData();
			if ($c19_config['get_kz_data']) $this->getKzData();
			//if ($c19_config['get_kg_data']) $this->getKgData();
			
			$this->cdata = (object) $this->cdata;
		}
		
		private function getWorldData(){
			global $c19_config, $_TIME;
			
			$querySite 	= 'https://corona.lmao.ninja/v2/';
			$methodPath = array('all','countries');
			
			if ($c19_config['get_history_data']) {
				$methodPath[] = 'historical';
				$data['historical']['lastadays'] = 'all'; 
				$methodPath[] = 'historical/all';
			}

			foreach ($methodPath as $mType) {
				if (count($data[$mType])) $arg = '?'.http_build_query($data[$mType]);
					else $arg = '';
				$endPoint = $querySite.$mType;
				$mType = str_replace('/','_',$mType);
				$this->cdata{$mType} = json_decode(file_get_contents($endPoint.$arg));
				
				if ($c19_config['get_history_data']) $this->cdata{$mType}->updated = $_TIME;
				
				
			}

		}

		private function getKzData(){
			global $_TIME;

			if (!function_exists('file_get_html')){
				include_once (DLEPlugins::Check($this->plugDir . 'classes/simple_html_dom.php'));	
			}

			$dataUrl = 'https://findhow.org/4268-karta-koronovirusa-covid-19-v-kazahstane.html';

			$curl = curl_init();
			curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
			curl_setopt($curl, CURLOPT_HEADER, false);
			curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
			curl_setopt($curl, CURLOPT_URL, $dataUrl);
			curl_setopt($curl, CURLOPT_REFERER, $dataUrl);
			curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);
			curl_setopt($curl, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/533.4 (KHTML, like Gecko) Chrome/5.0.375.125 Safari/533.4");
			$str = curl_exec($curl);
			curl_close($curl);

			$html = new simple_html_dom();
			$html->load($str);
			
			foreach($html->find('#covid19-table',0)->find('tr') as $element){

				$i++;
				if ($i==1) continue;
				if( stripos ( $element->find('td',0)->plaintext,'сего:' ) !== false ) continue;

					$tData['region'] = str_replace(array(':','г. '), '', $element->find('td',0)->plaintext);
					$tData['region_alt'] = totranslit($tData['region']);
					$tData['cases'] = (int)$element->find('td',1)->find('.diff-inner',0)->innertext;
					//$tData['todayCases'] = (int)$element->find('td',1)->find('.diff-infected',0)->plaintext;
					$tData['deaths'] = (int)$element->find('td',3)->plaintext;
					$tData['recovered'] = (int)$element->find('td',2)->find('.diff-inner',0)->innertext;
					//$tData['todayRecovered'] = (int)$element->find('td',2)->find('.diff-recovered',0)->plaintext;
					$tData['active'] = $tData['cases']-$tData['deaths']-$tData['recovered'];
					$tData['updated'] = $_TIME;
				
					$this->cdata['kazakhstan'][] = (object)$tData;
					unset($tData);

			}
			
			
		}
				
		private function getUkraineData(){
			global $_TIME;

			$querySite 	= 'https://api-covid19.rnbo.gov.ua/data';

			$data = array(
				'to' => date('Y-m-d'),
			); 
			

			if (count($data)) $arg = '?'.http_build_query($data);
			
			if( function_exists( 'curl_init' ) ) {
				
				$ch = curl_init();
				curl_setopt( $ch, CURLOPT_URL, $querySite.$arg );


				@curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, true );
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, true );
				curl_setopt($ch, CURLOPT_TIMEOUT, 5 );
				curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
				curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
				curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);

				$data = curl_exec( $ch );
				curl_close( $ch );
				
			

				if( $data !== false ) {
					
					$tmpdt = json_decode($data);
					
					foreach ($tmpdt->{ukraine} as $key => $val) {
						
						$tData[region_alt] = $val->label->en;
						$tData[region] = $val->label->uk;
						$tData[cases] = $val->confirmed;
						$tData[deaths] = $val->deaths;						
						$tData[recovered] = $val->recovered;
						$tData[active] = $val->existing;						
						$tData[updated] = $_TIME;
						
						$this->cdata['ukraine'][] = (object)$tData;
						unset($tData);

					}
					
				} 	

			} 
			
		}
		
		private function getRussiaData(){
			global $_TIME;

			if (!function_exists('file_get_html')){
				include_once (DLEPlugins::Check($this->plugDir . 'classes/simple_html_dom.php'));	
			}

			$dataUrl = 'https://coronavirus-monitor.info/country/russia/';

			$html = file_get_html($dataUrl);

			foreach($html->find('#russia_stats',0)->find('.flex-table') as $element){

				$i++;
				if ($i==1) continue;

					$tData[region_alt] = basename($element->find('div[data-region] a',0)->href);
					$tData[region] = $element->find('div[data-region]',0)->{'data-region'};
					$tData[cases] = (int)$element->find('div[data-confirmed]',0)->{'data-confirmed'};
					$tData[todayCases] = (int)$element->find('div[data-confirmed] sup',0)->plaintext;
					$tData[deaths] = (int)$element->find('div[data-deaths]',0)->{'data-deaths'};
					$tData[todayDeaths] = (int)$element->find('div[data-deaths] sup',0)->plaintext;
					$tData[recovered] = (int)$element->find('div[data-cured]',0)->{'data-cured'};
					$tData[active] = $tData[cases]-$tData[deaths]-$tData[recovered];
					$tData[updated] = $_TIME;

					$this->cdata['russia'][] = (object)$tData;
					unset($tData);

			}

		}
		
		private function getKgData(){
			global $_TIME;

			if (!function_exists('file_get_html')){
				include_once (DLEPlugins::Check($this->plugDir . '/classes/simple_html_dom.php'));	
			}

			$dataUrl = 'https://covid.kg/';

			$html = file_get_html($dataUrl);

			foreach($html->find('.map-left',1)->find('li.list-group-item') as $element){

				$i++;
				if ($i==1) continue;

					//$tData[region_alt] = basename($element->find('div[data-region] a',0)->href);
					//$tData[region] = $element->find('div[data-region]',0)->{'data-region'};
					$tData[cases] = (int)$element->find('span.badge-pill',0)->plaintext;
					//$tData[deaths] = (int)$element->find('div[data-deaths]',0)->{'data-deaths'};
					//$tData[todayDeaths] = (int)$element->find('div[data-deaths] sup',0)->plaintext;
					//$tData[recovered] = (int)$element->find('div[data-cured]',0)->{'data-cured'};
					//$tData[active] = $tData[cases]-$tData[deaths]-$tData[recovered];
					//$tData[updated] = $_TIME;

					$this->cdata['kyrgyzstan'][] = (object)$tData;
					unset($tData);

			}

		}
		
		public function getMatches($matches) {
			global $lang;
			
			$this->params =  array('label_today_confirmed'=>$lang['c19_l_today_confirmed'],'label_today_deaths'=>$lang['c19_l_today_deaths'],'label_country'=>$lang['c19_l_country'],	'country' => null,'region' => null,'label_confirmed' => $lang['c19_l_confirmed'],'label_deaths' => $lang['c19_l_deaths'],'label_recovered' => $lang['c19_l_recovered'],'label_active' => $lang['c19_l_active'],'style' => 'default'
			);
		

			$param_str = trim($matches[1]);

			if( preg_match( "#type=['\"](.+?)['\"]#i", $param_str, $match ) ) {
				$this->params['type'] = trim($match[1]);
			} else $this->params['type'] = "box";

			if( preg_match( "#style=['\"](.+?)['\"]#i", $param_str, $match ) ) {
				$this->params['style'] = trim($match[1]);
			} else $this->params['style'] = "1";

			if( preg_match( "#country=['\"](.+?)['\"]#i", $param_str, $match ) ) {
				$this->params['country'] = trim($match[1]);
			} 

			if( preg_match( "#region=['\"](.+?)['\"]#i", $param_str, $match ) ) {
				$this->params['region'] = trim($match[1]);
			} 

			if( preg_match( "#title=['\"](.+?)['\"]#i", $param_str, $match ) ) {
				$this->params['title'] = trim($match[1]);
			} 

			if( preg_match( "#dark_mode=['\"](.+?)['\"]#i", $param_str, $match ) ) {
				$this->params['dark_mode'] = trim($match[1]);
			} 

			if( preg_match( "#per_page=['\"](.+?)['\"]#i", $param_str, $match ) ) {
				$this->params['per_page'] = (int)trim($match[1]);
			} 

			if ($this->params['type'] == 'map'){

				// may be late
				
				
			} elseif (($this->params['type'] == 'chart')) {

				if ($this->params['country']) {
					
					foreach ($this->cdata->historical as $key => $val) {

						if (strtolower($val->country) == strtolower($this->params['country'])) {
							$sdata[$this->params['country']] = $this->cdata->historical[$key];
							break;
						}

					}
					
				} 

				$sdata['all'] = $this->cdata->historical_all;
				
				
			} elseif (($this->params['type'] == 'list') || ($this->params['type'] == 'table')) {
				
				if ($this->params['country'] == 'Russia') {

					$sdata = $this->cdata->russia;
					
				} elseif ($this->params['country'] == 'Kazakhstan') {

					$sdata = $this->cdata->kazakhstan;
					
					//print_r($sdata);
					
				} elseif ($this->params['country'] == 'Ukraine') {

					$sdata = $this->cdata->ukraine;					
					
				} else {
					
					$sdata = (array)$this->cdata->countries;
					
					foreach ($sdata as $key => $row) $cases[$key]  = $row->{'cases'};
					array_multisort($cases, SORT_DESC, $sdata);

				}
				
			} elseif (($this->params['type'] == 'line') || ($this->params['type'] == 'box')) {


				if ($this->params['region']) {
					
					if ($this->params['country'] == 'Russia') $sdata = $this->cdata->russia;
					elseif ($this->params['country'] == 'Ukraine') $sdata = $this->cdata->ukraine;
					elseif ($this->params['country'] == 'Kazakhstan') $sdata = $this->cdata->kazakhstan;
					
					
					$params = $this->params;
					
					$new_array = array_filter($sdata, function($obj) use($params) {
						if ($obj->region_alt === $this->params['region']) {
							return true;
						}
						return false;
					});

					if ($new_array) $sdata = reset($new_array);
					
					
					

				} elseif ($this->params['country']) {
					
					$sdata = $this->cdata->countries;
					$params = $this->params;

					$new_array = array_filter($sdata, function($obj) use($params) {
						if ($obj->country === $this->params['country']) {
							return true;
						}
						return false;
					});

					if ($new_array) {
						$sdata = reset($new_array);
					}

				} else $sdata = $this->cdata->all;


			}
			
			return $this->render($sdata);
		}
		
		public function render($data){
			global $lang, $_TIME, $config;
			
			//print_r($data);
			
			$tID = rand(0,100);
			
			if ($data->updated) $updated = substr($data->updated, 0, 10);
				else $updated = substr($data{0}->updated, 0, 10);
				
			if( date( 'Ymd', $updated ) == date( 'Ymd', $_TIME ) ) {
				$date = $lang['time_heute'] . langdate( ", H:i", $updated  );
			} elseif( date( 'Ymd', $updated ) == date( 'Ymd', ($_TIME - 86400) ) ) {
				$date=$lang['time_gestern'] . langdate( ", H:i", $updated ) ;
			} else {
				$date=langdate( $config['timestamp_active'], $updated  );
			}
			
			
			// Show or hide flags
			if (($this->params['country']=='Russia') || ($this->params['country']=='Ukraine') || ($this->params['country']=='Kazakhstan')) { 
				if ($this->params['country']=='Russia') $titleCountry = 'Россия';
				elseif ($this->params['country']=='Kazakhstan') $titleCountry = 'Казахстан';
				elseif ($this->params['country']=='Ukraine') $titleCountry = 'Украина';
				$isFullCountry = true;
			} else $isFullCountry = false;
			
			if ($this->params['type'] == 'table') {
				
				$ret = '<div class="covid-table"> <table id="covid19_table_'.$tID.'" class="cell-border compact stripe" data-page-length="'.(($this->params['per_page']) ? $this->params['per_page'] : '10').'"> <thead> <tr> <th>'.($this->params['label_country']).'</th> <th>'.($this->params['label_confirmed']).'</th> <th>'.($this->params['label_today_confirmed']).'</th> <th>'.($this->params['label_deaths']).'</th> <th>'.($this->params['label_today_deaths']).'</th> <th>'.($this->params['label_recovered']).'</th> </tr> </thead> <tbody>';
	
				foreach ($data as $key => $value) {
					$ret .= ' <tr> <td>'.(($isFullCountry) ? $value->region : '<img width="15" class="covid-flag" src="'.($value->countryInfo->flag).'" /> '.$this->country_translate($value->country)).'</td> <td>'.number_format($value->cases).'</td> <td>'.number_format($value->todayCases).'</td> <td>'.number_format($value->deaths).'</td> <td>'.number_format($value->todayDeaths).'</td> <td>'.number_format($value->recovered).'</td> </tr>';

					$total['cases'] += $value->cases; 
					$total['deaths'] += $value->deaths; 
					$total['recovered'] += $value->recovered; 
				}

				$ret .='</tbody> </table> <div class="covid-updated">'.$lang['c19_updated'].': '.$date.'</div> <script> jQuery(document).ready(function($) { $(\'#covid19_table_'.$tID.'\').DataTable({ "order": [[ 1, "desc" ]], "bLengthChange": false, "searching": 0, "language": { "emptyTable": "Нет информации", "info": "Показано _START_ - _END_ из _TOTAL_ строк", "infoEmpty": "Показано 0 - 0 из 0 строк", "paginate": { "first": "Первая", "last": "Последняя", "next": "След", "previous": "Пред" }, } }); } ); </script> </div>';
				
			} elseif ($this->params['type'] == 'box') {
				
				$ret = '<div class="covid-item covid-style-'.(($this->params["style"]) ? $this->params["style"] : "default").' covid-'.(($this->params['country']) ? 'country' : 'global').' '.(($this->params['dark_mode']) ? 'covid-darkmode-1' : '').'" > <div class="covid-inner"> <h4 class="covid-title">'.(($data->region) ? $data->region : (($this->params['country']) ? '<img width="30" class="title-flag" src="'.($data->countryInfo->flag).'"> '.$this->country_translate($data->country) : ((!isset($this->params['title'])) ? $lang['c19_def_title'] : $this->params['title']))).'</h4> <div class="covid-row"> <div class="covid-col covid-confirmed"> <div class="covid-label">'.($this->params['label_confirmed']).'</div> <div class="covid-value">'.number_format($data->cases).(($data->todayCases) ? '<div class="new-today">+'.number_format($data->todayCases).' <span class="new-label"></span> </div>' : '').'</div> </div> <div class="covid-col covid-deaths"> <div class="covid-label">'.($this->params['label_deaths']).'</div> <div class="covid-value">'.number_format($data->deaths).(($data->todayDeaths) ? '<div class="new-today">+'.number_format($data->todayDeaths).' <span class="new-label"></span> </div>' : '').'</div> </div> <div class="covid-col covid-recovered"> <div class="covid-label">'.($this->params['label_recovered']).'</div> <div class="covid-value">'.number_format($data->recovered).'</div> </div> <div class="covid-col covid-active"> <div class="covid-label">'.($this->params['label_active']).'</div> <div class="covid-value">'.number_format($data->active).'</div> </div> </div> </div> <div class="covid-updated">'.$lang['c19_updated'].': '.$date.'</div> </div>';
				
			} elseif ($this->params['type'] == 'list') {
				
				$ret = '<div class="covid-item covid-style-list '.(($this->params['dark_mode']) ? 'covid-darkmode-1' : '').' covid-global"> <h4 class="covid-title">'.((isset($this->params['title'])) ? $this->params['title'] : (($isFullCountry) ? $titleCountry : '')).'</h4> <li class="covid-country"> <div class=""></div> <div class="covid-country-stats covid-head"> <div class="covid-col covid-confirmed"> <div class="covid-label">'.($this->params['label_confirmed']).'</div> </div> <div class="covid-col covid-deaths"> <div class="covid-label">'.($this->params['label_deaths']).'</div> </div> <div class="covid-col covid-recovered"> <div class="covid-label">'.($this->params['label_recovered']).'</div> </div> </div> </li> <ul class="covid-list">';
	
				foreach ($data as $key => $value) {
					$ret .= ' <li class="covid-country"> <div class=""> '.(($isFullCountry) ? $value->region : ' <img width="15" class="covid-flag" src="'.($value->countryInfo->flag).'" /> '.$this->country_translate($value->country)).' </div> <div class="covid-country-stats"> <div class="covid-col covid-confirmed"> <div class="covid-value">'.number_format($value->cases).'</div> </div> <div class="covid-col covid-deaths"> <div class="covid-value">'.number_format($value->deaths).'</div> </div> <div class="covid-col covid-recovered"> <div class="covid-value">'.number_format($value->recovered).'</div> </div> </div> </li>';

					$total['cases'] += $value->cases; 
					$total['deaths'] += $value->deaths; 
					$total['recovered'] += $value->recovered; 
				}

				$ret .=' </ul> <div class="covid-country covid-total"> <div class="">Итого</div> <div class="covid-country-stats"> <div class="covid-col covid-confirmed"> <div class="covid-value">'.number_format($total['cases']).'</div> </div> <div class="covid-col covid-deaths"> <div class="covid-value">'.number_format($total['deaths']).'</div> </div> <div class="covid-col covid-recovered"> <div class="covid-value">'.number_format($total['recovered']).'</div> </div> </div> </div> <div class="covid-updated">'.$lang['c19_updated'].': '.$date.'</div> </div>';

			} elseif ($this->params['type'] == 'line') {
				
				$ret = '<div class="covid-line"> <div class="covid-line-wrap"> <div class="covid-line-colour covid-slideup covid-animated"></div> <div class="covid-line-title covid-slidein">'.(($data->region) ? $data->region : (($this->params['country']) ? $this->country_translate($data->country) : ((!isset($this->params['title'])) ? $lang['c19_def_title'] : $this->params['title']))).'</div> <div class="covid-line-headline covid-fadein covid-marquee"> <span class="line--confirmed"> '.($this->params['label_confirmed']).': <span class="line--value"> '.number_format($data->cases).(($data->todayCases) ? '<span class="line--today">+'.number_format($data->todayCases).' <span class="line--new"> за сегодня</span></span>' : '').' </span> </span> <span class="line--deaths"> '.($this->params['label_deaths']).': <span class="line--value"> '.number_format($data->deaths).(($data->todayDeaths) ? '<span class="line--today">+'.number_format($data->todayDeaths).' <span class="line--new"> за сегодня</span></span>' : '').' </span> </span> <span class="line--recovered"> '.($this->params['label_recovered']).': <span class="line--value">'.number_format($data->recovered).'</span> </span> <span class="line--active"> '.($this->params['label_active']).': <span class="line--value">'.number_format($data->active).'</span> </span> <span class="line--updated">'.$lang['c19_updated'].': '.$date.'</span> </div> </div> </div>';
				
			} elseif ($this->params['type'] == 'chart') {
				
				$id = 'covid19_chart_'.uniqid();
					
				$covidArray = '<script> var covid19 = {"history": '.json_encode($data[all]).'}</script>';
				
				$ret = $covidArray.'<div class="covid-chart" >
					<canvas id="'.$id.'" 
						data-confirmed="'.$this->params['label_confirmed'].'"
						data-deaths="'.$this->params['label_deaths'].'"
						data-recovered="'.$this->params['label_recovered'].'"
						data-json="'.str_replace("\"",'&quot;', json_encode($data[$this->params['country']])).'"
						'.(($this->params['country']) ? 'data-country="'.$this->params['country'].'"':'').'
					></canvas> 
						<div class="covid-updated">
							'.$lang['c19_updated'].': '.$date.'
						</div>
				</div>
				';
				
			} elseif ($this->params['type'] == 'map') {
				
				//may be late
				
			}
			
			//echo $ret;
			
			return $ret;
			
		}
		
		private function country_translate ($country) {
			
			$countries = array ('USA'=>'США','Spain'=>'Испания','Italy'=>'Италия','Germany'=>'Германия','France'=>'Франция','Iran'=>'Иран','UK'=>'Великобритания','Turkey'=>'Турция','Switzerland'=>'Швейцария','Belgium'=>'Бельгия','Netherlands'=>'Нидерланды','Canada'=>'Канада','Austria'=>'Австрия','Brazil'=>'Бразилия','Portugal'=>'Португалия','S. Korea'=>'Ю.Корея','Israel'=>'Израиль','Sweden'=>'Швеция','Russia'=>'Россия','Australia'=>'Австралия','Norway'=>'Норвегия','Ireland'=>'Ирландия','Chile'=>'Чили','India'=>'Индия','Czechia'=>'Чехия','Denmark'=>'Дания','Poland'=>'Польша','Romania'=>'Румыния','Malaysia'=>'Малайзия','Pakistan'=>'Пакистан','Ecuador'=>'Эквадор','Philippines'=>'Филиппины','Japan'=>'Япония','Luxembourg'=>'Люксембург','Saudi Arabia'=>'Саудовская Аравия','Peru'=>'Перу','Indonesia'=>'Индонезия','Thailand'=>'Таиланд','Serbia'=>'Сербия','Finland'=>'Финляндия','Mexico'=>'Мексика','UAE'=>'ОАЭ','Panama'=>'Панама','Qatar'=>'Катар','Dominican Republic'=>'Доминиканская Республика','Greece'=>'Греция','South Africa'=>'Южная Африка','Colombia'=>'Колумбия','Iceland'=>'Исландия','Argentina'=>'Аргентина','Algeria'=>'Алжир','Singapore'=>'Сингапур','Egypt'=>'Египет','Ukraine'=>'Украина','Croatia'=>'Хорватия','Morocco'=>'Марокко','Estonia'=>'Эстония','New Zealand'=>'Новая Зеландия','Iraq'=>'Ирак','Slovenia'=>'Словения','Moldova, Republic of'=>'Молдова, Республика','Hong Kong'=>'Гонконг','Lithuania'=>'Литва','Armenia'=>'Армения','Bahrain'=>'Бахрейн','Hungary'=>'Венгрия','Diamond Princess'=>'Алмазная принцесса','Belarus'=>'Беларусь','Bosnia'=>'Босния','Kuwait'=>'Кувейт','Kazakhstan'=>'Казахстан','Cameroon'=>'Камерун','Azerbaijan'=>'Азербайджан','Tunisia'=>'Тунис','Macedonia'=>'Македония','Bulgaria'=>'Болгария','Latvia'=>'Латвия','Lebanon'=>'Ливан','Slovakia'=>'Словакия','Andorra'=>'Андорра','Costa Rica'=>'Коста-Рика','Cyprus'=>'Кипр','Uzbekistan'=>'Узбекистан','Uruguay'=>'Уругвай','Albania'=>'Албания','Taiwan'=>'Тайвань','Afghanistan'=>'Афганистан','Cuba'=>'Куба','Jordan'=>'Иордания','Réunion'=>'Реюньон','Burkina Faso'=>'Буркина-Фасо','Oman'=>'Оман','Channel Islands'=>'Нормандские острова','Côte d\'Ivoire'=>'Кот-д\'Ивуар','Honduras'=>'Гондурас','San Marino'=>'Сан-Марино','Niger'=>'Нигер','Palestinian Territory, Occupied'=>'Палестинская территория','Vietnam'=>'Вьетнам','Mauritius'=>'Маврикий','Malta'=>'Мальта','Nigeria'=>'Нигерия','Montenegro'=>'Черногория','Senegal'=>'Сенегал','Kyrgyzstan'=>'Кыргызстан','Ghana'=>'Гана','Georgia'=>'Грузия','Bolivia'=>'Боливия','Faroe Islands'=>'Фарерские острова','Sri Lanka'=>'Шри-Ланка','DRC'=>'ДРК','Venezuela'=>'Венесуэла','Kenya'=>'Кения','Martinique'=>'Мартиника','Mayotte'=>'Майотта','Isle of Man'=>'Остров Мэн','Guadeloupe'=>'Гваделупа','Brunei'=>'Бруней','Bangladesh'=>'Бангладеш','Guinea'=>'Гвинея','Cambodia'=>'Камбоджа','Paraguay'=>'Парагвай','Gibraltar'=>'Гибралтар','Trinidad and Tobago'=>'Тринидад и Тобаго','Rwanda'=>'Руанда','Madagascar'=>'Мадагаскар','Liechtenstein'=>'Лихтенштейн','Monaco'=>'Монако','Aruba'=>'Аруба','Guatemala'=>'Гватемала','El Salvador'=>'Сальвадор','French Guiana'=>'Французская Гвиана','Djibouti'=>'Джибути','Jamaica'=>'Ямайка','Barbados'=>'Барбадос','Togo'=>'Того','Uganda'=>'Уганда','Mali'=>'Мали','Congo'=>'Конго','Ethiopia'=>'Эфиопия','Macao'=>'Макао','French Polynesia'=>'Французская Полинезия','Bermuda'=>'Бермудские острова','Cayman Islands'=>'Каймановы острова','Zambia'=>'Замбия','Sint Maarten'=>'Синт','Saint Martin'=>'Сен-Мартен','Eritrea'=>'Эритрея','Bahamas'=>'Багамские острова','Guyana'=>'Гайана','Gabon'=>'Габон','Haiti'=>'Гаити','Tanzania, United Republic of'=>'Танзания, Объединенная Республика','Benin'=>'Бенин','Myanmar'=>'Мьянма','Syrian Arab Republic'=>'Сирийская Арабская Республика','Maldives'=>'Мальдивы','Libyan Arab Jamahiriya'=>'Ливийская Арабская Джамахирия','Guinea-Bissau'=>'Гвинея-Бисау','New Caledonia'=>'Новая Каледония','Angola'=>'Ангола','Equatorial Guinea'=>'Экваториальная Гвинея','Namibia'=>'Намибия','Antigua and Barbuda'=>'Антигуа и Барбуда','Mongolia'=>'Монголия','Liberia'=>'Либерия','Dominica'=>'Доминика','Fiji'=>'Фиджи','Saint Lucia'=>'Сент-Люсия','Curaçao'=>'Кюрасао','Sudan'=>'Судан','Grenada'=>'Гренада','Lao People\'s Democratic Republic'=>'Лаосская Народно-Демократическая Республика','Greenland'=>'Гренландия','Seychelles'=>'Сейшельские острова','Suriname'=>'Суринам','Zimbabwe'=>'Зимбабве','Mozambique'=>'Мозамбик','Saint Kitts and Nevis'=>'Сент-Китс и Невис','Swaziland'=>'Свазиленд','MS Zaandam'=>'MS Zaandam','Nepal'=>'Непал','Chad'=>'Чад','Central African Republic'=>'Центрально-Африканская Республика Республика','Belize'=>'Белиз','Cabo Verde'=>'Кабо-Верде','Holy See (Vatican City State)'=>'Святой Престол','Saint Vincent and the Grenadines'=>'Сент-Винсент и Гренадины','Somalia'=>'Сомали','Botswana'=>'Ботсвана','Mauritania'=>'Мавритания','Nicaragua'=>'Никарагуа','Montserrat'=>'Монтсеррат','St. Barth'=>'Св. Барт','Sierra Leone'=>'Сьерра-Леоне','Turks and Caicos Islands'=>'Острова Теркс и Кайкос','Bhutan'=>'Бутан','Malawi'=>'Малави','Gambia'=>'Гамбия','Sao Tome and Principe'=>'Сан-Томе и Принсипи','Western Sahara'=>'Западная Сахара','Anguilla'=>'Ангилья','British Virgin Islands'=>'Британские Виргинские острова','Burundi'=>'Бурунди','Caribbean Netherlands'=>'Карибские острова Нидерланды','Falkland Islands (Malvinas)'=>'Фолклендские (Мальвинские) острова','Papua New Guinea'=>'Папуа-Новая Гвинея','Saint Pierre Miquelon'=>'Сен-Пьер Микелон','South Sudan'=>'Юг Судан','Timor-Leste'=>'Восточный Тимор','China'=>'Китай');

			if ($countries[$country]) return $countries[$country];
				else return $country;
		}
	}
}