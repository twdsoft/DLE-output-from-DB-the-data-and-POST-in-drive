<?PHP 

//Corona.Info Configurations

$c19_config = array (

'cache_time' => '10',

'get_world_data' => '1',

'get_ru_data' => '0',

'get_ua_data' => '0',

'get_history_data' => '0',

);

?>