package com.yoggo.dleandroidclient.interfaces;

public interface CommentariesUpdateListener {
	public void updateCommentaries();
}
