package com.yoggo.dleandroidclient.interfaces;

public interface DrawerListUpdateCallback {
	public void updateList();
}
