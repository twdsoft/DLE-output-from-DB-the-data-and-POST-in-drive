package com.yoggo.dleandroidclient.interfaces;

public interface OldNewsLoadListener {
	public void loadNews();
}
