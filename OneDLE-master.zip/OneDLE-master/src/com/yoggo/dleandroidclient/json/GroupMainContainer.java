package com.yoggo.dleandroidclient.json;

import java.util.List;

import com.google.gson.annotations.SerializedName;

public class GroupMainContainer {
	
	
	
	@SerializedName("")
	public GroupJson list;
}
