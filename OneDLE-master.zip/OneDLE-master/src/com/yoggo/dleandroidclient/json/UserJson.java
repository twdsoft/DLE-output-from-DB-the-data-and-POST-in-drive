package com.yoggo.dleandroidclient.json;

import com.google.gson.annotations.SerializedName;

public class UserJson {
	
	@SerializedName("user_id")
	public String userId;
	
	@SerializedName("user_group")
	public String userGroup;
}
