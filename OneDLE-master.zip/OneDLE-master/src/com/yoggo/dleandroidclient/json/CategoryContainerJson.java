package com.yoggo.dleandroidclient.json;

import com.google.gson.annotations.SerializedName;

public class CategoryContainerJson {
	
	@SerializedName("1")
	public CategoryJson categoryJson1;
	@SerializedName("2")
	public CategoryJson categoryJson2;
	@SerializedName("3")
	public CategoryJson categoryJson3;
	@SerializedName("4")
	public CategoryJson categoryJson4;
	@SerializedName("5")
	public CategoryJson categoryJson5;
	@SerializedName("6")
	public CategoryJson categoryJson6;
}
