package com.yoggo.dleandroidclient.json;

public class MyJsonParser {
	
}
