package com.yoggo.dleandroidclient.json;

import com.google.gson.annotations.SerializedName;

public class TokenJson {
	@SerializedName("token")
	public String token;
}
