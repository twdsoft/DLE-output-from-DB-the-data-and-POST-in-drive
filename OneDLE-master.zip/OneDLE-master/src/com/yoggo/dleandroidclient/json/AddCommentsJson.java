package com.yoggo.dleandroidclient.json;

import com.google.gson.annotations.SerializedName;

public class AddCommentsJson {
	@SerializedName("result")
	public String result;
	
	@SerializedName("error")
	public String error;
}
